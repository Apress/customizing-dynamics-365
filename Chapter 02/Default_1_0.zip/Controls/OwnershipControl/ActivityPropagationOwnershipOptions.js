/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var ActivityPropagationOwnership;
    (function (ActivityPropagationOwnership) {
        var OwnershipControl = (function () {
            function OwnershipControl() {
                var _this = this;
                this.init = function (context, notifyOutputChanged, state, container) {
                    _this.controlBuilder = new ActivityPropagationOwnership.ControlBuilder(context);
                    _this.container = container;
                    _this.notifyOutputChanged = notifyOutputChanged;
                    _this.render(context);
                };
                this.updateView = function (context) {
                    _this.updateRadioControls();
                    context.state.IsEmailActivity = Number(context.parameters.IsEmailActivity.formatted) === 1;
                    _this.state = context.state;
                    _this.render(context);
                };
                this.getOutputs = function () {
                    var ownerId = null;
                    var queueId = null;
                    var hasOwner = _this.state.SelectedOption === 0 /* Other */;
                    if (hasOwner) {
                        ownerId = _this.state.SelectedOwner;
                    }
                    if (_this.state.AddToQueue) {
                        queueId = _this.state.SelectedQueue;
                    }
                    return {
                        CloseEmailActivity: (_this.state.IsEmailActivity && _this.state.CloseEmailActivity),
                        OwnerId: ownerId,
                        QueueId: queueId,
                        OwnershipOption: _this.state.SelectedOption,
                        AddToQueue: _this.state.AddToQueue
                    };
                };
                this.destroy = function () {
                    _this.container.remove();
                    _this.container = null;
                    _this.state = null;
                };
                this.updateRadioControls = function () {
                    _this.controlBuilder.updateRadioControls(_this.container);
                };
                this.render = function (context) {
                    var localized = ActivityPropagationOwnership.LocalizedStrings.getLocalized(context);
                    var optionChanged = function (value) {
                        return function () {
                            _this.state.SelectedOption = value;
                            _this.render(context);
                        };
                    };
                    var queueInputChanged = function (value) {
                        _this.state.AddToQueue = value;
                        _this.render(context);
                    };
                    var closeActivityChanged = function (value) {
                        _this.state.CloseEmailActivity = value;
                        _this.render(context);
                    };
                    var getContainer = function (id, input) {
                        return _this.controlBuilder.buildContainer(id, [input], ActivityPropagationOwnership.Style.Classes.Inline);
                    };
                    var customerOwnerGroup = _this.createOwnershipGroup(2 /* ListMemberOwner */, localized.CustomerOwnerLabel, optionChanged);
                    var myselfOwnerGroup = _this.createOwnershipGroup(1 /* Caller */, localized.MyselfOwnerLabel, optionChanged);
                    var ownerLookup = _this.controlBuilder.buildOwnerLookupControl("ownerLookup", _this.state.SelectedOption !== 0 /* Other */, _this.onOwnerLookupSelectionChanged);
                    var ownerGroup = _this.createOwnershipGroup(0 /* Other */, localized.OwnerLabel, optionChanged, ownerLookup);
                    var queueLookupContainer = _this.createQueueGroup(localized.QueueLabel, queueInputChanged);
                    var containers = [customerOwnerGroup, myselfOwnerGroup, ownerGroup, queueLookupContainer];
                    if (_this.state.IsEmailActivity) {
                        containers.push(_this.createActivityGroup(localized.CloseActivityTitle, localized.CloseActivityLabel, closeActivityChanged));
                    }
                    var optionsContainer = _this.controlBuilder.buildContainer("optionsContainer", containers);
                    var ownershipControlContainer = _this.controlBuilder.buildContainer("ownershipControlContainer", [optionsContainer], ActivityPropagationOwnership.Style.Classes.Main);
                    context.utils.bindDOMElement(ownershipControlContainer, _this.container);
                    _this.notifyOutputChanged();
                    context.state = _this.state;
                };
                this.createOwnershipGroup = function (option, text, callback, lookup) {
                    var id = "ownershipGroup_" + option + "_" + text;
                    var inputId = id + "_input";
                    var checked = _this.state.SelectedOption === option;
                    var onChange = callback(option);
                    var builder = _this.controlBuilder;
                    var input = builder.buildContainer(id + "_inputContainer", [builder.buildRadioButton(inputId, inputId, onChange, checked, ActivityPropagationOwnership.Style.Classes.Input)], ActivityPropagationOwnership.Style.Classes.Inline);
                    var label = builder.buildLabel(id + "_label", text, inputId, ActivityPropagationOwnership.Style.Classes.Inline);
                    var subGroup = builder.buildContainer(id + "_subGroup", [input, label], ActivityPropagationOwnership.Style.Classes.Group);
                    return builder.buildContainer(id + "_group", [subGroup, lookup], ActivityPropagationOwnership.Style.Classes.Container);
                };
                this.createQueueGroup = function (text, onChange) {
                    var id = "queueGroup_" + text;
                    var inputId = id + "_input";
                    var builder = _this.controlBuilder;
                    var input = builder.buildContainer(id + "_inputContainer", [builder.buildCheckbox(inputId, onChange, _this.state.AddToQueue, ActivityPropagationOwnership.Style.Classes.Input)], ActivityPropagationOwnership.Style.Classes.Inline);
                    var label = builder.buildLabel(id + "_label", text, inputId, ActivityPropagationOwnership.Style.Classes.Inline);
                    var subGroup = builder.buildContainer(id + "_subGroup", [input, label], ActivityPropagationOwnership.Style.Classes.Group);
                    var lookup = builder.buildQueueLookupControl(id + "_lookup", !_this.state.AddToQueue, _this.onQueueLookupSelectionChanged);
                    return builder.buildContainer(id + "_group", [subGroup, lookup], ActivityPropagationOwnership.Style.Classes.Container);
                };
                this.createActivityGroup = function (titleText, labelText, onChange) {
                    var id = "activityGroup_" + titleText + "_" + labelText;
                    var inputId = id + "_input";
                    var builder = _this.controlBuilder;
                    var title = builder.buildLabel(id + "_title", titleText, null, ActivityPropagationOwnership.Style.Classes.Title);
                    var titleContainer = builder.buildContainer(id + "_titleContainer", [title], ActivityPropagationOwnership.Style.Classes.TitleContainer);
                    var input = builder.buildContainer(id + "_inputContainer", [builder.buildCheckbox(inputId, onChange, _this.state.CloseEmailActivity, ActivityPropagationOwnership.Style.Classes.Input)], ActivityPropagationOwnership.Style.Classes.Inline);
                    var label = builder.buildLabel(id + "_label", labelText, inputId, ActivityPropagationOwnership.Style.Classes.Inline);
                    var subGroup = builder.buildContainer(id + "_subGroup", [input, label], ActivityPropagationOwnership.Style.Classes.Group);
                    return builder.buildContainer(id + "_group", [titleContainer, subGroup], ActivityPropagationOwnership.Style.Classes.Container);
                };
                this.onOwnerLookupSelectionChanged = function (value) {
                    if (value.length !== 0) {
                        _this.state.SelectedOwner = {
                            Id: value[0].id,
                            LogicalName: value[0].entityName,
                            Name: value[0].name
                        };
                    }
                    else {
                        _this.state.SelectedOwner = null;
                    }
                    _this.notifyOutputChanged();
                };
                this.onQueueLookupSelectionChanged = function (value) {
                    if (value.length !== 0) {
                        _this.state.SelectedQueue = {
                            Id: value[0].id,
                            LogicalName: value[0].entityName,
                            Name: value[0].name
                        };
                    }
                    else {
                        _this.state.SelectedQueue = null;
                    }
                    _this.notifyOutputChanged();
                };
                this.state = {
                    SelectedOption: 2 /* ListMemberOwner */,
                    AddToQueue: false,
                    IsEmailActivity: false,
                    SelectedQueue: null,
                    SelectedOwner: null,
                    CloseEmailActivity: true
                };
            }
            return OwnershipControl;
        }());
        ActivityPropagationOwnership.OwnershipControl = OwnershipControl;
    })(ActivityPropagationOwnership = MscrmControls.ActivityPropagationOwnership || (MscrmControls.ActivityPropagationOwnership = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ActivityPropagationOwnership;
    (function (ActivityPropagationOwnership) {
        var ControlBuilder = (function () {
            function ControlBuilder(context) {
                this.context = context;
                this.FalseBound = 3;
                this.radioControlsToUpdate = [];
            }
            ControlBuilder.prototype.buildOwnerLookupControl = function (id, isDisabled, callback) {
                if (isDisabled === void 0) { isDisabled = true; }
                var lookup = this.context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", "cc_owner_lookup", {
                    controlstates: {
                        hasFocus: this.context.mode.hasFocus,
                        isControlDisabled: isDisabled
                    },
                    descriptor: {
                        Id: "cc_owner_lookup-Id",
                        Label: "cc_owner_lookup-Label",
                        Name: "cc_owner_lookup-Name",
                        ShowLabel: false,
                        Visible: true,
                        Disabled: isDisabled
                    },
                    configuration: {
                        FormFactor: this.context.client.formFactor,
                        CustomControlId: "MscrmControls.FieldControls.SimpleLookupControl",
                        Name: "cc_owner_lookup-Config",
                        Version: "1.0.0",
                        Parameters: {
                            value: this.getOwnerValueParameter(callback)
                        }
                    }
                });
                var boxedLookup = this.buildContainer(id + "_container", [lookup], ActivityPropagationOwnership.Style.Classes.Lookup);
                var required = isDisabled ? null : this.buildRequiredIndicator(id + "_required", ActivityPropagationOwnership.Style.Classes.Indicator);
                var group = this.buildContainer(id + "_group", [required, boxedLookup], ActivityPropagationOwnership.Style.Classes.Group);
                return this.buildContainer(id + "_ownerLookupContainer", [group], ActivityPropagationOwnership.Style.Classes.Container);
            };
            ControlBuilder.prototype.buildQueueLookupControl = function (id, isDisabled, callback) {
                if (isDisabled === void 0) { isDisabled = true; }
                var lookup = this.context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", "cc_queue_lookup", {
                    controlstates: {
                        hasFocus: this.context.mode.hasFocus,
                        isControlDisabled: isDisabled
                    },
                    descriptor: {
                        Id: "cc_queue_lookup-Id",
                        Label: "cc_queue_lookup-Label",
                        Name: "cc_queue_lookup-Name",
                        ShowLabel: false,
                        Visible: true,
                        Disabled: isDisabled
                    },
                    configuration: {
                        FormFactor: this.context.client.formFactor,
                        CustomControlId: "MscrmControls.FieldControls.SimpleLookupControl",
                        Name: "cc_queue_lookup-Config",
                        Version: "1.0.0",
                        Parameters: {
                            value: this.getQueueValueParameter(callback)
                        }
                    }
                });
                var boxedLookup = this.buildContainer(id + "_container", [lookup], ActivityPropagationOwnership.Style.Classes.Lookup);
                var required = isDisabled ? null : this.buildRequiredIndicator(id + "_required", ActivityPropagationOwnership.Style.Classes.Indicator);
                var group = this.buildContainer(id + "_group", [required, boxedLookup], ActivityPropagationOwnership.Style.Classes.Group);
                return this.buildContainer(id + "_queueLookupContainer", [group], ActivityPropagationOwnership.Style.Classes.Container);
            };
            ControlBuilder.prototype.buildLabel = function (labelId, title, forElementId, style, visible) {
                var properties = {
                    key: labelId,
                    forElementId: forElementId,
                    style: style,
                    visible: visible
                };
                return this.context.factory.createElement("LABEL", properties, title);
            };
            ControlBuilder.prototype.buildContainer = function (containerId, children, style) {
                var properties = {
                    id: containerId,
                    key: containerId,
                    style: style
                };
                return this.context.factory.createElement("CONTAINER", properties, children);
            };
            ControlBuilder.prototype.buildRadioButton = function (inputId, inputName, onValueChanged, isChecked, style) {
                if (isChecked === void 0) { isChecked = false; }
                var properties = {
                    absoluteId: inputId,
                    id: inputId,
                    key: inputId,
                    name: inputName,
                    value: isChecked,
                    onValueChange: onValueChanged,
                    style: style,
                    // tslint:disable-next-line:object-literal-key-quotes because 'type' is a typescript keyword
                    "type": "radio",
                    role: "radio"
                };
                if (this.radioControlsToUpdate.indexOf(inputId) === -1) {
                    this.radioControlsToUpdate.push(inputId);
                }
                return this.context.factory.createElement("BOOLEAN", properties);
            };
            ControlBuilder.prototype.buildCheckbox = function (inputId, onValueChanged, isChecked, style) {
                if (isChecked === void 0) { isChecked = false; }
                var properties = {
                    absoluteId: inputId,
                    id: inputId,
                    key: inputId,
                    onValueChange: onValueChanged,
                    value: isChecked,
                    style: style
                };
                return this.context.factory.createElement("BOOLEAN", properties);
            };
            ControlBuilder.prototype.updateRadioControls = function (container) {
                this.radioControlsToUpdate.forEach(function (controlId) {
                    var inputId = controlId;
                    var input = document.getElementById(inputId);
                    input.type = "radio";
                    input.role = "radio";
                });
            };
            ControlBuilder.prototype.buildRequiredIndicator = function (id, style) {
                var textbox = this.context.theming.textbox;
                var symbol = "*";
                style.color = textbox.redcolor;
                var indicator = this.context.factory.createElement("CONTAINER", {
                    id: id,
                    key: "required",
                    style: style
                }, symbol);
                return this.buildContainer(id + "_container", [indicator], ActivityPropagationOwnership.Style.Classes.Inline);
            };
            ControlBuilder.prototype.getOwnerValueParameter = function (callback) {
                return {
                    Usage: this.FalseBound,
                    Static: false,
                    Value: null,
                    Type: "Lookup.Owner",
                    Callback: callback,
                    ViewId: "2DF45189-84C2-452A-B4D6-D09F918EBCA7",
                    Attributes: {
                        EntityLogicalName: "campaignactivity",
                        LogicalName: "ownerid",
                        Type: "lookup",
                        Targets: ["systemuser", "team"],
                        Initialized: 0
                    }
                };
            };
            ControlBuilder.prototype.getQueueValueParameter = function (callback) {
                return {
                    Usage: this.FalseBound,
                    Static: false,
                    Value: null,
                    Type: "Lookup.Simple",
                    Callback: callback,
                    ViewId: "3434f892-b38a-4a21-98e4-35c473073f52",
                    Attributes: {
                        EntityLogicalName: "campaignactivity",
                        LogicalName: "queueid",
                        Type: "lookup",
                        Targets: ["queue"],
                        Initialized: 0
                    }
                };
            };
            return ControlBuilder;
        }());
        ActivityPropagationOwnership.ControlBuilder = ControlBuilder;
    })(ActivityPropagationOwnership = MscrmControls.ActivityPropagationOwnership || (MscrmControls.ActivityPropagationOwnership = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var ActivityPropagationOwnership;
    (function (ActivityPropagationOwnership) {
        var Style = (function () {
            function Style() {
            }
            return Style;
        }());
        Style.Classes = {
            Title: {
                "font-weight": "bold"
            },
            TitleContainer: {
                "padding-bottom": "5px"
            },
            Inline: {
                display: "inline"
            },
            Input: {
                display: "inline",
                margin: "3px 10px 0px 5px"
            },
            Lookup: {
                width: "90%",
                display: "inline"
            },
            Indicator: {
                display: "inline",
                margin: "5px 10px 0px 10px"
            },
            Container: {
                "display": "block",
                "padding-bottom": "5px"
            },
            Group: {
                display: "inline-flex",
                width: "100%"
            },
            Main: {
                display: "block",
                padding: "5px"
            }
        };
        ActivityPropagationOwnership.Style = Style;
    })(ActivityPropagationOwnership = MscrmControls.ActivityPropagationOwnership || (MscrmControls.ActivityPropagationOwnership = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../privatereferences.ts" />
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="../privatereferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var ActivityPropagationOwnership;
    (function (ActivityPropagationOwnership) {
        var LocalizedStrings = (function () {
            function LocalizedStrings() {
            }
            LocalizedStrings.getLocalized = function (context) {
                return {
                    CustomerOwnerLabel: context.resources.getString("Customer_Owner_Label"),
                    MyselfOwnerLabel: context.resources.getString("Myself_Owner_Label"),
                    OwnerLabel: context.resources.getString("Owner_Label"),
                    QueueLabel: context.resources.getString("Queue_Label"),
                    CloseActivityTitle: context.resources.getString("Close_Activity_Title"),
                    CloseActivityLabel: context.resources.getString("Close_Activity_Label")
                };
            };
            return LocalizedStrings;
        }());
        ActivityPropagationOwnership.LocalizedStrings = LocalizedStrings;
    })(ActivityPropagationOwnership = MscrmControls.ActivityPropagationOwnership || (MscrmControls.ActivityPropagationOwnership = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="PropagationOwnershipOptions.ts" />
/// <reference path="ActivityPropagationOwnershipControl.ts" />
/// <reference path="ControlBuilder.ts" />
/// <reference path="Style.ts" />
/// <reference path="Localization/ILocalizedStrings.ts" />
/// <reference path="Localization/LocalizedStrings.ts" />
//# sourceMappingURL=ActivityPropagationOwnershipOptions.js.map