var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/lib.es6.d.ts" />
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../../Packages/Crm.ClientApiTypings.1.0.839/clientapi/XrmClientApi.d.ts" />
/// <reference path="../../../../../Packages/Crm.ClientApiTypings.1.0.839/clientapi/XrmClientApiDeprecated.d.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/microsoft.ajax.d.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/whatwg-fetch.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="../../../../TypeDefinitions/AppCommon/Telemetry/TelemetryLibrary.d.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/FeatureTelemetry/FeatureTelemetry.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        Suggestions.LOC_KEYS = {
            GRID_TITLE_CROSS_SELL: "CC_Cross_Sell",
            GRID_TITLE_ACCESSORY: "CC_Accessory",
            GRID_TITLE_UP_SELL: "CC_Up_Sell",
            GRID_TITLE_SUBSTITUTE: "CC_Substitute",
            GRID_NO_ITEM_SELECTED_ERROR: "CC_No_Item_Selected_Error"
        };
        var SuggestionsControl = (function () {
            /**
             * Empty constructor.
             */
            function SuggestionsControl() {
                this.AppCommonNullCheck = function () {
                    return ((typeof (AppCommon) !== 'undefined') &&
                        (AppCommon != null && AppCommon != undefined) &&
                        (AppCommon.TelemetryReporter != null && AppCommon.TelemetryReporter != undefined) &&
                        (AppCommon.TelemetryReporter.Instance() != null && AppCommon.TelemetryReporter.Instance() != undefined));
                };
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            SuggestionsControl.prototype.init = function (context, notifyOutputChanged, state) {
                var _this = this;
                // custom code goes here
                if (this.AppCommonNullCheck()) {
                    AppCommon.TelemetryReporter.Instance().PostStartMarker("SalesWebResources", "SuggestionsControl", "init", this.ProductId);
                }
                SuggestionsControl.context = context;
                this.Value1 = this.getParamValueById("Value1").raw;
                this.ProductId = this.getParamValueById("ProductId").raw;
                this.PriceLevelId = this.getParamValueById("PriceLevelId").raw;
                this.EntityName = this.getParamValueById("EntityName").raw;
                this.EntityRecordId = this.getParamValueById("EntityRecordId").raw;
                this.ProductName = this.getParamValueById("ProductName").raw;
                this.ChildEntityName = this.getParamValueById("ChildEntityName").raw;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                SuggestionsControl.suggestionsGridDataSetProvider = new Suggestions.CrossSellGridDataSetProvider();
                SuggestionsControl.crossSellGridDataSetProvider = Suggestions.SuggestionsGridDataSetFactory.Create(Suggestions.SuggestionGridType.CROSS_SELL);
                SuggestionsControl.accessoryGridDataSetProvider = Suggestions.SuggestionsGridDataSetFactory.Create(Suggestions.SuggestionGridType.ACCESSORY);
                SuggestionsControl.substituteGridDataSetProvider = Suggestions.SuggestionsGridDataSetFactory.Create(Suggestions.SuggestionGridType.SUBSTITUTE);
                SuggestionsControl.upSellGridDataSetProvider = Suggestions.SuggestionsGridDataSetFactory.Create(Suggestions.SuggestionGridType.UP_SELL);
                var self = this;
                SuggestionsControl.suggestionsGridDataSetProvider.getSuggestionGridData(this.ProductId, this.PriceLevelId).then(function (response) {
                    if (self.AppCommonNullCheck()) {
                        AppCommon.TelemetryReporter.Instance().PostEndMarker("SalesWebResources", "SuggestionsControl", "init", self.ProductId, "", true);
                    }
                    SuggestionsControl.isDataAvailable = true;
                    var addButtonData = $('[data-id="add_to_list_id"]');
                    if (addButtonData.length > 0) {
                        addButtonData[0].addEventListener("click", function () {
                            this.addToList();
                        }.bind(_this));
                    }
                    var cancelButtonData = $('[data-id="cancel_id"]');
                    if (cancelButtonData.length > 0) {
                        cancelButtonData[0].addEventListener("click", function () {
                            window.parent["lastButtonClicked"] = "Cancel";
                            this.closeMDDFromCustomControl();
                        }.bind(_this));
                    }
                    SuggestionsControl.context.utils.requestRender();
                });
                this.createControlTitle();
                if (this.AppCommonNullCheck()) {
                    AppCommon.TelemetryReporter.Instance().PostEndMarker("SalesWebResources", "SuggestionsControl", "init", this.ProductId);
                }
            };
            /**
             * gets the values for the manifest parameters
             */
            SuggestionsControl.prototype.getParamValueById = function (id) {
                var result;
                switch (id) {
                    case "Value1":
                        result = SuggestionsControl.context.parameters.Value1;
                        break;
                    case "ProductId":
                        result = SuggestionsControl.context.parameters.ProductId;
                        break;
                    case "PriceLevelId":
                        result = SuggestionsControl.context.parameters.PriceLevelId;
                        break;
                    case "EntityName":
                        result = SuggestionsControl.context.parameters.EntityName;
                        break;
                    case "EntityRecordId":
                        result = SuggestionsControl.context.parameters.EntityRecordId;
                        break;
                    case "ProductName":
                        result = SuggestionsControl.context.parameters.ProductName;
                        break;
                    case "ChildEntityName":
                        result = SuggestionsControl.context.parameters.ChildEntityName;
                        break;
                }
                return result;
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            SuggestionsControl.prototype.updateView = function (context) {
                if (SuggestionsControl.isDataAvailable) {
                    return this.renderGrids();
                }
                else {
                    return this._renderProgressIndicator();
                }
            };
            /**
             * add the selected products to the grid
             */
            SuggestionsControl.prototype.addToList = function () {
                try {
                    var selectedProductIds = SuggestionsControl.crossSellGridDataSetProvider.getSelectedRecords().concat(SuggestionsControl.accessoryGridDataSetProvider.getSelectedRecords()).concat(SuggestionsControl.upSellGridDataSetProvider.getSelectedRecords()).concat(SuggestionsControl.substituteGridDataSetProvider.getSelectedRecords());
                    if (selectedProductIds.length > 0) {
                        var entityXml = '';
                        var parentEntityXml = '';
                        for (var i = 0; i < selectedProductIds.length; i++) {
                            var productPriceLevelId = selectedProductIds[i];
                            var entityReferenceLogicalName = "productpricelevel";
                            entityXml += '<a:Entity><a:Attributes xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"><a:KeyValuePairOfstringanyType><b:key>productid</b:key><b:value i:type="a:EntityReference"><a:Id>' + productPriceLevelId + '</a:Id><a:LogicalName>' + entityReferenceLogicalName + '</a:LogicalName></b:value></a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil="true"/><a:FormattedValues xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/><a:LogicalName>' + this.ChildEntityName + '</a:LogicalName><a:RelatedEntities xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/></a:Entity>';
                            parentEntityXml += '<a:Id>' + this.EntityRecordId + '</a:Id><a:LogicalName >' + this.EntityName + '</a:LogicalName>';
                        }
                        var self_1 = this;
                        var xml = '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><SdkClientVersion xmlns="http://schemas.microsoft.com/xrm/2011/Contracts">9.0</SdkClientVersion></s:Header><s:Body><Execute xmlns="http://schemas.microsoft.com/xrm/2011/Contracts/Services" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><request i:type="b:CreateProductsRequest" xmlns:a="http://schemas.microsoft.com/xrm/2011/Contracts" xmlns:b="http://schemas.microsoft.com/crm/2011/Contracts"><a:Parameters xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"><a:KeyValuePairOfstringanyType><b:key>Entities</b:key><b:value i:type="a:EntityCollection"><a:Entities>' + entityXml + '</a:Entities></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>ParentEntity</b:key><b:value i:type="a:Entity"><a:Attributes xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/><a:EntityState i:nil = "true" /><a:FormattedValues xmlns:b = "http://schemas.datacontract.org/2004/07/System.Collections.Generic" />' + parentEntityXml + '<a:RelatedEntities xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil="true" /><a:RequestName>CreateProducts</a:RequestName></request></Execute></s:Body></s:Envelope>';
                        var xHReq = new XMLHttpRequest();
                        xHReq.open('POST', '/' + SuggestionsControl.context.orgSettings.uniqueName + '/XRMServices/2011/Organization.svc/web', false);
                        xHReq.setRequestHeader('SOAPAction', 'http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute');
                        xHReq.onload = function () {
                            window.parent["lastButtonClicked"] = "AddToList";
                            if (self_1.AppCommonNullCheck()) {
                                AppCommon.ProductGridEventWriter.WriteEvent(self_1.EntityName, AppCommon.ProductGridEventContext.AddSuggestedProductClassic, self_1.ProductId);
                            }
                            this.closeMDDFromCustomControl();
                        }.bind(this);
                        xHReq.setRequestHeader('Content-Type', 'text/xml; charset=utf-8');
                        xHReq.setRequestHeader('Content-Length', xml.length.toString());
                        xHReq.send(xml);
                    }
                    else {
                        SuggestionsControl.ErrorMessage = SuggestionsControl.context.resources.getString(Suggestions.LOC_KEYS.GRID_NO_ITEM_SELECTED_ERROR);
                        this.createErrorContainer();
                    }
                }
                catch (exception) {
                    console.warn(exception);
                }
            };
            /**
             * closes the control
             */
            SuggestionsControl.prototype.closeMDDFromCustomControl = function () {
                try {
                    if (window.Xrm && window.Xrm.Page && window.Xrm.Page.ui) {
                        window.Xrm.Page.ui.close();
                    }
                }
                catch (exception) {
                    console.warn(exception);
                }
            };
            /**
             * renders four grids
             */
            SuggestionsControl.prototype.renderGrids = function () {
                var crossSellComponent = this.renderGrid(Suggestions.SuggestionGridType.CROSS_SELL);
                var upSellComponent = this.renderGrid(Suggestions.SuggestionGridType.UP_SELL);
                var accessoryComponent = this.renderGrid(Suggestions.SuggestionGridType.ACCESSORY);
                var substituteComponent = this.renderGrid(Suggestions.SuggestionGridType.SUBSTITUTE);
                var container = SuggestionsControl.context.factory.createElement("CONTAINER", {
                    id: "suggestionsFlyoutControlContainer",
                    key: "suggestionsFlyoutControlContainer",
                    style: {
                        "display": "block",
                        "width": "100%",
                        "color": SuggestionsControl.context.theming.colors.grays.gray05,
                        "background-color": SuggestionsControl.context.theming.colors.whitebackground
                    }
                }, [crossSellComponent, upSellComponent, accessoryComponent, substituteComponent]);
                return container;
            };
            /**
             * renders a grid of type gridType
             */
            SuggestionsControl.prototype.renderGrid = function (gridType) {
                var container = SuggestionsControl.context.factory.createElement("CONTAINER", {
                    id: "gridContainer" + gridType.toString(),
                    key: "gridContainer" + gridType.toString(),
                    style: {
                        "display": "block",
                        "width": "100%",
                        "color": SuggestionsControl.context.theming.colors.grays.gray05,
                        "background-color": SuggestionsControl.context.theming.colors.whitebackground,
                        "margin-bottom": "50px"
                    }
                }, [this.createGridTitle(gridType), this.createGrid(gridType)]);
                return container;
            };
            /**
             * create the grid title gor a grid
             */
            SuggestionsControl.prototype.createGridTitle = function (gridType) {
                var dataSetProvider = this.getDataProvider(gridType);
                var context = SuggestionsControl.context;
                var gridTitle = dataSetProvider.getTitle();
                var label = context.factory.createElement("LABEL", {
                    id: "label_" + gridType.toString(),
                    key: "label_" + gridType.toString(),
                    style: {
                        fontSize: "14px",
                        fontFamilies: context.theming.fontfamilies.bold,
                        border: "none",
                        color: "#828181"
                    }
                }, gridTitle);
                return context.factory.createElement("CONTAINER", {
                    id: "labelcontainer_" + gridTitle,
                    key: "labelcontainer_" + gridTitle,
                    style: {
                        paddingLeft: "0",
                        paddingRight: "0",
                        width: "100%",
                        display: "block"
                    }
                }, [label]);
            };
            /**
             * creates the control title (product name that is selected)
             */
            SuggestionsControl.prototype.createControlTitle = function () {
                var context = SuggestionsControl.context;
                var elem = document.createElement("div");
                elem.style.cssText = "font-size: 20px; font-family: 'SegoeUI', 'Segoe UI'; width: 100%";
                elem.id = "productNameLabel";
                elem.innerHTML = this.ProductName;
                var headerItem = $('[data-id="dialogHeader"]');
                headerItem.append(elem);
            };
            /**
             * creates the error container when no record is selected for adding to list
             */
            SuggestionsControl.prototype.createErrorContainer = function () {
                var headerItem = $('[data-id="dialogHeader"]');
                if (document.getElementById("errorLabel")) {
                    return;
                }
                else {
                    var elem = document.createElement("div");
                    elem.id = "errorLabel";
                    elem.style.cssText = "font-size: 12px; font-family: 'SegoeUI', 'Segoe UI'; color: '#ff0000'; width: 100%";
                    elem.innerHTML = SuggestionsControl.ErrorMessage;
                    headerItem.append(elem);
                }
            };
            /**
             * get the dataset provider for he gridType
             */
            SuggestionsControl.prototype.getDataProvider = function (gridType) {
                var dataSetProvider;
                switch (gridType) {
                    case Suggestions.SuggestionGridType.CROSS_SELL:
                        dataSetProvider = SuggestionsControl.crossSellGridDataSetProvider;
                        break;
                    case Suggestions.SuggestionGridType.UP_SELL:
                        dataSetProvider = SuggestionsControl.upSellGridDataSetProvider;
                        break;
                    case Suggestions.SuggestionGridType.ACCESSORY:
                        dataSetProvider = SuggestionsControl.accessoryGridDataSetProvider;
                        break;
                    case Suggestions.SuggestionGridType.SUBSTITUTE:
                        dataSetProvider = SuggestionsControl.substituteGridDataSetProvider;
                        break;
                }
                return dataSetProvider;
            };
            /**
             * creates the grid of gridType
             */
            SuggestionsControl.prototype.createGrid = function (gridType) {
                var dataSetProvider = this.getDataProvider(gridType);
                dataSetProvider.setColumns(SuggestionsControl.suggestionsGridDataSetProvider.getColumns());
                var properties = {
                    "parameters": {
                        "Grid": {
                            "Primary": true,
                            "DataProvider": dataSetProvider,
                            "ViewId": "",
                            "Columns": dataSetProvider.getColumns(),
                            "onRecordsSelected": dataSetProvider.onRecordSelected.bind(dataSetProvider),
                            "Type": "Grid"
                        },
                        "EnableGroupBy": {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        "EnableFiltering": {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        "EnableEditing": {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        "ReflowBehavior": {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "GridOnly",
                            Primary: false
                        }
                    },
                    key: "SuggestionsGrid_type" + gridType.toString(),
                    id: "SuggestionsGrid_type" + gridType.toString()
                };
                return SuggestionsControl.context.factory.createComponent("MscrmControls.Grid.GridControl", "gridControl" + gridType.toString(), properties);
            };
            /**
             * render the progressindicator
             */
            SuggestionsControl.prototype._renderProgressIndicator = function () {
                //Create progress Indicator Element
                var progressIndicator = SuggestionsControl.context.factory.createElement("PROGRESSINDICATOR", {
                    key: "progressIndicator",
                    id: "progressIndicator",
                    style: {
                        color: "white"
                    },
                    progressType: "ring",
                    active: true
                }, []);
                return progressIndicator;
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            SuggestionsControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                var result = {};
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            SuggestionsControl.prototype.destroy = function () {
                SuggestionsControl.crossSellGridDataSetProvider.setSelectedRecords([]);
                SuggestionsControl.upSellGridDataSetProvider.setSelectedRecords([]);
                SuggestionsControl.accessoryGridDataSetProvider.setSelectedRecords([]);
                SuggestionsControl.substituteGridDataSetProvider.setSelectedRecords([]);
                SuggestionsControl.isDataAvailable = false;
            };
            return SuggestionsControl;
        }());
        /**
         * Input context
         */
        SuggestionsControl.context = null;
        /**
         * is data available
         */
        SuggestionsControl.isDataAvailable = false;
        Suggestions.SuggestionsControl = SuggestionsControl;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SuggestionsControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var MetadataQuery = (function () {
            function MetadataQuery(metadataType, metadataSubType, entityLogicalName) {
                this.MetadataType = null;
                this.MetadataSubtype = null;
                this.EntityLogicalName = null;
                this.MetadataId = null;
                this.MetadataName = null;
                this.GetDefault = true;
                this.DependencyDepth = 2;
                this.ChangedAfter = null;
                this.Exclude = [];
                this.AppId = null;
                if (!metadataType || !metadataSubType) {
                    throw new Error("Can't construct metadata query");
                }
                this.MetadataType = metadataType;
                this.MetadataSubtype = metadataSubType;
                this.EntityLogicalName = entityLogicalName;
            }
            MetadataQuery.prototype.getMetadata = function () {
                return {
                    boundParameter: null,
                    parameterTypes: {
                        "MetadataType": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1
                        },
                        "MetadataSubtype": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1
                        },
                        "EntityLogicalName": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1
                        },
                        "MetadataId": {
                            "typeName": "Edm.Guid",
                            "structuralProperty": 1
                        },
                        "MetadataName": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1
                        },
                        "GetDefault": {
                            "typeName": "Edm.Boolean",
                            "structuralProperty": 1
                        },
                        "DependencyDepth": {
                            "typeName": "Microsoft.Dynamics.CRM.DependencyDepth",
                            "structuralProperty": 3,
                            "enumProperties": [
                                {
                                    "name": "Unknown",
                                    "value": 0
                                },
                                {
                                    "name": "OnDemandWithContext",
                                    "value": 1
                                },
                                {
                                    "name": "OnDemandWithoutContext",
                                    "value": 2
                                },
                                {
                                    "name": "OnDemandContextOnly",
                                    "value": 3
                                },
                                {
                                    "name": "Offline",
                                    "value": 4
                                },
                                {
                                    "name": "Mobile",
                                    "value": 5
                                }
                            ]
                        },
                        "ChangedAfter": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1
                        },
                        "Exclude": {
                            "typeName": "Edm.Guid",
                            "structuralProperty": 4
                        },
                        "AppId": {
                            "typeName": "Edm.Guid",
                            "structuralProperty": 1
                        }
                    },
                    operationName: null,
                    operationType: null
                };
            };
            return MetadataQuery;
        }());
        Suggestions.MetadataQuery = MetadataQuery;
        var GetClientMetadataRequest = (function () {
            function GetClientMetadataRequest(metadataType, metadataSubType, entityLogicalName) {
                this.ClientMetadataQuery = new MetadataQuery(metadataType, metadataSubType, entityLogicalName);
            }
            GetClientMetadataRequest.prototype.getMetadata = function () {
                return {
                    boundParameter: null,
                    parameterTypes: {
                        "ClientMetadataQuery": {
                            "typeName": "Microsoft.Dynamics.CRM.MetadataQuery",
                            "structuralProperty": 2
                        }
                    },
                    operationName: "GetClientMetadata",
                    operationType: 1
                };
            };
            return GetClientMetadataRequest;
        }());
        Suggestions.GetClientMetadataRequest = GetClientMetadataRequest;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var ProductSuggestionsGridDataSetProviderBase = (function () {
            function ProductSuggestionsGridDataSetProviderBase() {
                /**
                 * loading state
                 */
                this._loading = true;
                /**
                 * if error has occured
                 */
                this._error = false;
                /**
                 * error message in case error occured
                 */
                this._errorMessage = "";
                /**
                 * sorting
                 */
                this._sorting = null;
                this._columnNames = ["productid", "uomid", "amount"];
                /**
                 * columns
                 */
                this._columns = [];
                /**
                 * records to be set by child classes
                 */
                this._records = [];
                /**
                 * selected record list
                 */
                this._selectedRecords = [];
            }
            /**
             * is loading?
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.isLoading = function () {
                return this._loading;
            };
            /**
             * if error has occured
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.isError = function () {
                return this._error;
            };
            /**
             * gets the error message in case error occured
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getErrorMessage = function () {
                return this._errorMessage;
            };
            /**
             * set sorting
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.setSorting = function (sorting) {
            };
            /**
             * set filtering
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.setFiltering = function (filtering) {
                this._filtering = filtering;
            };
            /**
             * refresh the data set
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.refresh = function () {
                return window.Promise.resolve(this.getRecords());
            };
            /**
             * get the records that needs to be displayed
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getRecords = function () {
                return this._records;
            };
            /**
             * get the paging data
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getPaging = function () {
                return undefined;
            };
            /**
             * get the columns
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getColumns = function () {
                return this._columns;
            };
            /**
             * save the record
             * @param {Mscrm.DataSetRecord} record
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.save = function (record) {
            };
            /**
             * set the columns
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.setColumns = function (columns) {
                this._columns = columns;
            };
            /**
             * set the records
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.setRecords = function (records) {
                this._records = records;
            };
            /**
             * adds a record
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.addRecord = function (record) {
                this._records.push(record);
            };
            /**
             * Gets the column localized names by fetching entity metadata
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getColumnDisplayNames = function (columnLogicalNames) {
                var metadataSubType = {
                    "productpricelevel": columnLogicalNames
                };
                var request = new Suggestions.GetClientMetadataRequest("entity", JSON.stringify(metadataSubType).replace(/\"/g, '\\"'), null);
                return Suggestions.SuggestionsControl.context.webAPI.execute(request)
                    .then(function (response) { return response.json(); })
                    .then(function (odataResponse) {
                    if (odataResponse && odataResponse.Metadata) {
                        try {
                            var result = JSON.parse(odataResponse.Metadata);
                            var logicalNameToDisplayNameMapping = {};
                            var attributes = result.Entities[0].Attributes;
                            for (var i = 0; i < attributes.length; i++) {
                                logicalNameToDisplayNameMapping[attributes[i].LogicalName] =
                                    (attributes[i].DisplayName.UserLocalizedLabel && attributes[i].DisplayName.UserLocalizedLabel.Label)
                                        || attributes[i].LogicalName;
                            }
                            return window.Promise.resolve(logicalNameToDisplayNameMapping);
                        }
                        catch (err) {
                            return window.Promise.reject(err);
                        }
                    }
                    else {
                        return window.Promise.reject(new Error("odataResponse.Metadata is empty"));
                    }
                });
            };
            /**
             * sets the column records from localized column data
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getColumnData = function () {
                var _this = this;
                return this.getColumnDisplayNames(this._columnNames.map(function (logicalName) { return logicalName.toLowerCase(); }))
                    .then(function (logicalNameToDisplayNameMapping) {
                    _this._columns = _this._columnNames.map(function (value) {
                        return new Suggestions.SuggestionsGridColumn(value, logicalNameToDisplayNameMapping[value.toLowerCase()] || value);
                    });
                });
            };
            /**
             * fetches the records and set the grid records
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.fetchGridRecords = function (productId, priceLevelId) {
                var fetchXml = "<fetch mapping='logical'>	<entity name='productpricelevel'>		<attribute name='uomid' />		<attribute name='productpricelevelid' />		<attribute name='pricelevelid' />		<attribute name='amount' />		<filter>			<condition attribute='pricelevelid' operator='eq' value='" + priceLevelId + "' />		</filter>		<link-entity name='productsubstitute' to='productid' from='substitutedproductid' alias='b' link-type='inner'>			<attribute name='substitutedproductid' />    <attribute name='salesrelationshiptype' />					<filter>						<condition attribute='productid' operator='eq' value='" + productId + "' />					</filter>			<link-entity name='product' to='substitutedproductid' from='productid' alias='c' link-type='inner'>				<filter type='or'>					<filter>					<condition attribute='statecode' operator='eq' value='0' />					</filter>					<filter>					<condition attribute='statecode' operator='eq' value='3' />					</filter>				</filter>			</link-entity>	</link-entity>	</entity></fetch>";
                return this.getData("productpricelevel", fetchXml)
                    .then(function (data) {
                    var entityData = data.entities;
                    console.log(entityData);
                    if (entityData) {
                        for (var i = 0; i < entityData.length; i++) {
                            var salesRelationshipType = entityData[i]["b.salesrelationshiptype"];
                            var productPriceLevelId = entityData[i]["productpricelevelid"];
                            var productName = entityData[i]["b.substitutedproductid@OData.Community.Display.V1.FormattedValue"];
                            var unitName = entityData[i]["_uomid_value@OData.Community.Display.V1.FormattedValue"];
                            var amount = entityData[i]["amount"];
                            var gridRecord = new Suggestions.SuggestionsGridDataRecord(i.toString(), { "productid": productName, "uomid": unitName, "amount": amount, "productPriceLevelId": productPriceLevelId });
                            switch (salesRelationshipType) {
                                case Suggestions.SuggestionGridType.UP_SELL:
                                    Suggestions.SuggestionsControl.upSellGridDataSetProvider.addRecord(gridRecord);
                                    break;
                                case Suggestions.SuggestionGridType.CROSS_SELL:
                                    Suggestions.SuggestionsControl.crossSellGridDataSetProvider.addRecord(gridRecord);
                                    break;
                                case Suggestions.SuggestionGridType.ACCESSORY:
                                    Suggestions.SuggestionsControl.accessoryGridDataSetProvider.addRecord(gridRecord);
                                    break;
                                case Suggestions.SuggestionGridType.SUBSTITUTE:
                                    Suggestions.SuggestionsControl.substituteGridDataSetProvider.addRecord(gridRecord);
                                    break;
                            }
                        }
                        Suggestions.SuggestionsControl.upSellGridDataSetProvider._loading = false;
                        Suggestions.SuggestionsControl.crossSellGridDataSetProvider._loading = false;
                        Suggestions.SuggestionsControl.accessoryGridDataSetProvider._loading = false;
                        Suggestions.SuggestionsControl.substituteGridDataSetProvider._loading = false;
                    }
                });
            };
            /**
             * gets the data using fetchxml
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getData = function (entity, fetchxml) {
                var _window = window;
                var data = Suggestions.SuggestionsControl.context.webAPI.retrieveMultipleRecords(entity, "?fetchXml=" + fetchxml);
                return data;
            };
            /**
             * get Suggestion Grid Columns and Records
             * @returns the datasetrecords
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getSuggestionGridData = function (productId, priceLevelId) {
                return Promise.all([
                    this.fetchGridRecords(productId, priceLevelId),
                    this.getColumnData()
                ])
                    .then(function (results) {
                    return results[0];
                });
            };
            /**
            * Callback method for recordselection
            * @params {string[]} rowIds The record selected by the user.
            */
            ProductSuggestionsGridDataSetProviderBase.prototype.onRecordSelected = function (rowIds) {
                var records = this.getRecords();
                this._selectedRecords = [];
                var headerItem = $('[data-id="dialogHeader"]');
                if (rowIds.length > 0) {
                    if (document.getElementById("errorLabel")) {
                        document.getElementById("errorLabel").remove();
                    }
                    for (var i = 0; i < rowIds.length; i++) {
                        var selectedRecord = records.find(function (item) { return item.getRecordId() === rowIds[i]; });
                        this._selectedRecords.push(selectedRecord._record["productPriceLevelId"]);
                    }
                }
            };
            /**
            * gets the selected records
            */
            ProductSuggestionsGridDataSetProviderBase.prototype.getSelectedRecords = function () {
                return this._selectedRecords;
            };
            /**
             * sets the selected records
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.setSelectedRecords = function (records) {
                this._selectedRecords = records;
            };
            /**
             * Gets grid title, to be overwritten by child classes.
             */
            ProductSuggestionsGridDataSetProviderBase.prototype.getTitle = function () {
                return "";
            };
            return ProductSuggestionsGridDataSetProviderBase;
        }());
        Suggestions.ProductSuggestionsGridDataSetProviderBase = ProductSuggestionsGridDataSetProviderBase;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var AccessoryGridDataSetProvider = (function (_super) {
            __extends(AccessoryGridDataSetProvider, _super);
            function AccessoryGridDataSetProvider() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            AccessoryGridDataSetProvider.prototype.getTitle = function () {
                var context = Suggestions.SuggestionsControl.context;
                return context.resources.getString(Suggestions.LOC_KEYS.GRID_TITLE_ACCESSORY);
            };
            return AccessoryGridDataSetProvider;
        }(Suggestions.ProductSuggestionsGridDataSetProviderBase));
        Suggestions.AccessoryGridDataSetProvider = AccessoryGridDataSetProvider;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var CrossSellGridDataSetProvider = (function (_super) {
            __extends(CrossSellGridDataSetProvider, _super);
            function CrossSellGridDataSetProvider() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            CrossSellGridDataSetProvider.prototype.getTitle = function () {
                var context = Suggestions.SuggestionsControl.context;
                return context.resources.getString(Suggestions.LOC_KEYS.GRID_TITLE_CROSS_SELL);
            };
            return CrossSellGridDataSetProvider;
        }(Suggestions.ProductSuggestionsGridDataSetProviderBase));
        Suggestions.CrossSellGridDataSetProvider = CrossSellGridDataSetProvider;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var SubstituteGridDataSetProvider = (function (_super) {
            __extends(SubstituteGridDataSetProvider, _super);
            function SubstituteGridDataSetProvider() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            SubstituteGridDataSetProvider.prototype.getTitle = function () {
                var context = Suggestions.SuggestionsControl.context;
                return context.resources.getString(Suggestions.LOC_KEYS.GRID_TITLE_SUBSTITUTE);
            };
            return SubstituteGridDataSetProvider;
        }(Suggestions.ProductSuggestionsGridDataSetProviderBase));
        Suggestions.SubstituteGridDataSetProvider = SubstituteGridDataSetProvider;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        /**
         * switch process column
         */
        var SuggestionsGridColumn = (function () {
            /**
             * constructor
             * @param {string} name name
             * @param {string} displayName display name
             */
            function SuggestionsGridColumn(name, displayName) {
                /**
                 * The data type of this column's values.
                 */
                this.dataType = "SingleLine.Text";
                /**
                 * The configured size factor for this column relative to other columns in the data set.
                 * By default columns have a size factor of 1.0, but the system customizer or user can
                 * make some columns larger (e.g., 1.5) or smaller (e.g., 0.75).
                 */
                this.visualSizeFactor = 50;
                /**
                * Identifies if the column is hidden or not.
                */
                this.isHidden = false;
                /**
                * The column order for the layout.
                */
                this.order = 1;
                /**
                * The attributes of the columns.
                */
                this.attributes = {
                    maxLength: 200,
                    "type": "SingleLine.Text",
                    format: "Text"
                };
                /**
                * Identifies if sorting is unavailable for the column.
                */
                this.disableSorting = false;
                this.name = name;
                this.displayName = displayName;
            }
            Object.defineProperty(SuggestionsGridColumn.prototype, "alias", {
                /**
                * The alias of this column.
                */
                get: function () {
                    return "name";
                },
                enumerable: true,
                configurable: true
            });
            return SuggestionsGridColumn;
        }());
        Suggestions.SuggestionsGridColumn = SuggestionsGridColumn;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var SuggestionsGridDataRecord = (function () {
            /**
             * constructor
             * @param id the id
             * @param record the record
             */
            function SuggestionsGridDataRecord(id, record) {
                /**
                 * grid record {column name:column value}
                 */
                this._record = {};
                this._id = id;
                this._record = record;
            }
            /**
             * gets the record id
             */
            SuggestionsGridDataRecord.prototype.getRecordId = function () {
                return this._id;
            };
            /**
             * returns the error message
             * @returns the error message
             */
            SuggestionsGridDataRecord.prototype.getErrorMessage = function () {
                return null;
            };
            /**
             * is Dirty?
             * @returns is dirty?
             */
            SuggestionsGridDataRecord.prototype.isDirty = function () {
                return false;
            };
            /**
             * is record valid?
             * @returns whether the record is valid?
             */
            SuggestionsGridDataRecord.prototype.isRecordValid = function () {
                return true;
            };
            /**
             * gets the notification
             * @param {string} columnName the column name
             * @returns notification for column
             */
            SuggestionsGridDataRecord.prototype.getNotification = function (columnName) {
                return null;
            };
            /**
             * get value of a column
             * @param {string} columnName the column name
             * @returns te value for that column
             */
            SuggestionsGridDataRecord.prototype.getValue = function (columnName) {
                return this._record[columnName];
            };
            /**
             * sets the value for a column
             * @param {string} columnName the column name
             * @param {any} newValue the new value for the column
             */
            SuggestionsGridDataRecord.prototype.setValue = function (columnName, newValue) {
                return this._record[columnName] = newValue;
            };
            /**
             * gets the formatted value for a column
             * @param {string} columnName the column name
             * @returns the formatted value
             */
            SuggestionsGridDataRecord.prototype.getFormattedValue = function (columnName) {
                return this._record[columnName];
            };
            /**
             * is Editable?
             * @param {string} columnName the column name
             * @returns whether the columns is editable
             */
            SuggestionsGridDataRecord.prototype.isEditable = function (columnName) {
                return window.Promise.resolve(false);
            };
            /**
             * is secured?
             * @param {string} columnName the column name
             * @returns whether the columns is secured
             */
            SuggestionsGridDataRecord.prototype.isSecured = function (columnName) {
                return window.Promise.resolve(true);
            };
            /**
             * is readable?
             * @param {string} columnName the column name
             * @returns whether the columns is readable
             */
            SuggestionsGridDataRecord.prototype.isReadable = function (columnName) {
                return window.Promise.resolve(true);
            };
            /**
             * is Valid
             * @param {string} columnName the column name
             * @returns if the column is valid
             */
            SuggestionsGridDataRecord.prototype.isValid = function (columnName) {
                return true;
            };
            /**
             * get field required level
             * @param {string} columnName the column name
             * @returns the required level
             */
            SuggestionsGridDataRecord.prototype.getFieldRequiredLevel = function (columnName) {
                return window.Promise.resolve(0 /* None */);
            };
            /**
             * returns the attributes
             * @param {Mscrm.DataSetColumn} column the column
             * @returns the attributes
             */
            SuggestionsGridDataRecord.prototype.getAttributes = function (column) {
                return null;
            };
            SuggestionsGridDataRecord.prototype.getValidator = function (column) {
                return null;
            };
            /**
             * returns the named reference
             * @returns the named reference
             */
            SuggestionsGridDataRecord.prototype.getNamedReference = function () {
                var _this = this;
                return {
                    Id: {
                        guid: this._id,
                        toString: function () { return _this._id; }
                    },
                    Name: null,
                    LogicalName: null
                };
            };
            /**
             * returns the activity party record
             * @returns the activity party record
             */
            SuggestionsGridDataRecord.prototype.getActivityPartyRecord = function () {
                return null;
            };
            /**
             *  validates all columns
             */
            SuggestionsGridDataRecord.prototype.validateAllColumns = function () {
                return null;
            };
            /**
             * Save record.
             */
            SuggestionsGridDataRecord.prototype.save = function () {
                return null;
            };
            return SuggestionsGridDataRecord;
        }());
        Suggestions.SuggestionsGridDataRecord = SuggestionsGridDataRecord;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        /**
         * Suggestions Grid Data Set Column Validator
         */
        var SuggestionsGridDataSetColumnValidator = (function () {
            function SuggestionsGridDataSetColumnValidator() {
            }
            /**
             * validator
             * @param {any} value the value
             * @param {boolean} isValueChanging is value changing
             * @param {boolean} isDisabled is disabled
             * @returns validation result
             */
            SuggestionsGridDataSetColumnValidator.prototype.validate = function (value, isValueChanging, isDisabled) {
                return new Suggestions.SuggestionsGridDataSetValidationResult("", true);
            };
            return SuggestionsGridDataSetColumnValidator;
        }());
        Suggestions.SuggestionsGridDataSetColumnValidator = SuggestionsGridDataSetColumnValidator;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var SuggestionGridType = (function () {
            function SuggestionGridType() {
            }
            return SuggestionGridType;
        }());
        SuggestionGridType.UP_SELL = 0;
        SuggestionGridType.CROSS_SELL = 1;
        SuggestionGridType.ACCESSORY = 2;
        SuggestionGridType.SUBSTITUTE = 3;
        Suggestions.SuggestionGridType = SuggestionGridType;
        var SuggestionsGridDataSetFactory = (function () {
            function SuggestionsGridDataSetFactory() {
            }
            SuggestionsGridDataSetFactory.Create = function (gridType) {
                switch (gridType) {
                    case SuggestionGridType.UP_SELL: return new Suggestions.UpSellGridDataSetProvider();
                    case SuggestionGridType.CROSS_SELL: return new Suggestions.CrossSellGridDataSetProvider();
                    case SuggestionGridType.ACCESSORY: return new Suggestions.AccessoryGridDataSetProvider();
                    case SuggestionGridType.SUBSTITUTE: return new Suggestions.SubstituteGridDataSetProvider();
                }
            };
            return SuggestionsGridDataSetFactory;
        }());
        Suggestions.SuggestionsGridDataSetFactory = SuggestionsGridDataSetFactory;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        /**
         * SuggestionControl validation result
         */
        var SuggestionsGridDataSetValidationResult = (function () {
            /**
             * constructor
             * @param {string} errorMessage the error message
             * @param {boolean} isValid is valid
             */
            function SuggestionsGridDataSetValidationResult(errorMessage, isValid) {
                this.errorMessage = errorMessage;
                this.isValid = isValid;
            }
            return SuggestionsGridDataSetValidationResult;
        }());
        Suggestions.SuggestionsGridDataSetValidationResult = SuggestionsGridDataSetValidationResult;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var Suggestions;
    (function (Suggestions) {
        'use strict';
        var UpSellGridDataSetProvider = (function (_super) {
            __extends(UpSellGridDataSetProvider, _super);
            function UpSellGridDataSetProvider() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            UpSellGridDataSetProvider.prototype.getTitle = function () {
                var context = Suggestions.SuggestionsControl.context;
                return context.resources.getString(Suggestions.LOC_KEYS.GRID_TITLE_UP_SELL);
            };
            return UpSellGridDataSetProvider;
        }(Suggestions.ProductSuggestionsGridDataSetProviderBase));
        Suggestions.UpSellGridDataSetProvider = UpSellGridDataSetProvider;
    })(Suggestions = MscrmControls.Suggestions || (MscrmControls.Suggestions = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SuggestionsControl.js.map