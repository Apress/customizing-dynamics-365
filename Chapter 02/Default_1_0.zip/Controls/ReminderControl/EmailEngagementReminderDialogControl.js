/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrmcomponents.d.ts" />
/// <reference path="../../../../jsreferences/external/TypeDefinitions/jquery.d.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/lib.es6.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EmailReminderControl;
    (function (EmailReminderControl) {
        'use strict';
        var ReminderControl = (function () {
            /**
             * constructor to handle Date and Text changes.
             */
            function ReminderControl() {
                this._changeTextHandler = this._onTextChange.bind(this);
                this._changeDateHandler = this._onDateChange.bind(this);
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            ReminderControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                this._id_lastButtonClicked = this._context.parameters.id_lastButtonClicked.raw;
                this._id_reminderDateSelected = this._context.parameters.id_reminderDateSelected.raw;
                this._id_reminderOptionSelected = isNaN(this._context.parameters.id_reminderOptionSelected.raw) ? 0 : this._context.parameters.id_reminderOptionSelected.raw;
                this._id_reminderTextSelected = this._context.parameters.id_reminderTextSelected.raw;
                this._id_dateErrorText = this._context.parameters.id_dateErrorText.raw;
                this._id_recipientName = this._context.parameters.id_recipientName.raw;
                this._id_footerTextOption1_single_recipient = this._context.parameters.id_footerTextOption1_single_recipient.raw;
                this._id_footerTextOption1_ignore_recipient = this._context.parameters.id_footerTextOption1_ignore_recipient.raw;
                this._id_footerTextOption2_single_recipient = this._context.parameters.id_footerTextOption2_single_recipient.raw;
                this._id_footerTextOption2_ignore_recipient = this._context.parameters.id_footerTextOption2_ignore_recipient.raw;
                this._id_footerTextOption3 = this._context.parameters.id_footerTextOption3.raw;
                this._id_invalidChoice = this._context.parameters.id_invalidChoice.raw;
                this._id_isEmailFollowedValue = this._context.parameters.id_isEmailFollowedValue.raw;
                this._id_now = this._context.parameters.id_now.raw;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            ReminderControl.prototype.updateView = function (context) {
                // custom code goes here
                var controls = [];
                controls.push(this.reminderOptionsComponent());
                controls.push(this.createDateTimeComponent());
                controls.push(this.createTextComponent());
                controls.push(this.createFooterComponent());
                return this.createContainerWithControls(controls, "completePage");
            };
            /**
              * Generates container element for passed array with controls
              * @param controls - array with elements which are need to be wrapped
              * @param containerSuffix - suffix for the container id and key
              * @returns container element with passed controls
              */
            ReminderControl.prototype.createContainerWithControls = function (controls, containerSuffix) {
                return this._context.factory.createElement("CONTAINER", {
                    key: "containerWithControls" + containerSuffix,
                    id: "containerWithControls" + containerSuffix,
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%"
                    }
                }, controls);
            };
            /**
             * This function will create the reminder options component
             */
            ReminderControl.prototype.reminderOptionsComponent = function () {
                var condition_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_Condition_Label");
                var infoIcon = this._context.factory.createElement('MICROSOFTICON', {
                    key: 'Condition_requiredIcon',
                    id: 'Condition_requiredIcon',
                    type: 181,
                    accessibilityHidden: true
                });
                var infoIconWrapper = this._context.factory.createElement('CONTAINER', {
                    key: 'condition_icon_wrapper',
                    id: 'condition_icon_wrapper',
                    style: {
                        padding: "5px",
                        width: "20px",
                        color: "#ff0000"
                    }
                }, infoIcon);
                var headerLabel = this._context.factory.createElement("LABEL", {
                    id: "contition_label",
                    key: "contition_label",
                    accessibilityLabel: condition_Label,
                    title: condition_Label,
                    style: {
                        fontSize: "16px",
                        width: "8rem",
                        alignItems: "center",
                        flexGrow: "0",
                        overflow: "hidden"
                    }
                }, condition_Label);
                var options = this._createFieldsSelectorList();
                var fieldsTypeToRenderSelector = this._context.factory.createElement("SELECT", {
                    key: 'fieldsTypeToRenderSelector_container',
                    id: "fieldsTypeToRenderSelector_container",
                    title: "Options",
                    onChange: this._reminderOptionsOnChangeHandler.bind(this),
                    value: options[this._id_reminderOptionSelected],
                    disabled: false,
                    options: options,
                    accessibilityRequired: true,
                    labelledByElementId: this._context.accessibility.getUniqueId("contition_label"),
                    style: this.selectStyle()
                }, this._context.resources.getString("CustomControl_EmailEngagementReminder_Reminder_Options"));
                return this._context.factory.createElement("CONTAINER", {
                    key: "fieldsTypeToRenderSelectorHeaderCell",
                    id: "fieldsTypeToRenderSelectorHeaderCell",
                    title: "Reminder Options",
                    style: {
                        justifyContent: "space-between",
                        display: "flex",
                        alignItems: "center",
                        paddingBottom: this._context.theming.measures.measure075,
                        borderBottom: this._context.theming.borders.border02
                    }
                }, [infoIconWrapper, headerLabel, fieldsTypeToRenderSelector]);
            };
            /**
             * This function will handle reminder option value changes
             */
            ReminderControl.prototype._reminderOptionsOnChangeHandler = function (renderedFieldsTypeOption) {
                var tempOptionSelected = this._id_reminderOptionSelected;
                this._id_reminderOptionSelected = renderedFieldsTypeOption.Value;
                if (!this._id_isEmailFollowedValue && (this._id_reminderOptionSelected == 0 || this._id_reminderOptionSelected == 1)) {
                    this._context.navigation.openAlertDialog({
                        text: this._id_invalidChoice
                    });
                    return;
                }
                this._context.utils.requestRender();
                if (tempOptionSelected !== renderedFieldsTypeOption.Value) {
                    this._notifyOutputChanged();
                }
            };
            /**
             * This function will create styles for SELECT dropdown
             */
            ReminderControl.prototype.selectStyle = function () {
                var _a = this._context.theming, noneborderstyle = _a.noneborderstyle, textbox = _a.textbox;
                var backgroundColor = textbox.backgroundcolor;
                var color = textbox.contentcolor;
                var selectStyle = {
                    appearance: "none",
                    width: "100%",
                    height: "2.5rem",
                    paddingTop: textbox.verticalpadding,
                    paddingBottom: textbox.verticalpadding,
                    paddingLeft: textbox.horizontalpadding,
                    paddingRight: textbox.horizontalpadding,
                    fontSize: textbox.fontsize,
                    fontWeight: textbox.fontweight,
                    boxShadow: "0 0 0 1px #cccccc inset",
                    backgroundColor: this._context.theming.colors.whitebackground,
                    color: color
                };
                var optionStyle = {
                    backgroundColor: backgroundColor,
                    color: color
                };
                return {
                    selectStyle: selectStyle,
                    optionStyle: optionStyle
                };
            };
            /**
             * This function will create footer component
             */
            ReminderControl.prototype.createFooterComponent = function () {
                var reminder_Time = this._id_reminderDateSelected.localeFormat(this._context.client.dateFormattingInfo.ShortTimePattern.toString());
                var reminder_Date = this._id_reminderDateSelected.localeFormat(this._context.client.dateFormattingInfo.ShortDatePattern.toString());
                var reminder_Date_Text = reminder_Date + " " + reminder_Time;
                if (this._id_recipientName && this._id_reminderOptionSelected === 0) {
                    this._footer_complete_Text = MscrmCommon.ControlUtils.String.Format(this._id_footerTextOption1_single_recipient, this._id_recipientName, reminder_Date_Text);
                }
                else if ((this._id_recipientName === "") && this._id_reminderOptionSelected === 0) {
                    this._footer_complete_Text = MscrmCommon.ControlUtils.String.Format(this._id_footerTextOption1_ignore_recipient, reminder_Date_Text);
                }
                else if (this._id_recipientName && this._id_reminderOptionSelected === 1) {
                    this._footer_complete_Text = MscrmCommon.ControlUtils.String.Format(this._id_footerTextOption2_single_recipient, this._id_recipientName, reminder_Date_Text);
                }
                else if ((this._id_recipientName === "") && this._id_reminderOptionSelected === 1) {
                    this._footer_complete_Text = MscrmCommon.ControlUtils.String.Format(this._id_footerTextOption2_ignore_recipient, reminder_Date_Text);
                }
                else {
                    this._footer_complete_Text = MscrmCommon.ControlUtils.String.Format(this._id_footerTextOption3, reminder_Date_Text);
                }
                var footer_Label_Info = this._footer_complete_Text;
                var footerLabel = this._context.factory.createElement("LABEL", {
                    id: "footer_label",
                    key: "footer_label",
                    accessibilityLabel: footer_Label_Info
                }, footer_Label_Info);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_footer_container",
                    id: "reminder_footer_container",
                    style: {
                        paddingTop: this._context.theming.measures.measure075
                    }
                }, footerLabel);
            };
            /**
             * This function will create the comment text component
             */
            ReminderControl.prototype.createTextComponent = function () {
                var _this = this;
                var textComponentLabel = this._context.resources.getString("CustomControl_EmailEngagementReminder_Comment_Label");
                var inputText = this._id_reminderTextSelected;
                var textLabel = this._context.factory.createElement("LABEL", {
                    id: "reminder_comment_label",
                    key: "reminder_comment_label",
                    accessibilityLabel: textComponentLabel,
                    style: {
                        fontSize: "16px",
                        width: "8rem",
                        paddingLeft: "25px",
                        alignItems: "center",
                        flexGrow: "0",
                        overflow: "hidden"
                    }
                }, textComponentLabel);
                var properties = {
                    "parameters": {
                        "value": {
                            Usage: 3 /*PropertyUsage.FalseBound*/,
                            Static: true,
                            Value: inputText,
                            Type: "SingleLine.Text",
                            Callback: function (change) { return _this._changeTextHandler(textComponentLabel, change); },
                            Attributes: {
                                Format: "text",
                                Type: "text"
                            }
                        },
                        "deviceSizeMode": {
                            Usage: 1,
                            Static: true,
                            Value: 0,
                            Type: "Enum",
                            Primary: false
                        },
                        "describedByElementId": {
                            Usage: 1,
                            Value: this._context.accessibility.getUniqueId("reminder_comment_label"),
                            Static: true
                        }
                    },
                    style: {
                        fontFamilies: this._context.theming.fontfamilies.regular,
                        fonstSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray07
                    }
                };
                var textComponent = this._context.factory.createComponent("MscrmControls.FieldControls.TextBoxControl", "Start_Text_MDD", properties);
                return this._context.factory.createElement("CONTAINER", {
                    key: "reminder_text_Container",
                    id: "reminder_text_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingTop: this._context.theming.measures.measure075,
                        borderBottom: this._context.theming.borders.border02
                    }
                }, [textLabel, textComponent]);
            };
            /**
             * This function will create a reminder date time component
             */
            ReminderControl.prototype.createDateTimeComponent = function () {
                var _this = this;
                var typeString = this._context.resources.getString("CustomControl_EmailEngagementReminder_Start_Date_Label");
                var inputDate = this._id_reminderDateSelected;
                var send_By_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_Remind_By_Label");
                var dateLabel = this._context.factory.createElement("LABEL", {
                    id: "send_label",
                    key: "send_label",
                    accessibilityLabel: send_By_Label,
                    style: {
                        fontSize: "16px",
                        width: "8rem",
                        alignItems: "center",
                        flexGrow: "0",
                        overflow: "hidden"
                    }
                }, send_By_Label);
                var properties = {
                    "parameters": {
                        "value": {
                            Usage: 3 /*PropertyUsage.FalseBound*/,
                            Static: true,
                            Value: inputDate,
                            Type: "DateAndTime.DateAndTime",
                            Callback: function (change) { return _this._changeDateHandler(typeString, change); },
                            Attributes: {
                                Format: "datetime",
                                Type: "datetime",
                                Behavior: 1,
                                RequiredLevel: 1
                            }
                        },
                        "deviceSizeMode": {
                            Usage: 1,
                            Static: true,
                            Value: 0,
                            Type: "Enum",
                            Primary: false
                        },
                        "describedByElementId": {
                            Usage: 1,
                            Value: this._context.accessibility.getUniqueId("send_label"),
                            Static: true
                        }
                    },
                    style: {
                        fontFamilies: this._context.theming.fontfamilies.regular,
                        fonstSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray07,
                        width: "100%"
                    }
                };
                var dateComponent = this._context.factory.createComponent("MscrmControls.FieldControls.DateTimeControl", this._context.resources.getString("CustomControl_EmailEngagementReminder_CustomControl_EmailEngagementReminder_Date_Component_ID"), properties);
                var infoIcon = this._context.factory.createElement('MICROSOFTICON', {
                    key: 'date_requiredIcon',
                    id: 'date_requiredIcon',
                    type: 181,
                    accessibilityHidden: true
                });
                var infoIconWrapper = this._context.factory.createElement('CONTAINER', {
                    key: 'date_icon_wrapper',
                    id: 'date_icon_wrapper',
                    style: {
                        padding: "5px",
                        width: "20px",
                        color: "#ff0000"
                    }
                }, infoIcon);
                return this._context.factory.createElement("CONTAINER", {
                    key: "date_time_Container",
                    id: "date_time_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        alignItems: "center",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingTop: this._context.theming.measures.measure075,
                        borderBottom: this._context.theming.borders.border02
                    }
                }, [infoIconWrapper, dateLabel, dateComponent]);
            };
            /**
              * Handles a change of a value
              * @params event The change event
              * @private
              */
            ReminderControl.prototype._onTextChange = function (type, change) {
                var controlValue = change ? change : null;
                this._id_reminderTextSelected = controlValue;
                this._context.utils.requestRender();
                this._notifyOutputChanged();
            };
            /**
             * Handles a change of a inout data for the date control
             * @param change change event object wrapper.
             * @param type Start date vs End Date.
             */
            ReminderControl.prototype._onDateChange = function (type, change) {
                var controlValue = change ? change : null;
                this._id_reminderDateSelected = controlValue;
                this._context.utils.requestRender();
                this._notifyOutputChanged();
            };
            /**
             * This function return option values for SELECT dropdown
             */
            ReminderControl.prototype._createOption = function (label, text, value) {
                return { text: text, Label: label, Value: value, Color: "" };
            };
            /**
             * This function will create option fields for the SELECT Dropdown
             */
            ReminderControl.prototype._createFieldsSelectorList = function () {
                var fieldstypeToRenderOptions = [];
                var commentOption1_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_commentOption1_Label");
                var commentOption2_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_commentOption2_Label");
                var commentOption3_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_commentOption3_Label");
                var Option1_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_Option1_Label");
                var Option2_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_Option2_Label");
                var Option3_Label = this._context.resources.getString("CustomControl_EmailEngagementReminder_Option3_Label");
                fieldstypeToRenderOptions = fieldstypeToRenderOptions.concat(this._createOption(commentOption1_Label, Option1_Label, 0));
                fieldstypeToRenderOptions = fieldstypeToRenderOptions.concat(this._createOption(commentOption2_Label, Option2_Label, 1));
                fieldstypeToRenderOptions = fieldstypeToRenderOptions.concat(this._createOption(commentOption3_Label, Option3_Label, 2));
                return fieldstypeToRenderOptions;
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            ReminderControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                var result = {
                    id_lastButtonClicked: this._id_lastButtonClicked,
                    id_reminderDateSelected: this._id_reminderDateSelected,
                    id_reminderOptionSelected: this._id_reminderOptionSelected,
                    id_reminderTextSelected: this._id_reminderTextSelected,
                    id_now: this._id_now
                };
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            ReminderControl.prototype.destroy = function () {
            };
            return ReminderControl;
        }());
        EmailReminderControl.ReminderControl = ReminderControl;
    })(EmailReminderControl = MscrmControls.EmailReminderControl || (MscrmControls.EmailReminderControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="EmailReminderControl.ts" /> 
