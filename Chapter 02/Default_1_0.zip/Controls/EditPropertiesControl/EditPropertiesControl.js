var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="./references/mscrm.d.ts" />
/// <reference path="./references/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../TypeDefinitions/lib.es6.d.ts" />
/// <reference path="../../../../../Packages/Crm.ClientApiTypings.1.0.839/clientapi/XrmClientApi.d.ts" />
/// <reference path="../../../../../Packages/Crm.ClientApiTypings.1.0.839/clientapi/XrmClientApiDeprecated.d.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/microsoft.ajax.d.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/whatwg-fetch.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        'use strict';
        EditProperties.LOC_KEYS = {
            OPTION_SET_EMPTY_OPTION: "CC_ChooseAValue",
            REQUIRED_VALIDATION_MESSAGE: "CC_RequiredValidationMessage",
            NUMBER_VALIDATION_MESSAGE: "CC_NumberValidationMessage",
            DECIMAL_VALIDATION_MESSAGE: "CC_DecimalValidationMessage",
            DOUBLE_VALIDATION_MESSAGE: "CC_DoubleValidationMessage",
            STRING_VALIDATION_MESSAGE: "CC_StringValidationMessage",
            OPTION_YES: "CC_OptionYes",
            OPTION_NO: "CC_OptionNo",
            PROPERTY_NAME: "CC_BundleHeaderPropertyName",
            DEFAULT_VALUE: "CC_BundleHeaderDefaultValue",
            EDITABLE: "CC_BundleHeaderEditable"
        };
        EditProperties.OPTION_SET_DEFAULT_OPTION_VALUE = "-1";
        var ValidationFactory = (function () {
            function ValidationFactory() {
            }
            ValidationFactory.getValidationObject = function (prop) {
                var validationObject;
                switch (prop.dataType) {
                    case EditProperties.DynamicPropertyDataType.Decimal:
                        validationObject = new DecimalValidationObject(prop);
                        break;
                    case EditProperties.DynamicPropertyDataType.Double:
                        validationObject = new DoubleValidationObject(prop);
                        break;
                    case EditProperties.DynamicPropertyDataType.WholeNumber:
                        validationObject = new NumberValidationObject(prop);
                        break;
                    case EditProperties.DynamicPropertyDataType.String:
                        validationObject = new StringValidationObject(prop);
                        break;
                    case EditProperties.DynamicPropertyDataType.OptionSet:
                        validationObject = new OptionSetValidationObject(prop);
                        break;
                }
                if (!validationObject) {
                    validationObject = new StringValidationObject(prop);
                }
                return validationObject;
            };
            return ValidationFactory;
        }());
        EditProperties.ValidationFactory = ValidationFactory;
        // Interface for validation object
        var ValidationObjectBase = (function () {
            function ValidationObjectBase(prop) {
                this.prop = prop;
            }
            ValidationObjectBase.prototype.emptyValidationPass = function () {
                this.updatedValStr = this.prop.getUpdatedValue();
                if (!this.prop.isRequired && this.updatedValStr == "") {
                    return true;
                }
                return false;
            };
            ValidationObjectBase.prototype.isEmptyAndRequired = function () {
                this.updatedValStr = this.prop.getUpdatedValue();
                if (this.prop.isRequired && this.updatedValStr == "") {
                    this.showIsRequiredValidationMsg = true;
                    return true;
                }
                this.showIsRequiredValidationMsg = false;
            };
            return ValidationObjectBase;
        }());
        var OptionSetValidationObject = (function (_super) {
            __extends(OptionSetValidationObject, _super);
            function OptionSetValidationObject(prop) {
                var _this = _super.call(this, prop) || this;
                _this.prop = prop;
                return _this;
            }
            OptionSetValidationObject.prototype.validate = function () {
                if (this.prop.isRequired && this.prop.getUpdatedValue() == EditProperties.OPTION_SET_DEFAULT_OPTION_VALUE) {
                    this.showIsRequiredValidationMsg = true;
                    this.prop.showValidationMessage();
                    return false;
                }
                this.showIsRequiredValidationMsg = false;
                this.prop.hideValidationMessage();
                return true;
            };
            OptionSetValidationObject.prototype.getValidationMessage = function () {
                if (this.showIsRequiredValidationMsg) {
                    return this.prop.context.resources.getString(EditProperties.LOC_KEYS.REQUIRED_VALIDATION_MESSAGE);
                }
                return "";
            };
            return OptionSetValidationObject;
        }(ValidationObjectBase));
        var NumberValidationObject = (function (_super) {
            __extends(NumberValidationObject, _super);
            function NumberValidationObject(prop) {
                var _this = _super.call(this, prop) || this;
                _this.prop = prop;
                return _this;
            }
            NumberValidationObject.prototype.validate = function () {
                var result = true;
                if (this.emptyValidationPass()) {
                    this.prop.hideValidationMessage();
                    return true;
                }
                if (this.isEmptyAndRequired()) {
                    this.prop.showValidationMessage();
                    return false;
                }
                var updatedValue = Number(this.updatedValStr);
                if (isNaN(updatedValue) || updatedValue < this.prop.minValueInteger || updatedValue > this.prop.maxValueInteger) {
                    result = false;
                    this.prop.showValidationMessage();
                }
                else {
                    this.prop.hideValidationMessage();
                }
                return result;
            };
            NumberValidationObject.prototype.getValidationMessage = function () {
                if (this.showIsRequiredValidationMsg) {
                    return this.prop.context.resources.getString(EditProperties.LOC_KEYS.REQUIRED_VALIDATION_MESSAGE);
                }
                var validationTemplate = this.prop.context.resources.getString(EditProperties.LOC_KEYS.NUMBER_VALIDATION_MESSAGE);
                return MscrmCommon.ControlUtils.String.Format(validationTemplate, this.prop.minValueInteger, this.prop.maxValueInteger);
            };
            return NumberValidationObject;
        }(ValidationObjectBase));
        var DecimalValidationObject = (function (_super) {
            __extends(DecimalValidationObject, _super);
            function DecimalValidationObject(prop) {
                var _this = _super.call(this, prop) || this;
                _this.prop = prop;
                return _this;
            }
            DecimalValidationObject.prototype.validate = function () {
                var result = true;
                if (this.emptyValidationPass()) {
                    this.prop.hideValidationMessage();
                    return true;
                }
                if (this.isEmptyAndRequired()) {
                    this.prop.showValidationMessage();
                    return false;
                }
                var updatedValue = Number(this.updatedValStr);
                if (isNaN(updatedValue) || updatedValue < this.prop.minValueDecimal || updatedValue > this.prop.maxValueDecimal) {
                    result = false;
                    this.prop.showValidationMessage();
                }
                else {
                    this.prop.hideValidationMessage();
                }
                return result;
            };
            DecimalValidationObject.prototype.getValidationMessage = function () {
                if (this.showIsRequiredValidationMsg) {
                    return this.prop.context.resources.getString(EditProperties.LOC_KEYS.REQUIRED_VALIDATION_MESSAGE);
                }
                var validationTemplate = this.prop.context.resources.getString(EditProperties.LOC_KEYS.DECIMAL_VALIDATION_MESSAGE);
                return MscrmCommon.ControlUtils.String.Format(validationTemplate, this.prop.minValueDecimal, this.prop.maxValueDecimal);
            };
            return DecimalValidationObject;
        }(ValidationObjectBase));
        var DoubleValidationObject = (function (_super) {
            __extends(DoubleValidationObject, _super);
            function DoubleValidationObject(prop) {
                var _this = _super.call(this, prop) || this;
                _this.prop = prop;
                return _this;
            }
            DoubleValidationObject.prototype.validate = function () {
                var result = true;
                if (this.emptyValidationPass()) {
                    this.prop.hideValidationMessage();
                    return true;
                }
                if (this.isEmptyAndRequired()) {
                    this.prop.showValidationMessage();
                    return false;
                }
                var updatedValue = Number(this.updatedValStr);
                if (isNaN(updatedValue) || updatedValue < this.prop.minValueDouble || updatedValue > this.prop.maxValueDouble) {
                    result = false;
                    this.prop.showValidationMessage();
                }
                else {
                    this.prop.hideValidationMessage();
                }
                return result;
            };
            DoubleValidationObject.prototype.getValidationMessage = function () {
                if (this.showIsRequiredValidationMsg) {
                    return this.prop.context.resources.getString(EditProperties.LOC_KEYS.REQUIRED_VALIDATION_MESSAGE);
                }
                var validationTemplate = this.prop.context.resources.getString(EditProperties.LOC_KEYS.DOUBLE_VALIDATION_MESSAGE);
                return MscrmCommon.ControlUtils.String.Format(validationTemplate, this.prop.minValueDouble, this.prop.maxValueDouble);
            };
            return DoubleValidationObject;
        }(ValidationObjectBase));
        var StringValidationObject = (function (_super) {
            __extends(StringValidationObject, _super);
            function StringValidationObject(prop) {
                var _this = _super.call(this, prop) || this;
                _this.prop = prop;
                return _this;
            }
            StringValidationObject.prototype.validate = function () {
                if (this.emptyValidationPass()) {
                    this.prop.hideValidationMessage();
                    return true;
                }
                if (this.isEmptyAndRequired()) {
                    this.prop.showValidationMessage();
                    return false;
                }
                var updatedValue = this.prop.getUpdatedValue();
                if (isNaN(this.prop.maxLengthString) || (this.prop.maxLengthString > 0 && updatedValue.length <= this.prop.maxLengthString)) {
                    this.prop.hideValidationMessage();
                    return true;
                }
                this.prop.showValidationMessage();
                return false;
            };
            StringValidationObject.prototype.getValidationMessage = function () {
                if (this.showIsRequiredValidationMsg) {
                    return this.prop.context.resources.getString(EditProperties.LOC_KEYS.REQUIRED_VALIDATION_MESSAGE);
                }
                var validationTemplate = this.prop.context.resources.getString(EditProperties.LOC_KEYS.STRING_VALIDATION_MESSAGE);
                return MscrmCommon.ControlUtils.String.Format(validationTemplate, this.prop.maxLengthString);
            };
            return StringValidationObject;
        }(ValidationObjectBase));
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        'use strict';
        var Property = (function () {
            function Property(dynamicPropId, propInstanceId, name, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionname, optionvalue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) {
                this.dynamicPropId = dynamicPropId;
                this.propInstanceId = propInstanceId;
                this.name = name;
                this.dataType = dataType;
                this.regardingObjectId = regardingObjectId;
                this.valueString = valueString;
                this.valueDecimal = valueDecimal;
                this.valueInteger = valueInteger;
                this.valueDouble = valueDouble;
                this.optionname = optionname;
                this.optionvalue = optionvalue;
                this.minValueDecimal = minValueDecimal;
                this.maxValueDecimal = maxValueDecimal;
                this.minValueDouble = minValueDouble;
                this.maxValueDouble = maxValueDouble;
                this.minValueInteger = minValueInteger;
                this.maxValueInteger = maxValueInteger;
                this.maxLengthString = maxLengthString;
                this.isReadOnly = isReadOnly;
                this.isHidden = isHidden;
                this.isRequired = isRequired;
                this.defaultValueOptionSet = defaultValueOptionSet;
                this.context = context;
                this.iteration = iteration;
                this.stateCode = stateCode;
                this.validationMsgShown = false;
                this.isChanged = false;
                this.inputBoxBorderColor = "#a9a9a9";
                this.isActive = false;
                var value = this.getValueByType(this.dataType);
                if (!value) {
                    value = "";
                }
                if (context.client.isRTL) {
                    this.alignments = new RTLAlignments(this);
                }
                else {
                    this.alignments = new LTRAlignments(this);
                }
                this.value = value;
                this.lastUpdatedValue = value;
                this.validationObject = EditProperties.ValidationFactory.getValidationObject(this);
                this.label = this.createLabel(this.iteration + "_propname", this.name, "#000", this.isDisabled() ? "calc(40% - 2.125rem)" : "calc(40% - 1.25rem)");
                var children = [];
                children.push(this.label);
                if (this.isDisabled()) {
                    var lockedIcon = this.context.factory.createElement("MICROSOFTICON", {
                        id: "lockicon_" + this.iteration,
                        key: "lockicon_" + this.iteration,
                        type: 26 // Locked icon - refer MicrosoftIconSymbol.ts
                    });
                    children.push(lockedIcon);
                }
                if (this.isRequired) {
                }
                if (this.dataType !== EditProperties.DynamicPropertyDataType.OptionSet) {
                    this.borderColor = "transparent";
                    this.borderWidth = "0.0625rem";
                    this.inputTextColor = this.context.theming.colors.basecolor.black;
                    this.inputBox = this.getInputBox();
                }
                //this.validationObject.validate();
                if (this.inputBox) {
                    children.push(this.inputBox);
                }
                else if (this.optionSet) {
                    children = [this.label, this.optionSet];
                }
                else {
                    children = [this.label];
                }
                this.container = this.getContainer(children);
            }
            Property.prototype.getInputBox = function () {
                var _this = this;
                var inputBox = this.createInputBox({
                    id: this.iteration + "_propvalue",
                    key: this.iteration + "_propvalue",
                    style: {
                        marginRight: this.alignments.getItemMarginRight(),
                        marginLeft: this.alignments.getItemMarginLeft(),
                        height: "2.25rem",
                        fontSize: this.context.theming.fontsizes.font100,
                        fontFamilies: this.context.theming.fontfamilies.semibold,
                        fontWeight: this.validationMsgShown ? "bold" : "normal",
                        border: this.context.theming.borders.border02,
                        "border-color": this.borderColor,
                        "border-width": this.borderWidth,
                        color: this.inputTextColor,
                        width: this.getInputBoxWidth(),
                        ":hover": {
                            "border-color": this.validationMsgShown ? this.context.theming.textbox.redcolor : this.inputBoxBorderColor,
                            "border-width": this.validationMsgShown ? "0.125rem" : "0.0625rem"
                        }
                    },
                    value: !this.isActive && (this.context.utils.isNullOrUndefined(this.lastUpdatedValue) || this.lastUpdatedValue.trim().length === 0) ? Property.DEFAULT_VALUE_LABEL : this.lastUpdatedValue,
                    disabled: this.isDisabled(),
                    onFocus: function () {
                        _this.inputFocusHandler();
                    },
                    onBlur: function () {
                        _this.inputBlurHandler();
                    },
                    onChange: this.changeHandler.bind(this),
                    accessibilityLabel: this.name,
                    accessibilityRequired: this.isRequired ? "true" : "false"
                });
                return inputBox;
            };
            Property.prototype.getInputBoxWidth = function () {
                if (this.validationMsgShown) {
                    return "calc(45% - 0.125rem)";
                }
                return "45%";
            };
            Property.prototype.isDisabled = function () {
                return this.isReadOnly;
            };
            Property.prototype.getColData = function () {
                switch (this.dataType) {
                    case EditProperties.DynamicPropertyDataType.WholeNumber:
                    case EditProperties.DynamicPropertyDataType.OptionSet:
                        return new EditProperties.ColData("valueinteger", "c:int", "defaultvalueinteger");
                    case EditProperties.DynamicPropertyDataType.Decimal:
                        return new EditProperties.ColData("valuedecimal", "c:decimal", "defaultvaluedecimal");
                    case EditProperties.DynamicPropertyDataType.Double:
                        return new EditProperties.ColData("valuedouble", "c:double", "defaultvaluedouble");
                    case EditProperties.DynamicPropertyDataType.String:
                        return new EditProperties.ColData("valuestring", "c:string", "defaultvaluestring");
                }
                return null;
            };
            Property.prototype.updateProperty = function (propertyId, json) {
                this.context.webAPI.updateRecord("dynamicpropertyinstance", propertyId, json);
            };
            Property.prototype.changeHandler = function () {
                this.isChanged = true;
                this.lastUpdatedValue = this.getUpdatedValue();
            };
            Property.prototype.createOptionSet = function () {
                var value = !MscrmCommon.ControlUtils.Object.isNullOrUndefined(this.valueInteger) ? EditProperties.OptionSet.getOptionSetByValue(this.valueInteger.toString()) : this.options[0];
                this.optionSet = this.context.factory.createElement("SELECT", {
                    key: this.iteration + "_optionset",
                    id: this.iteration + "_optionset",
                    title: value.Label,
                    freeTextMode: true,
                    value: value,
                    disabled: this.isDisabled(),
                    accessibilityRequired: this.isRequired ? "true" : "false",
                    autoFocus: true,
                    options: this.options,
                    style: this.selectStyle(),
                    onChange: this.changeHandler.bind(this),
                    accessibilityLabel: this.name
                }, null);
                var children = [this.label, this.optionSet];
                this.container = this.getContainer(children);
            };
            Property.prototype.selectStyle = function (isEditableSelectBox) {
                if (isEditableSelectBox === void 0) { isEditableSelectBox = false; }
                var _a = this.context.theming, noneborderstyle = _a.noneborderstyle, textbox = _a.textbox;
                var backgroundColor = textbox.backgroundcolor;
                var color = textbox.contentcolor;
                var selectStyle = {
                    appearance: "normal",
                    padding: "0",
                    marginRight: this.alignments.getItemMarginRight(isEditableSelectBox),
                    marginLeft: this.alignments.getItemMarginLeft(isEditableSelectBox),
                    width: "25%",
                    height: "2.25rem",
                    fontSize: this.context.theming.fontsizes.font100,
                    fontWeight: this.context.theming.textbox.fontweight,
                    boxShadow: this.getSelectBoxShadow(),
                    backgroundColor: this.context.theming.colors.whitebackground,
                    color: color
                };
                var optionStyle = {
                    backgroundColor: backgroundColor,
                    color: color
                };
                return {
                    selectStyle: selectStyle,
                    optionStyle: optionStyle
                };
            };
            Property.prototype.getSelectBoxShadow = function () {
                return "0 0 0 0.0625rem #cccccc inset";
            };
            Property.prototype.getContainer = function (children) {
                this.containerChildren = children;
                return this.context.factory.createElement("CONTAINER", {
                    id: "proprow_" + this.iteration,
                    key: "proprow_" + this.iteration,
                    style: {
                        "display": "block",
                        "width": "100%",
                        "margin-top": this.validationMsgShown ? "0.5625rem" : "0.625rem",
                        "margin-bottom": this.validationMsgShown ? "0.5625rem" : "0.625rem",
                        "color": this.context.theming.colors.grays.gray05,
                        "background-color": this.context.theming.colors.whitebackground
                    }
                }, children);
            };
            Property.prototype.showValidationMessage = function () {
                if (this.validationMsgShown) {
                    return;
                }
                this.validationMsgShown = true;
                this.label = this.createLabel(this.iteration + "_propname", this.name, "#000", "calc(40% - 1.25rem)");
                this.validationBox = this.createValidationErrorMessage("validation_" + this.iteration, this.validationObject.getValidationMessage());
                var children = this.getChildrenWithValidation();
                this.container = this.getContainer(children);
                this.context.utils.requestRender();
            };
            Property.prototype.getErrorIcon = function () {
                var _a = this.context.theming, textbox = _a.textbox, colors = _a.colors, fontsizes = _a.fontsizes, measures = _a.measures;
                var errorIcon = this.context.factory.createElement("LABEL", {
                    id: "erroricon_" + this.iteration,
                    key: "erroricon_" + this.iteration,
                    style: {
                        fontFamily: "Dyn CRM Symbol, Segoe MDL2 Assets",
                        fontWeight: textbox.contentfontweight,
                        fontSize: fontsizes.font100,
                        lineHeight: "2rem",
                        width: textbox.fonticonsize,
                        height: textbox.fonticonsize,
                        textAlign: "center",
                        color: colors.statuscolor.alert1.fill,
                        paddingRight: this.context.client.isRTL ? 0 : measures.measure050,
                        paddingLeft: this.context.client.isRTL ? measures.measure050 : 0
                    },
                }, "\uEA39");
                return errorIcon;
            };
            Property.prototype.createValidationErrorMessage = function (id, msg) {
                var icon = this.getErrorIcon();
                var flexibleText = this.context.factory.createElement("TEXT", {
                    key: id,
                    id: id,
                    truncatedlines: undefined,
                    noExpandable: true,
                    accessibilityHidden: true,
                    lineHeight: 28,
                    flexibleTextStyle: this.getErrorMessageStyles(this.context.theming, msg),
                    style: this.getErrorMessageStyles(this.context.theming, msg),
                    flexibleTextContainerStyle: { overflow: "hidden" }
                }, msg);
                return this.context.factory.createElement("CONTAINER", {
                    style: this.getErrorMessageContainerStyles(this.context),
                    "role": "alert",
                    "aria-live": "assertive",
                    title: msg
                }, [icon, flexibleText]);
            };
            Property.prototype.getErrorMessageContainerStyles = function (context) {
                var _a = context.theming, colors = _a.colors, measures = _a.measures;
                var backgroundColor = MscrmCommon.ThemingHelper.convertHexColorToRGBA(colors.statuscolor.alert1.fill, 0.075);
                return {
                    display: "inline-flex",
                    width: "92.5%",
                    paddingTop: measures.measure050,
                    paddingBottom: measures.measure050,
                    paddingLeft: measures.measure050,
                    paddingRight: measures.measure050,
                    backgroundColor: backgroundColor
                };
            };
            Property.prototype.getErrorMessageStyles = function (theming, errorMessage) {
                var textbox = theming.textbox, colors = theming.colors, fontsizes = theming.fontsizes, measures = theming.measures;
                return {
                    display: errorMessage ? "initial" : "none",
                    color: colors.statuscolor.alert1.fill,
                    fontWeight: textbox.contentfontweight,
                    lineHeight: "2rem",
                    fontSize: fontsizes.font100
                };
            };
            Property.prototype.getChildrenWithValidation = function () {
                var children = [this.label, this.inputBox, this.validationBox];
                if (this.optionSet) {
                    children = [this.label, this.optionSet, this.validationBox];
                }
                return children;
            };
            Property.prototype.hideValidationMessage = function () {
                if (!this.validationMsgShown) {
                    return;
                }
                this.validationMsgShown = false;
                this.label = this.createLabel(this.iteration + "_propname", this.name, "#000", "calc(40% - 1.25rem)");
                this.container = this.getContainer([this.label, this.inputBox]);
                this.context.utils.requestRender();
            };
            Property.prototype.createLabel = function (id, labelValue, color, width) {
                if (color === void 0) { color = "#000000"; }
                if (width === void 0) { width = "calc(40% - 1.25rem)"; }
                var children = [];
                if (this.isRequired) {
                    var textbox = this.context.theming.textbox;
                    var symbol = "*";
                    var color_1 = textbox.redcolor;
                    var requiredIcon = this.context.factory.createElement("CONTAINER", {
                        id: "requiredcontainer" + this.iteration,
                        key: "requiredcontainer" + this.iteration,
                        style: {
                            color: color_1,
                            marginRight: "0.125rem",
                            marginLeft: "0.125rem",
                            display: "inline"
                        },
                        title: null,
                        testhooks: { id: "required-icon" + this.iteration }
                    }, symbol);
                    children.push(requiredIcon);
                }
                var label = this.context.factory.createElement("LABEL", {
                    id: id,
                    key: labelValue,
                    style: {
                        fontSize: this.context.theming.fontsizes.font100,
                        fontFamilies: this.context.theming.fontfamilies.semibold,
                        border: "none",
                        color: color
                    },
                    "aria-required": this.isRequired ? "true" : "false"
                }, labelValue);
                children.push(label);
                return this.context.factory.createElement("CONTAINER", {
                    id: id + "_labelcontainer",
                    key: id + "_labelcontainer",
                    style: {
                        paddingLeft: this.alignments.getLabelPaddingLeft(),
                        paddingRight: this.alignments.getLabelPaddingRight(),
                        width: width,
                        display: "inline-block"
                    }
                }, children);
            };
            Property.prototype.getUpdatedValue = function () {
                var component = this.inputBox;
                if (this.optionSet) {
                    component = this.optionSet;
                }
                var uniqueId = this.context.accessibility.getUniqueId(component.getProperties().id);
                if (uniqueId && document.getElementById(uniqueId)) {
                    return document.getElementById(uniqueId).value;
                }
                // fallback in case element is being re-rendered and may not be present in the dom.
                return this.lastUpdatedValue;
            };
            Property.prototype.inputBlurHandler = function () {
                this.isActive = false;
                this.validationObject.validate();
                this.borderColor = "transparent";
                this.borderWidth = "0.0625rem";
                if (this.validationMsgShown) {
                    this.inputTextColor = this.context.theming.textbox.redcolor;
                }
                else {
                    this.inputTextColor = this.context.theming.colors.basecolor.black;
                }
                this.reRenderInputBox();
            };
            Property.prototype.inputFocusHandler = function () {
                this.isActive = true;
                if (this.validationMsgShown) {
                    this.borderColor = this.context.theming.textbox.redcolor;
                    this.inputTextColor = this.context.theming.textbox.redcolor;
                    this.borderWidth = "0.125rem";
                }
                else {
                    this.borderColor = this.inputBoxBorderColor;
                    this.inputTextColor = this.context.theming.colors.basecolor.black;
                    this.borderWidth = "0.0625rem";
                }
                this.reRenderInputBox();
            };
            Property.prototype.reRenderInputBox = function () {
                var inputBoxIndex = this.containerChildren.indexOf(this.inputBox);
                this.inputBox = this.getInputBox();
                this.containerChildren.splice(inputBoxIndex, 1, this.inputBox);
                this.container = this.getContainer(this.containerChildren);
                this.context.utils.requestRender();
            };
            Property.prototype.createInputBox = function (props) {
                var ccProperties = {};
                var input = this.context.factory.createElement("TEXTINPUT", props);
                return input;
            };
            Property.prototype.getValueByType = function (dataType) {
                switch (dataType) {
                    case EditProperties.DynamicPropertyDataType.Decimal:
                        if (this.valueDecimal) {
                            return this.valueDecimal.toString();
                        }
                    case EditProperties.DynamicPropertyDataType.Double:
                        if (this.valueDouble) {
                            return this.valueDouble.toString();
                        }
                    case EditProperties.DynamicPropertyDataType.WholeNumber:
                    case EditProperties.DynamicPropertyDataType.OptionSet:
                        if (this.valueInteger) {
                            return this.valueInteger.toString();
                        }
                    case EditProperties.DynamicPropertyDataType.String:
                        if (this.valueString) {
                            return this.valueString;
                        }
                }
                return null;
            };
            Property.prototype.getBundleProductNameAndValueDataForSave = function (colData) {
                return '<a:KeyValuePairOfstringanyType><b:key>' + colData.defaultColName + '</b:key>' +
                    '<b:value i:type="' + colData.colType + '" xmlns:c="http://www.w3.org/2001/XMLSchema">' +
                    this.getUpdatedValue() + '</b:value></a:KeyValuePairOfstringanyType>';
            };
            return Property;
        }());
        Property.DEFAULT_VALUE_LABEL = "---";
        EditProperties.Property = Property;
        var LTRAlignments = (function () {
            function LTRAlignments(property) {
                this.property = property;
            }
            LTRAlignments.prototype.getItemMarginLeft = function (isEditableSelectBox) {
                if (isEditableSelectBox === void 0) { isEditableSelectBox = false; }
                // 0.625rem = 1px considering 1rem as 16px
                if (isEditableSelectBox) {
                    return "0.625rem";
                }
                return (this.property.isRequired) ? "1.25rem" : "0.625rem";
            };
            LTRAlignments.prototype.getItemMarginRight = function (isEditableSelectBox) {
                if (isEditableSelectBox === void 0) { isEditableSelectBox = false; }
                if (this.property instanceof BundleProductProperty) {
                    return "0.625rem";
                }
                return (this.property.isRequired) ? "1.875rem" : "0.625rem";
            };
            LTRAlignments.prototype.getLabelPaddingLeft = function () {
                return (this.property.isRequired) ? "0" : "0.625rem";
            };
            LTRAlignments.prototype.getLabelPaddingRight = function () {
                return "0.625rem";
            };
            return LTRAlignments;
        }());
        var RTLAlignments = (function (_super) {
            __extends(RTLAlignments, _super);
            function RTLAlignments() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            RTLAlignments.prototype.getItemMarginLeft = function (isEditableSelectBox) {
                if (isEditableSelectBox === void 0) { isEditableSelectBox = false; }
                return _super.prototype.getItemMarginRight.call(this, isEditableSelectBox);
            };
            RTLAlignments.prototype.getItemMarginRight = function (isEditableSelectBox) {
                if (isEditableSelectBox === void 0) { isEditableSelectBox = false; }
                return _super.prototype.getItemMarginLeft.call(this, isEditableSelectBox);
            };
            RTLAlignments.prototype.getLabelPaddingLeft = function () {
                return _super.prototype.getLabelPaddingRight.call(this);
            };
            RTLAlignments.prototype.getLabelPaddingRight = function () {
                return _super.prototype.getLabelPaddingLeft.call(this);
            };
            return RTLAlignments;
        }(LTRAlignments));
        /**
         * Property data can be fetched from different data sources for bundle and oqoi products.
         * This class represents and creates instances of data from different sources.
         */
        var PropertyData = (function () {
            function PropertyData() {
            }
            PropertyData.getData = function (referrer, data) {
                var propData = new PropertyData();
                if (referrer instanceof EditProperties.OppQuoteInvoiceOrderProductPropertiesController) {
                    propData.dynamicPropInstanceId = data["dynamicpropertyinstanceid"];
                    propData.dynamicPropId = data["dp.dynamicpropertyid"];
                    propData.propName = data["dp.name"];
                    propData.dataType = data["dp.datatype"];
                    propData.valueString = data["valuestring"];
                    propData.valueDecimal = data["valuedecimal"];
                    propData.valueInteger = data["valueinteger"];
                    propData.valueDouble = data["valuedouble"];
                    propData.regardingObjectId = data["op." + EditProperties.FetchXmlCreator.getIdColNameByEntity(referrer.model.GridEntityName)];
                    propData.optionName = data["osi.dynamicpropertyoptionname"];
                    propData.optionValue = data["osi.dynamicpropertyoptionvalue"];
                    propData.minValueDecimal = data["dp.minvaluedecimal"];
                    propData.maxValueDecimal = data["dp.maxvaluedecimal"];
                    propData.minValueDouble = data["dp.minvaluedouble"];
                    propData.maxValueDouble = data["dp.maxvaluedouble"];
                    propData.minValueInteger = data["dp.minvalueinteger"];
                    propData.maxValueInteger = data["dp.maxvalueinteger"];
                    propData.maxLengthString = data["dp.maxlengthstring"];
                    propData.isReadOnly = data["dp.isreadonly"];
                    propData.isHidden = data["dp.ishidden"];
                    propData.isRequired = data["dp.isrequired"];
                    propData.defaultValueOptionSet = data["dp.defaultvalueoptionset"];
                }
                else if (referrer instanceof EditProperties.BundleProductPropertiesController) {
                    propData.dynamicPropInstanceId = data["dynamicpropertyid"];
                    propData.dynamicPropId = data["dynamicpropertyid"];
                    propData.propName = data["name"];
                    propData.dataType = data["datatype"];
                    propData.valueString = data["defaultvaluestring"];
                    propData.valueDecimal = data["defaultvaluedecimal"];
                    propData.valueInteger = data["defaultvalueinteger"];
                    propData.valueDouble = data["defaultvaluedouble"];
                    propData.regardingObjectId = data["_regardingobjectid_value"];
                    propData.stateCode = data["statecode"];
                    propData.optionName = data["dynamicpropertyoptionname"];
                    propData.optionValue = data["dynamicpropertyoptionvalue"];
                    propData.minValueDecimal = data["minvaluedecimal"];
                    propData.maxValueDecimal = data["maxvaluedecimal"];
                    propData.minValueDouble = data["minvaluedouble"];
                    propData.maxValueDouble = data["maxvaluedouble"];
                    propData.minValueInteger = data["minvalueinteger"];
                    propData.maxValueInteger = data["maxvalueinteger"];
                    propData.maxLengthString = data["maxlengthstring"];
                    propData.isReadOnly = data["isreadonly"];
                    propData.isHidden = data["ishidden"];
                    propData.isRequired = data["isrequired"];
                    propData.defaultValueOptionSet = data["defaultvalueoptionset"];
                }
                return propData;
            };
            return PropertyData;
        }());
        EditProperties.PropertyData = PropertyData;
        var OptionSetItemData = (function () {
            function OptionSetItemData(optionSetItemId, dynamicPropertyId, dynamicPropertyName, optionName, optionValue, defaultItemId) {
                this.optionSetItemId = optionSetItemId;
                this.dynamicPropertyId = dynamicPropertyId;
                this.dynamicPropertyName = dynamicPropertyName;
                this.optionName = optionName;
                this.optionValue = optionValue;
                this.defaultItemId = defaultItemId;
                if (!OptionSetItemData.dataByPropId[dynamicPropertyId]) {
                    OptionSetItemData.dataByPropId[dynamicPropertyId] = [];
                }
                OptionSetItemData.dataByPropId[dynamicPropertyId].push(this);
            }
            Object.defineProperty(OptionSetItemData.prototype, "isDefault", {
                get: function () {
                    if (this.defaultItemId === this.optionSetItemId) {
                        return true;
                    }
                    return false;
                },
                enumerable: true,
                configurable: true
            });
            OptionSetItemData.getDefaultOptionSetItemByPropId = function (dynamicPropId) {
                var allItems = OptionSetItemData.dataByPropId[dynamicPropId];
                if (!allItems) {
                    return null;
                }
                for (var i = 0; i < allItems.length; i++) {
                    if (allItems[i].isDefault) {
                        return allItems[i];
                    }
                }
                return null;
            };
            OptionSetItemData.getOptionSetItemByPropIdAndValue = function (propId, value) {
                var allItems = OptionSetItemData.dataByPropId[propId];
                if (!allItems || MscrmCommon.ControlUtils.Object.isNullOrUndefined(value)) {
                    return null;
                }
                for (var i = 0; i < allItems.length; i++) {
                    if (allItems[i].optionValue === value) {
                        return allItems[i];
                    }
                }
                return null;
            };
            return OptionSetItemData;
        }());
        EditProperties.OptionSetItemData = OptionSetItemData;
        var BundleProductProperty = (function (_super) {
            __extends(BundleProductProperty, _super);
            function BundleProductProperty(dynamicPropId, propInstanceId, name, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionname, optionvalue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) {
                return _super.call(this, dynamicPropId, propInstanceId, name, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionname, optionvalue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) || this;
            }
            BundleProductProperty.prototype.isDisabled = function () {
                return false;
            };
            BundleProductProperty.prototype.isEditableTextKey = function () {
                var result;
                if (this.isReadOnly) {
                    result = EditProperties.LOC_KEYS.OPTION_NO;
                }
                else {
                    result = EditProperties.LOC_KEYS.OPTION_YES;
                }
                return result;
            };
            BundleProductProperty.prototype.getContainer = function (children) {
                if (!this.validationMsgShown) {
                    var no = this.context.resources.getString(EditProperties.LOC_KEYS.OPTION_NO);
                    var yes = this.context.resources.getString(EditProperties.LOC_KEYS.OPTION_YES);
                    var noOption = new EditProperties.OptionSet(no, '0', no);
                    var yesOption = new EditProperties.OptionSet(yes, '1', yes);
                    this.editableSelectBox = this.context.factory.createElement("SELECT", {
                        key: this.iteration + "_editable",
                        id: this.iteration + "_editable",
                        title: this.context.resources.getString(this.isEditableTextKey()),
                        freeTextMode: true,
                        value: this.isReadOnly ? noOption : yesOption,
                        disabled: false,
                        autoFocus: true,
                        options: [noOption, yesOption],
                        style: this.selectStyle(true),
                        onChange: this.readOnlyChangeHandler.bind(this),
                        accessibilityLabel: this.context.resources.getString(EditProperties.LOC_KEYS.EDITABLE) + ' ' + this.name
                    }, null);
                    children.push(this.editableSelectBox);
                }
                return _super.prototype.getContainer.call(this, children);
            };
            BundleProductProperty.prototype.getChildrenWithValidation = function () {
                var children = [this.label, this.inputBox, this.editableSelectBox, this.validationBox];
                if (this.optionSet) {
                    children = [this.label, this.optionSet, this.editableSelectBox, this.validationBox];
                }
                return children;
            };
            BundleProductProperty.prototype.getSelectBoxShadow = function () {
                return "none";
            };
            BundleProductProperty.prototype.readOnlyChangeHandler = function () {
                this.isChanged = true;
                this.isReadOnly = !this.isReadOnly;
            };
            BundleProductProperty.prototype.getInputBoxWidth = function () {
                if (this.validationMsgShown) {
                    return "calc(25% - 0.125rem)";
                }
                return "25%";
            };
            return BundleProductProperty;
        }(Property));
        EditProperties.BundleProductProperty = BundleProductProperty;
        var BundleProductOptionSetProperty = (function (_super) {
            __extends(BundleProductOptionSetProperty, _super);
            function BundleProductOptionSetProperty(dynamicPropId, propInstanceId, name, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionname, optionvalue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) {
                return _super.call(this, dynamicPropId, propInstanceId, name, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionname, optionvalue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) || this;
            }
            Object.defineProperty(BundleProductOptionSetProperty.prototype, "allOptions", {
                get: function () {
                    return OptionSetItemData.dataByPropId[this.dynamicPropId];
                },
                enumerable: true,
                configurable: true
            });
            BundleProductOptionSetProperty.prototype.getOptionSetItemByValue = function (value) {
                return OptionSetItemData.getOptionSetItemByPropIdAndValue(this.dynamicPropId, value);
            };
            BundleProductOptionSetProperty.prototype.getCurrentlySelectedItem = function () {
                return this.getOptionSetItemByValue(parseInt(this.lastUpdatedValue));
            };
            BundleProductOptionSetProperty.prototype.getBundleProductNameAndValueDataForSave = function (colData) {
                if (!this.getCurrentlySelectedItem()) {
                    return '';
                }
                return '<a:KeyValuePairOfstringanyType><b:key>defaultvalueoptionset</b:key><b:value i:type="a:EntityReference"><a:Id>' +
                    this.getCurrentlySelectedItem().optionSetItemId + '</a:Id><a:LogicalName>dynamicpropertyoptionsetitem</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>';
            };
            return BundleProductOptionSetProperty;
        }(BundleProductProperty));
        EditProperties.BundleProductOptionSetProperty = BundleProductOptionSetProperty;
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        var EditPropertiesModel = (function () {
            function EditPropertiesModel() {
                /*
                 * Input context
                 */
                this.context = null;
            }
            EditPropertiesModel.prototype.init = function (context) {
                this.context = context;
                this.Value1 = this.getParamValueById("Value1").raw;
                this.ProductId = this.getParamValueById("ProductId").raw;
                this.ProductName = this.getParamValueById("ProductName").raw;
                this.EntityName = this.getParamValueById("EntityName").raw;
                this.GridEntityName = this.getParamValueById("GridEntityName").raw;
            };
            EditPropertiesModel.prototype.getParamValueById = function (id) {
                var result;
                switch (id) {
                    case "Value1":
                        result = this.context.parameters.Value1;
                        break;
                    case "ProductId":
                        result = this.context.parameters.ProductId;
                        break;
                    case "ProductName":
                        result = this.context.parameters.ProductName;
                        break;
                    case "GridEntityName":
                        result = this.context.parameters.GridEntityName;
                        break;
                    case "EntityName":
                        result = this.context.parameters.EntityName;
                        break;
                }
                return result;
            };
            return EditPropertiesModel;
        }());
        EditProperties.EditPropertiesModel = EditPropertiesModel;
        var OptionSet = (function () {
            function OptionSet(Label, Value, text, color) {
                if (color === void 0) { color = "#000"; }
                this.Label = Label;
                this.Value = Value;
                this.text = text;
                this.color = color;
                OptionSet.optionByValue[Value] = this;
            }
            OptionSet.getNameByValue = function (value) {
                return OptionSet.optionByValue[value].Label;
            };
            OptionSet.getOptionSetByValue = function (value) {
                return OptionSet.optionByValue[value];
            };
            return OptionSet;
        }());
        OptionSet.optionByValue = {};
        EditProperties.OptionSet = OptionSet;
        var DynamicPropertyDataType = (function () {
            function DynamicPropertyDataType() {
            }
            return DynamicPropertyDataType;
        }());
        DynamicPropertyDataType.OptionSet = 0;
        DynamicPropertyDataType.Decimal = 1;
        DynamicPropertyDataType.Double = 2;
        DynamicPropertyDataType.String = 3;
        DynamicPropertyDataType.WholeNumber = 4;
        EditProperties.DynamicPropertyDataType = DynamicPropertyDataType;
        var ColData = (function () {
            function ColData(colName, colType, defaultColName) {
                this.colName = colName;
                this.colType = colType;
                this.defaultColName = defaultColName;
            }
            return ColData;
        }());
        EditProperties.ColData = ColData;
        EditProperties.SALES_ENTITY_NAMES = {
            OPPORTUNITY: "opportunity",
            ORDER: "salesorder",
            QUOTE: "quote",
            INVOICE: "invoice",
            OPP_PRODUCT: "opportunityproduct",
            ORDER_DETAIL: "salesorderdetail",
            QUOTE_DETAIL: "quotedetail",
            INVOICE_DETAIL: "invoicedetail",
            PRODUCT_ASSOCIATION: "productassociation"
        };
        var FetchXmlCreator = (function () {
            function FetchXmlCreator() {
            }
            ;
            FetchXmlCreator.getFetchXmlByType = function (gridEntityName, entityName, productId) {
                // Fetch xml is divided into three parts based on the entity being queried.
                var part1 = "<fetch version='1.0' mapping='logical' distinct='false'><entity name='dynamicpropertyinstance' alias='dpi'><attribute name='dynamicpropertyinstanceid'/><attribute name='valueinteger'/><attribute name='valuedouble'/><attribute name='valuedecimal'/><attribute name='valuestring'/>";
                var part2 = "<link-entity name='" + gridEntityName + "' alias='op' to='regardingobjectid' from='" + gridEntityName + "id' link-type='inner'> 			<attribute name='" + gridEntityName + "id'/> 			<attribute name='productidname'/> 			<filter type='and'> 				<condition attribute='" + gridEntityName + "id' operator='eq' value='" + productId + "' /> 			</filter> 		</link-entity>";
                var part3 = "<link-entity name='dynamicproperty' alias='dp' to='dynamicpropertyid' from='dynamicpropertyid' link-type='inner'> 		<attribute name='dynamicpropertyid'/>	<attribute name='datatype'/> 			<attribute name='name'/> 			<attribute name='minvaluedecimal'/> 			<attribute name='maxvaluedecimal'/> 			<attribute name='minvaluedouble'/> 			<attribute name='maxvaluedouble'/> 			<attribute name='minvalueinteger'/> 			<attribute name='maxvalueinteger'/> 			<attribute name='maxlengthstring'/> 			<attribute name='isreadonly'/> 			<attribute name='ishidden'/> 			<attribute name='isrequired'/> 	<attribute name='defaultvalueoptionset'/> </link-entity> 		<link-entity name='dynamicpropertyoptionsetitem' alias='osi' to='dynamicpropertyid' from='dynamicpropertyid' link-type='outer'> <attribute name='dynamicpropertyoptionname'/> 	<attribute name='dynamicpropertyoptionvalue'/> 	</link-entity> 	</entity> </fetch>";
                return part1 + part2 + part3;
            };
            FetchXmlCreator.getIdColNameByEntity = function (gridEntityName) {
                var result = gridEntityName + "id";
                return result;
            };
            FetchXmlCreator.getDetailEntityName = function (entityName) {
                var result = "opportunityproduct";
                switch (entityName.toLowerCase()) {
                    case EditProperties.SALES_ENTITY_NAMES.ORDER:
                        result = "salesorderdetail";
                        break;
                    case EditProperties.SALES_ENTITY_NAMES.QUOTE:
                        result = "quotedetail";
                        break;
                    case EditProperties.SALES_ENTITY_NAMES.INVOICE:
                        result = "invoicedetail";
                        break;
                }
                return result;
            };
            return FetchXmlCreator;
        }());
        EditProperties.FetchXmlCreator = FetchXmlCreator;
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        var ProductPropertiesControllerBase = (function () {
            function ProductPropertiesControllerBase(model) {
                this.model = model;
            }
            ProductPropertiesControllerBase.getControllerInstance = function (model) {
                var name = model.GridEntityName;
                if (ProductPropertiesControllerBase._instance) {
                    ProductPropertiesControllerBase._instance.model = model;
                    return ProductPropertiesControllerBase._instance;
                }
                var controller;
                switch (name) {
                    case EditProperties.SALES_ENTITY_NAMES.PRODUCT_ASSOCIATION:
                        controller = new EditProperties.BundleProductPropertiesController(model);
                        break;
                    case EditProperties.SALES_ENTITY_NAMES.OPP_PRODUCT:
                    case EditProperties.SALES_ENTITY_NAMES.QUOTE_DETAIL:
                    case EditProperties.SALES_ENTITY_NAMES.INVOICE_DETAIL:
                    case EditProperties.SALES_ENTITY_NAMES.ORDER_DETAIL:
                        controller = new EditProperties.OppQuoteInvoiceOrderProductPropertiesController(model);
                        break;
                }
                if (!controller) {
                    throw new Error("Controller not configured for this entity: " + name);
                }
                ProductPropertiesControllerBase._instance = controller;
                return ProductPropertiesControllerBase._instance;
            };
            ProductPropertiesControllerBase.nullifyInstance = function () {
                ProductPropertiesControllerBase._instance = null;
            };
            ProductPropertiesControllerBase.prototype.closeMDDFromCustomControl = function () {
                try {
                    if (window.Xrm && window.Xrm.Page && window.Xrm.Page.ui) {
                        window.Xrm.Page.ui.close();
                    }
                }
                catch (exception) {
                    console.warn(exception);
                }
            };
            ProductPropertiesControllerBase.prototype.dataSuccessHandler = function (entityData) {
                this.model.properties = [];
                var okButtonData = $('[data-id="ok_id"]');
                if (okButtonData.length > 0) {
                    okButtonData[0].addEventListener("click", this.okClickHandler.bind(this));
                }
                var cancelButtonData = $('[data-id="cancel_id"]');
                if (cancelButtonData.length > 0) {
                    cancelButtonData[0].addEventListener("click", function () {
                        this.closeMDDFromCustomControl();
                    }.bind(this));
                }
                var propertyByOptionsetPropInstanceId = {};
                if (entityData) {
                    for (var i = 0; i < entityData.length; i++) {
                        var propData = EditProperties.PropertyData.getData(this, entityData[i]);
                        var dynamicPropInstanceId = propData.dynamicPropInstanceId;
                        var dynamicPropId = propData.dynamicPropId;
                        var propName = propData.propName;
                        var dataType = propData.dataType;
                        var valueString = propData.valueString;
                        var valueDecimal = propData.valueDecimal;
                        var valueInteger = propData.valueInteger;
                        var valueDouble = propData.valueDouble;
                        var regardingObjectId = propData.regardingObjectId;
                        var optionName = propData.optionName;
                        var optionValue = propData.optionValue;
                        var minValueDecimal = propData.minValueDecimal;
                        var maxValueDecimal = propData.maxValueDecimal;
                        var minValueDouble = propData.minValueDouble;
                        var maxValueDouble = propData.maxValueDouble;
                        var minValueInteger = propData.minValueInteger;
                        var maxValueInteger = propData.maxValueInteger;
                        var maxLengthString = propData.maxLengthString;
                        var isReadOnly = propData.isReadOnly;
                        var isHidden = propData.isHidden;
                        var isRequired = propData.isRequired;
                        var defaultValueOptionSet = propData.defaultValueOptionSet;
                        var stateCode = propData.stateCode;
                        if (isHidden) {
                            continue;
                        }
                        if (dataType !== EditProperties.DynamicPropertyDataType.OptionSet || (dataType === EditProperties.DynamicPropertyDataType.OptionSet && !propertyByOptionsetPropInstanceId[dynamicPropInstanceId])) {
                            var prop = this.createProperty(dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, this.model.context, i, stateCode);
                            this.model.properties.push(prop);
                        }
                        if (dataType == EditProperties.DynamicPropertyDataType.OptionSet) {
                            if (!propertyByOptionsetPropInstanceId[dynamicPropInstanceId]) {
                                propertyByOptionsetPropInstanceId[dynamicPropInstanceId] = prop;
                                prop.options = [];
                                if (MscrmCommon.ControlUtils.Object.isNullOrUndefined(prop.valueInteger) || !prop.isRequired) {
                                    var defaultOption = prop.context.resources.getString(EditProperties.LOC_KEYS.OPTION_SET_EMPTY_OPTION);
                                    prop.options.push(new EditProperties.OptionSet(defaultOption, EditProperties.OPTION_SET_DEFAULT_OPTION_VALUE, defaultOption));
                                }
                                if (optionName) {
                                    prop.options.push(new EditProperties.OptionSet(optionName, optionValue, optionName));
                                }
                            }
                            else {
                                if (optionName) {
                                    propertyByOptionsetPropInstanceId[dynamicPropInstanceId].options.push(new EditProperties.OptionSet(optionName, optionValue, optionName));
                                }
                            }
                        }
                    }
                    for (var key in propertyByOptionsetPropInstanceId) {
                        propertyByOptionsetPropInstanceId[key].createOptionSet();
                    }
                    this.model.context.utils.requestRender();
                }
            };
            ProductPropertiesControllerBase.prototype.createProperty = function (dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) {
                return new EditProperties.Property(dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode);
            };
            ProductPropertiesControllerBase.prototype.okClickHandler = function () {
                if (!this.saveProperties()) {
                    this.model.context.utils.requestRender();
                }
            };
            ProductPropertiesControllerBase.prototype.saveProperties = function () {
                if (this.model.properties) {
                    var entityXml = '';
                    for (var i = 0; i < this.model.properties.length; i++) {
                        var prop = this.model.properties[i];
                        if (!prop.validationObject.validate()) {
                            // if any of the properties fail validation, abort save operation
                            return false;
                        }
                        if (prop.isChanged) {
                            entityXml += this.getSaveRequestEntityXml(prop);
                        }
                    }
                    if (entityXml === '') {
                        this.closeMDDFromCustomControl();
                        return false;
                    }
                    var xml = this.getSaveRequestXml(entityXml);
                    var xHReq = new XMLHttpRequest();
                    xHReq.open('POST', this.getClientUrl() + '/XRMServices/2011/Organization.svc/web', true);
                    xHReq.setRequestHeader('SOAPAction', 'http://schemas.microsoft.com/xrm/2011/Contracts/Services/IOrganizationService/Execute');
                    xHReq.onload = function () {
                        this.closeMDDFromCustomControl();
                    }.bind(this);
                    xHReq.setRequestHeader('Content-Type', 'text/xml; charset=utf-8');
                    xHReq.setRequestHeader('Content-Length', xml.length.toString());
                    xHReq.send(xml);
                    return true;
                }
            };
            ProductPropertiesControllerBase.prototype.getClientUrl = function () {
                return window.Xrm.Page.context.getClientUrl();
            };
            ProductPropertiesControllerBase.prototype.getSaveRequestXml = function (allEntitiesXml) {
                throw new Error("getSaveRequestXml method should be overridden by implementing classes");
            };
            ProductPropertiesControllerBase.prototype.getSaveRequestEntityXml = function (prop) {
                throw new Error("getSaveRequestEntityXml method should be overridden by implementing classes");
            };
            return ProductPropertiesControllerBase;
        }());
        EditProperties.ProductPropertiesControllerBase = ProductPropertiesControllerBase;
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        var OppQuoteInvoiceOrderProductPropertiesController = (function (_super) {
            __extends(OppQuoteInvoiceOrderProductPropertiesController, _super);
            function OppQuoteInvoiceOrderProductPropertiesController(model) {
                return _super.call(this, model) || this;
            }
            OppQuoteInvoiceOrderProductPropertiesController.prototype.fetchData = function () {
                var fetchXml = EditProperties.FetchXmlCreator.getFetchXmlByType(this.model.GridEntityName, this.model.EntityName, this.model.ProductId);
                //"<fetch version='1.0' mapping='logical' distinct='false'> 	<entity name='dynamicpropertyinstance' alias='dpi'> <attribute name='dynamicpropertyinstanceid'/> <attribute name='valueinteger'/> 		<attribute name='valuedouble'/> 		<attribute name='valuedecimal'/> 		<attribute name='valuestring'/> 		<link-entity name='opportunityproduct' alias='op' to='regardingobjectid' from='opportunityproductid' link-type='inner'> 			<attribute name='opportunityproductid'/> 			<attribute name='productidname'/> 			<filter type='and'> 				<condition attribute='opportunityproductid' operator='eq' value='" + this.ProductId + "' /> 			</filter> 		</link-entity> 		<link-entity name='dynamicproperty' alias='dp' to='dynamicpropertyid' from='dynamicpropertyid' link-type='inner'> 		<attribute name='dynamicpropertyid'/>	<attribute name='datatype'/> 			<attribute name='name'/> 			<attribute name='minvaluedecimal'/> 			<attribute name='maxvaluedecimal'/> 			<attribute name='minvaluedouble'/> 			<attribute name='maxvaluedouble'/> 			<attribute name='minvalueinteger'/> 			<attribute name='maxvalueinteger'/> 			<attribute name='maxlengthstring'/> 			<attribute name='isreadonly'/> 			<attribute name='ishidden'/> 			<attribute name='isrequired'/> 	<attribute name='defaultvalueoptionset'/> </link-entity> 		<link-entity name='dynamicpropertyoptionsetitem' alias='osi' to='dynamicpropertyid' from='dynamicpropertyid' link-type='outer'> <attribute name='dynamicpropertyoptionname'/> 	<attribute name='dynamicpropertyoptionvalue'/> 	</link-entity> 	</entity> </fetch>"
                this.getData(this.model.context, "dynamicpropertyinstance", fetchXml).then(this.dataSuccessHandler.bind(this), function (error) {
                    console.log("Error Occured");
                    console.log(error);
                });
            };
            OppQuoteInvoiceOrderProductPropertiesController.prototype.dataSuccessHandler = function (data) {
                _super.prototype.dataSuccessHandler.call(this, data.entities);
            };
            OppQuoteInvoiceOrderProductPropertiesController.prototype.getData = function (context, entity, fetchxml) {
                var data = context.webAPI.retrieveMultipleRecords(entity, "?fetchXml=" + fetchxml);
                return data;
            };
            OppQuoteInvoiceOrderProductPropertiesController.prototype.getSaveRequestXml = function (allEntitiesXml) {
                return '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><SdkClientVersion xmlns="http://schemas.microsoft.com/xrm/2011/Contracts">9.0</SdkClientVersion></s:Header><s:Body><Execute xmlns="http://schemas.microsoft.com/xrm/2011/Contracts/Services" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><request i:type="b:UpdateProductPropertiesRequest" xmlns:a="http://schemas.microsoft.com/xrm/2011/Contracts" xmlns:b="http://schemas.microsoft.com/crm/2011/Contracts"><a:Parameters xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"><a:KeyValuePairOfstringanyType><b:key>PropertyInstanceList</b:key><b:value i:type="a:EntityCollection"><a:Entities>' + allEntitiesXml + '</a:Entities></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil="true" /><a:RequestName>UpdateProductProperties</a:RequestName></request></Execute></s:Body></s:Envelope>';
            };
            OppQuoteInvoiceOrderProductPropertiesController.prototype.getSaveRequestEntityXml = function (prop) {
                var colData = prop.getColData();
                return '<a:Entity> <a:Attributes xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"> <a:KeyValuePairOfstringanyType> <b:key>regardingobjectid</b:key><b:value i:type="a:EntityReference"><a:Id>' +
                    prop.regardingObjectId +
                    '</a:Id><a:LogicalName>' + this.model.GridEntityName + '</a:LogicalName></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>dynamicpropertyid</b:key><b:value i:type="a:EntityReference"><a:Id>' +
                    prop.dynamicPropId +
                    ' </a:Id><a:LogicalName>dynamicproperty</a:LogicalName></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>dynamicpropertyinstanceid</b:key><b:value i:type="c:guid" xmlns:c="http://schemas.microsoft.com/2003/10/Serialization/">' +
                    prop.propInstanceId +
                    '</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>' +
                    colData.colName +
                    '</b:key><b:value i:type="' + colData.colType + '" xmlns:c="http://www.w3.org/2001/XMLSchema">' +
                    prop.getUpdatedValue() +
                    '</b:value></a:KeyValuePairOfstringanyType></a:Attributes><a:EntityState i:nil="true"/><a:FormattedValues xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/><a:Id>' +
                    prop.propInstanceId +
                    '</a:Id><a:LogicalName>dynamicpropertyinstance</a:LogicalName><a:RelatedEntities xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/></a:Entity>';
            };
            return OppQuoteInvoiceOrderProductPropertiesController;
        }(EditProperties.ProductPropertiesControllerBase));
        EditProperties.OppQuoteInvoiceOrderProductPropertiesController = OppQuoteInvoiceOrderProductPropertiesController;
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        var BundleProductPropertiesController = (function (_super) {
            __extends(BundleProductPropertiesController, _super);
            function BundleProductPropertiesController(model) {
                return _super.call(this, model) || this;
            }
            BundleProductPropertiesController.prototype.fetchData = function () {
                this.model.context.webAPI.execute(new RetrieveEntityDynamicPropertyDefinitions("dynamicproperty", this.model.ProductId)).then(function (response) {
                    response.json().then(this.dataSuccessHandler.bind(this));
                }.bind(this));
            };
            BundleProductPropertiesController.prototype.dataSuccessHandler = function (data) {
                // get optionset data if they exist and insert entries in data variable to ensure optionset creation via same pipeline as used by base.
                var entityData = data.value;
                var dynamicPropIdList = [];
                EditProperties.OptionSetItemData.dataByPropId = {};
                EditProperties.OptionSetItemData.defaultOptionSetIdByPropId = {};
                this.entityDataByPropId = {};
                for (var i = 0; i < entityData.length; i++) {
                    if (entityData[i]['datatype'] === EditProperties.DynamicPropertyDataType.OptionSet) {
                        EditProperties.OptionSetItemData.defaultOptionSetIdByPropId[entityData[i]['dynamicpropertyid']] = entityData[i]['_defaultvalueoptionset_value'];
                        this.entityDataByPropId[entityData[i]['dynamicpropertyid']] = entityData[i];
                        dynamicPropIdList.push(entityData[i]['dynamicpropertyid']);
                    }
                }
                if (dynamicPropIdList.length > 0) {
                    this.getOptionSetData(dynamicPropIdList, data, this.optionSetDataSuccessHandler.bind(this));
                }
                else {
                    _super.prototype.dataSuccessHandler.call(this, data.value);
                }
            };
            BundleProductPropertiesController.prototype.optionSetDataSuccessHandler = function (optionSetData, data) {
                data.value = optionSetData.concat(data.value);
                _super.prototype.dataSuccessHandler.call(this, data.value);
            };
            BundleProductPropertiesController.prototype.getOptionSetData = function (dynamicPropIdList, data, successHandler) {
                var xHReq = new XMLHttpRequest();
                xHReq.open('GET', this.getClientUrl() + '/api/data/v9.0/dynamicpropertyoptionsetitems?$select=dynamicpropertyoptionsetvalueid,dynamicpropertyoptionvalue,dynamicpropertyoptionname,_dynamicpropertyid_value', true);
                xHReq.onload = function () {
                    var value = JSON.parse(xHReq.response).value;
                    var result = [];
                    if (value && value.length > 0) {
                        var resp = value;
                        for (var i = 0; i < resp.length; i++) {
                            var idx = dynamicPropIdList.indexOf(resp[i]['_dynamicpropertyid_value']);
                            if (idx > -1) {
                                var entityData = this.entityDataByPropId[dynamicPropIdList[idx]];
                                new EditProperties.OptionSetItemData(resp[i]['dynamicpropertyoptionsetvalueid'], dynamicPropIdList[idx], entityData['name'], resp[i]['dynamicpropertyoptionname'], resp[i]['dynamicpropertyoptionvalue'], EditProperties.OptionSetItemData.defaultOptionSetIdByPropId[dynamicPropIdList[idx]]);
                            }
                        }
                        for (var i = 0; i < resp.length; i++) {
                            var idx = dynamicPropIdList.indexOf(resp[i]['_dynamicpropertyid_value']);
                            if (idx > -1) {
                                var defaultValue = EditProperties.OptionSetItemData.getDefaultOptionSetItemByPropId(dynamicPropIdList[idx]);
                                var entityData = this.entityDataByPropId[dynamicPropIdList[idx]];
                                result.push({
                                    'name': entityData['name'],
                                    'datatype': EditProperties.DynamicPropertyDataType.OptionSet,
                                    'isreadonly': entityData['isreadonly'],
                                    'statecode': entityData['statecode'],
                                    '_regardingobjectid_value': entityData['_regardingobjectid_value'],
                                    'defaultvalueinteger': defaultValue ? defaultValue.optionValue : -1,
                                    'dynamicpropertyoptionname': resp[i]['dynamicpropertyoptionname'],
                                    'dynamicpropertyoptionvalue': resp[i]['dynamicpropertyoptionvalue'],
                                    'dynamicpropertyid': dynamicPropIdList[idx],
                                    'dynamicpropertyinstanceid': dynamicPropIdList[idx]
                                });
                            }
                        }
                    }
                    successHandler(result, data);
                }.bind(this);
                xHReq.send();
            };
            BundleProductPropertiesController.prototype.getSaveRequestXml = function (allEntitiesXml) {
                return '<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/"><s:Header><SdkClientVersion xmlns="http://schemas.microsoft.com/xrm/2011/Contracts">9.0</SdkClientVersion></s:Header><s:Body><Execute xmlns="http://schemas.microsoft.com/xrm/2011/Contracts/Services" xmlns:i="http://www.w3.org/2001/XMLSchema-instance"><request i:type="b:ExecuteMultipleRequest" xmlns:a="http://schemas.microsoft.com/xrm/2011/Contracts" xmlns:b="http://schemas.microsoft.com/xrm/2011/Contracts"><a:Parameters xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"><a:KeyValuePairOfstringanyType><b:key>Requests</b:key><b:value i:type="c:OrganizationRequestCollection" xmlns:c="http://schemas.microsoft.com/xrm/2012/Contracts">' + allEntitiesXml + '</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>Settings</b:key><b:value i:type="c:ExecuteMultipleSettings" xmlns:c="http://schemas.microsoft.com/xrm/2012/Contracts"><c:ContinueOnError>true</c:ContinueOnError><c:ReturnResponses>true</c:ReturnResponses></b:value></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestId i:nil="true" /><a:RequestName>ExecuteMultiple</a:RequestName></request></Execute></s:Body></s:Envelope>';
            };
            BundleProductPropertiesController.prototype.getSaveRequestEntityXml = function (prop) {
                var colData = prop.getColData();
                return '<c:OrganizationRequest i:type="a:RetrieveRequest"><a:Parameters><a:KeyValuePairOfstringanyType><b:key>Target</b:key><b:value i:type="a:Entity"><a:Attributes xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic">' +
                    prop.getBundleProductNameAndValueDataForSave(colData) +
                    '<a:KeyValuePairOfstringanyType><b:key>regardingobjectid</b:key><b:value i:type="a:EntityReference"><a:Id>' +
                    this.model.ProductId + '</a:Id><a:LogicalName>productassociation</a:LogicalName></b:value>' +
                    '</a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>isreadonly</b:key><b:value i:type="c:boolean" xmlns:c="http://www.w3.org/2001/XMLSchema">' +
                    prop.isReadOnly +
                    '</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>name</b:key><b:value i:type="c:string" xmlns:c="http://www.w3.org/2001/XMLSchema">' +
                    prop.name +
                    '</b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>datatype</b:key><b:value i:type="a:OptionSetValue"><a:Value>' +
                    prop.dataType +
                    '</a:Value></b:value></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>statecode</b:key><b:value i:type="a:OptionSetValue"><a:Value>' +
                    prop.stateCode +
                    '</a:Value></b:value></a:KeyValuePairOfstringanyType>' +
                    this.baseDynamicPropData(prop) +
                    '</a:Attributes>' +
                    '<a:EntityState i:nil="true"/><a:FormattedValues xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/><a:Id>' +
                    prop.dynamicPropId +
                    '</a:Id><a:LogicalName>dynamicproperty</a:LogicalName><a:RelatedEntities xmlns:b="http://schemas.datacontract.org/2004/07/System.Collections.Generic"/></b:value>' +
                    '</a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>SuppressDuplicateDetection</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>CalculateMatchCodeSynchronously</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>SolutionUniqueName</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType><a:KeyValuePairOfstringanyType><b:key>MaintainLegacyAppServerBehavior</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType>' + this.getConcurrencyBehavior(prop) + '<a:KeyValuePairOfstringanyType><b:key>ReturnRowVersion</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType></a:Parameters><a:RequestName>' + this.getRequestName(prop) + '</a:RequestName></c:OrganizationRequest>';
            };
            BundleProductPropertiesController.prototype.isCreateCall = function (prop) {
                if (this.model.ProductId.toLowerCase() !== prop.regardingObjectId.toLowerCase() || prop.stateCode === 0) {
                    return true;
                }
                return false;
            };
            BundleProductPropertiesController.prototype.getConcurrencyBehavior = function (prop) {
                if (!this.isCreateCall(prop)) {
                    return '<a:KeyValuePairOfstringanyType><b:key>ConcurrencyBehavior</b:key><b:value i:nil="true" /></a:KeyValuePairOfstringanyType>';
                }
                return '';
            };
            BundleProductPropertiesController.prototype.getRequestName = function (prop) {
                if (!this.isCreateCall(prop)) {
                    return 'Update';
                }
                return 'Create';
            };
            BundleProductPropertiesController.prototype.baseDynamicPropData = function (prop) {
                if (!this.isCreateCall(prop)) {
                    return '';
                }
                return '<a:KeyValuePairOfstringanyType><b:key>basedynamicpropertyid</b:key><b:value i:type="a:EntityReference"><a:Id>' +
                    prop.dynamicPropId + '</a:Id><a:LogicalName>dynamicproperty</a:LogicalName></b:value></a:KeyValuePairOfstringanyType>';
            };
            BundleProductPropertiesController.prototype.createProperty = function (dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode) {
                var prop;
                if (dataType === EditProperties.DynamicPropertyDataType.OptionSet) {
                    prop = new EditProperties.BundleProductOptionSetProperty(dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode);
                }
                else {
                    prop = new EditProperties.BundleProductProperty(dynamicPropId, dynamicPropInstanceId, propName, dataType, regardingObjectId, valueString, valueDecimal, valueInteger, valueDouble, optionName, optionValue, minValueDecimal, maxValueDecimal, minValueDouble, maxValueDouble, minValueInteger, maxValueInteger, maxLengthString, isReadOnly, isHidden, isRequired, defaultValueOptionSet, context, iteration, stateCode);
                }
                return prop;
            };
            return BundleProductPropertiesController;
        }(EditProperties.ProductPropertiesControllerBase));
        EditProperties.BundleProductPropertiesController = BundleProductPropertiesController;
        var RetrieveEntityDynamicPropertyDefinitions = (function () {
            function RetrieveEntityDynamicPropertyDefinitions(entityName, regardingObjectId) {
                this.RegardingObject = {
                    entityType: 'productassociation',
                    id: regardingObjectId
                };
                this.ForDraftRegarding = true;
            }
            RetrieveEntityDynamicPropertyDefinitions.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    parameterTypes: {
                        "RegardingObject": {
                            "typeName": "mscrm.crmbaseentity",
                            "structuralProperty": 5
                        },
                        "ForDraftRegarding": {
                            "typeName": "Edm.Boolean",
                            "structuralProperty": 1
                        }
                    },
                    operationName: "RetrieveEntityDynamicPropertyDefinitions",
                    operationType: 1
                };
                return metadata;
            };
            return RetrieveEntityDynamicPropertyDefinitions;
        }());
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="../../../../TypeDefinitions/AppCommon/Telemetry/TelemetryLibrary.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var EditProperties;
    (function (EditProperties) {
        'use strict';
        var EditPropertiesControl = (function () {
            /**
             * Empty constructor.
             */
            function EditPropertiesControl() {
                /**
                 * Model for this control to store data
                 */
                this.model = new EditProperties.EditPropertiesModel();
                this.AppCommonNullCheck = function () {
                    return ((typeof (AppCommon) !== 'undefined') &&
                        (AppCommon != null && AppCommon != undefined) &&
                        (AppCommon.TelemetryReporter != null && AppCommon.TelemetryReporter != undefined) &&
                        (AppCommon.TelemetryReporter.Instance() != null && AppCommon.TelemetryReporter.Instance() != undefined));
                };
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            EditPropertiesControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                if (this.AppCommonNullCheck()) {
                    AppCommon.TelemetryReporter.Instance().PostStartMarker("SalesWebResources", "EditPropertiesControl", "init", this.model.ProductId);
                }
                this.model.init(context);
                this.model.isRTL = context.client.isRTL;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
                EditProperties.ProductPropertiesControllerBase.nullifyInstance();
                this.controller.fetchData();
                this.createControlTitle();
                if (this.AppCommonNullCheck()) {
                    AppCommon.TelemetryReporter.Instance().PostEndMarker("SalesWebResources", "EditPropertiesControl", "init", this.model.ProductId);
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            EditPropertiesControl.prototype.updateView = function (context) {
                this.children = [];
                if (this.controller instanceof EditProperties.BundleProductPropertiesController) {
                    // add header
                    var header = this.model.context.factory.createElement("CONTAINER", {
                        id: "EditPropertiesControlHeader",
                        key: "EditPropertiesContainerHeader",
                        style: {
                            "display": "block",
                            "width": "100%",
                            "margin-top": "0.3125rem",
                            "position": "fixed",
                            "background-color": this.model.context.theming.colors.whitebackground
                        }
                    }, [this.getHeaderLabel(EditProperties.LOC_KEYS.PROPERTY_NAME, "40%"), this.getHeaderLabel(EditProperties.LOC_KEYS.DEFAULT_VALUE, "26%", "0"), this.getHeaderLabel(EditProperties.LOC_KEYS.EDITABLE, "15%")]);
                    this.children.push(header);
                }
                if (this.model.properties) {
                    for (var i = 0; i < this.model.properties.length; i++) {
                        var prop = this.model.properties[i];
                        if (prop.container) {
                            if (i == 0 && this.controller instanceof EditProperties.BundleProductPropertiesController) {
                                prop.container.getProperties().style["margin-top"] = "2.5rem";
                            }
                            this.children.push(prop.container);
                        }
                    }
                }
                if (this.children.length > 0) {
                    if ($(".ms-crm-Inline-EmptyValue").length > 0) {
                        $(".ms-crm-Inline-EmptyValue").removeClass("ms-crm-Inline-Value").removeClass("ms-crm-Inline-EmptyValue");
                    }
                    var container = this.model.context.factory.createElement("CONTAINER", {
                        id: "EditPropertiesControlContainer",
                        key: "EditPropertiesContainer",
                        style: {
                            "display": "block",
                            "width": "100%",
                            "color": this.model.context.theming.colors.grays.gray03,
                            "background-color": this.model.context.theming.colors.whitebackground
                        }
                    }, this.children);
                    return container;
                }
            };
            EditPropertiesControl.prototype.getHeaderLabel = function (value, width, paddingLeft) {
                if (paddingLeft === void 0) { paddingLeft = "0.625rem"; }
                value = this.model.context.resources.getString(value);
                var label = this.model.context.factory.createElement("LABEL", {
                    id: "editpropertiesheader_" + value,
                    key: "editpropertiesheaderkey_" + value,
                    style: {
                        fontSize: this.model.context.theming.fontsizes.font100,
                        fontFamilies: this.model.context.theming.fontfamilies.semibold,
                        border: "none",
                        color: this.model.context.theming.colors.grays.gray06
                    }
                }, value);
                return this.model.context.factory.createElement("CONTAINER", {
                    id: "EditPropertiesHeaderContainerItem_" + value,
                    key: "EditPropertiesHeaderContainerItemKey_" + value,
                    style: {
                        "display": "inline-block",
                        "width": width,
                        "padding-left": this.model.isRTL ? 0 : paddingLeft,
                        "padding-right": this.model.isRTL ? paddingLeft : 0,
                        textAlign: this.model.isRTL ? "right" : "left",
                        "background-color": this.model.context.theming.colors.whitebackground
                    }
                }, [label]);
            };
            Object.defineProperty(EditPropertiesControl.prototype, "controller", {
                get: function () {
                    return EditProperties.ProductPropertiesControllerBase.getControllerInstance(this.model);
                },
                enumerable: true,
                configurable: true
            });
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            EditPropertiesControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return {};
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            EditPropertiesControl.prototype.destroy = function () {
            };
            EditPropertiesControl.prototype.createInputBox = function (props) {
                var input = this.model.context.factory.createElement("TEXTINPUT", props);
                return input;
            };
            /**
             * creates the control title (product name that is selected)
             */
            EditPropertiesControl.prototype.createControlTitle = function () {
                var context = this.model.context;
                var elem = document.createElement("div");
                elem.style.cssText = "font-size: 1.25rem; font-family: 'SegoeUI', 'Segoe UI'; width: 100%";
                elem.id = "productNameLabel";
                elem.innerHTML = this.model.ProductName;
                var headerItem = $('[data-id="dialogHeader"]');
                headerItem.append(elem);
            };
            return EditPropertiesControl;
        }());
        EditProperties.EditPropertiesControl = EditPropertiesControl;
    })(EditProperties = MscrmControls.EditProperties || (MscrmControls.EditProperties = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="Validation.ts" />
/// <reference path="Property.ts" />
/// <reference path="EditPropertiesModel.ts" />
/// <reference path="IProductPropertiesController.ts" />
/// <reference path="ProductPropertiesControllerBase.ts" />
/// <reference path="OppQuoteInvoiceOrderProductPropertiesController.ts" />
/// <reference path="BundleProductPropertiesController.ts" />
/// <reference path="EditPropertiesControl.ts" /> 
//# sourceMappingURL=EditPropertiesControl.js.map