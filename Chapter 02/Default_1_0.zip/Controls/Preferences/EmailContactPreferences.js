/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrmcomponents.d.ts" />
/// <reference path="../../../../jsreferences/external/TypeDefinitions/jquery.d.ts" />
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/XrmClientApi.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/lib.es6.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EmailContactPreferences;
    (function (EmailContactPreferences) {
        'use strict';
        var Preferences = (function () {
            /**
             * Empty constructor.
             */
            function Preferences() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            Preferences.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                this._context = context;
                this._id_tableHeaderLeft = this._context.parameters.id_tableHeaderLeft.raw;
                this.id_preferences = this._context.parameters.id_preferences.raw;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            Preferences.prototype.updateView = function (context) {
                // custom code goes here
                this._context = context;
                this._id_tableHeaderLeft = this._context.resources.getString("CustomControl_EmailEngagementPreferences_Recipient_Header_label");
                var id_tableHeaderRight = this._context.resources.getString("CustomControl_EmailEngagementPreferences_Preference_Header_label");
                this.id_followText = this._context.resources.getString("CustomControl_EmailEngagementPreferences_Allow_label");
                this.id_donotFollowText = this._context.resources.getString("CustomControl_EmailEngagementPreferences_Dont_Allow_Label");
                this.initContactPrefResources(this._context);
                this._notifyOutputChanged();
                var controls = [];
                controls.push(this.tableHeader(this._id_tableHeaderLeft, id_tableHeaderRight));
                controls.push(this.tableBody(this.id_preferences));
                return this.createContainerWithControls(controls, "completePage");
            };
            Preferences.prototype.initContactPrefResources = function (context) {
            };
            /**
             * Generates container element for passed array with controls
             * @param controls - array with elements which are need to be wrapped
             * @param containerSuffix - suffix for the container id and key
             * @returns container element with passed controls
             */
            Preferences.prototype.createContainerWithControls = function (controls, containerSuffix) {
                return this._context.factory.createElement("CONTAINER", {
                    key: "containerWithControls" + containerSuffix,
                    id: "containerWithControls" + containerSuffix,
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%",
                        marginTop: this._context.theming.measures.measure075
                    }
                }, controls);
            };
            /**
             * This function will create preferences table header
             */
            Preferences.prototype.tableHeader = function (thLeft, thRight) {
                var leftHeader = this._context.factory.createElement("LABEL", {
                    id: "thLeftLabel",
                    key: "thLeftLabel",
                    accessibilityLabel: thLeft,
                    role: "columnheader",
                    style: {
                        fontSize: "16px",
                        display: "block",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingTop: this._context.theming.measures.measure075,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050
                    }
                }, thLeft);
                var leftHeaderWrapper = this._context.factory.createElement("CONTAINER", {
                    id: "thLeftLabelContainer",
                    key: "thLeftLabelContainer",
                    style: {
                        display: "inline-block",
                        width: "50%"
                    }
                }, leftHeader);
                var rightHeader = this._context.factory.createElement("LABEL", {
                    key: "thRightLabel",
                    id: "thRightLabel",
                    accessibilityLabel: thRight,
                    role: "columnheader",
                    style: {
                        fontSize: "16px",
                        display: "block",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingTop: this._context.theming.measures.measure075,
                        paddingLeft: this._context.theming.measures.measure050,
                        paddingRight: this._context.theming.measures.measure050
                    }
                }, thRight);
                var rightHeaderWrapper = this._context.factory.createElement("CONTAINER", {
                    key: "thRightLabelContainer",
                    id: "thRightLabelContainer",
                    accessibilityLabel: thRight,
                    style: {
                        justifyContent: "space-between",
                        alignItems: "center",
                        display: "inline-block",
                        width: "50%"
                    }
                }, rightHeader);
                return this._context.factory.createElement("CONTAINER", {
                    key: "tableHeaderContainer",
                    id: "tableHeaderContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        display: "block",
                        width: "100%"
                    }
                }, [leftHeaderWrapper, rightHeaderWrapper]);
            };
            /**
             * This function will open contact info
             */
            Preferences.prototype.openContactEntity = function (entityName, entityId) {
                Xrm.Utility.openEntityForm(entityName, entityId);
            };
            ;
            /**
             * This function will create preferences table content
             */
            Preferences.prototype.tableBody = function (id_preferences) {
                var rows = [];
                for (var _i = 0, id_preferences_1 = id_preferences; _i < id_preferences_1.length; _i++) {
                    var pref = id_preferences_1[_i];
                    var allowText = pref.emailPreference == true ? this.id_followText : this.id_donotFollowText;
                    var leftLabel = this._context.factory.createElement("BUTTON", {
                        id: "nameLabel" + pref.entityDisplayName,
                        key: "nameLabel" + pref.entityDisplayName,
                        role: "link",
                        style: {
                            fontSize: "16px",
                            display: "block",
                            paddingBottom: this._context.theming.measures.measure075,
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure050,
                            paddingRight: this._context.theming.measures.measure050,
                            textDecoration: "none",
                            background: "none",
                            border: "none",
                            color: this._context.theming.colors.links["default"],
                            target: "_blank",
                            pointerEvents: "none"
                        },
                        describedByElementId: this._context.accessibility.getUniqueId("thLeftLabel")
                    }, pref.entityDisplayName);
                    var leftLabelWrapper = this._context.factory.createElement("CONTAINER", {
                        id: "nameLabelContainer" + pref.entityDisplayName,
                        key: "nameLabelContainer" + pref.entityDisplayName,
                        style: {
                            display: "inline-block",
                            width: "50%",
                            cursor: "pointer"
                        },
                        onClick: this.openContactEntity.bind(this, pref.entityName, pref.entityId)
                    }, leftLabel);
                    var rightLabel = this._context.factory.createElement("LABEL", {
                        key: "allowLabel" + pref.entityDisplayName,
                        id: "allowLabel" + pref.entityDisplayName,
                        accessibilityLabel: allowText,
                        tabIndex: 0,
                        style: {
                            fontSize: "16px",
                            display: "block",
                            paddingBottom: this._context.theming.measures.measure075,
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure050,
                            paddingRight: this._context.theming.measures.measure050
                        },
                        describedByElementId: this._context.accessibility.getUniqueId("thRightLabel")
                    }, allowText);
                    var rightLabelWrapper = this._context.factory.createElement("CONTAINER", {
                        key: "allowLabelContainer" + pref.entityDisplayName,
                        id: "allowLabelContainer" + pref.entityDisplayName,
                        style: {
                            justifyContent: "space-between",
                            alignItems: "center",
                            display: "inline-block",
                            width: "50%"
                        }
                    }, rightLabel);
                    var rowContainer = this._context.factory.createElement("CONTAINER", {
                        key: "rowContainer" + pref.entityDisplayName,
                        id: "rowContainer" + pref.entityDisplayName,
                        style: {
                            backgroundColor: this._context.theming.colors.whitebackground,
                            display: "block",
                            width: "100%"
                        }
                    }, [leftLabelWrapper, rightLabelWrapper]);
                    rows.push(rowContainer);
                }
                return this._context.factory.createElement("CONTAINER", {
                    key: "TableBodyContainer",
                    id: "TableBodyContainer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        display: "block",
                        width: "100%"
                    }
                }, rows);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            Preferences.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                var result = {
                    id_preferences: this.id_preferences,
                    id_tableHeaderLeft: this._id_tableHeaderLeft
                };
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            Preferences.prototype.destroy = function () {
            };
            return Preferences;
        }());
        EmailContactPreferences.Preferences = Preferences;
    })(EmailContactPreferences = MscrmControls.EmailContactPreferences || (MscrmControls.EmailContactPreferences = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="EmailContactPreferences.ts" /> 
