/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrmcomponents.d.ts" />
/// <reference path="../../../../jsreferences/external/TypeDefinitions/jquery.d.ts" />
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../jsreferences/internal/TypeDefinitions/lib.es6.d.ts" />
/// <reference path="CommonReferences.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EmailDelayDialogControl;
    (function (EmailDelayDialogControl) {
        'use strict';
        var DelayDialogControl = (function () {
            /**
             * Empty constructor.
             */
            function DelayDialogControl() {
                this._changeHandler = this._onChange.bind(this);
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            DelayDialogControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                this._context = context;
                this._id_lastButtonClicked = this._context.parameters.id_lastButtonClicked.raw;
                this._id_delayedSendTime = this._context.parameters.id_delayedSendTime.raw;
                this._id_dateErrorText = this._context.parameters.id_dateErrorText.raw;
                this._id_footerText = this._context.parameters.id_footerText.raw;
                this._id_now = this._context.parameters.id_now.raw;
                this._notifyOutputChanged = notifyOutputChanged || (function () { });
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            DelayDialogControl.prototype.updateView = function (context) {
                // custom code goes here
                this._context = context;
                var controls = [];
                controls.push(this.createDateTimeComponent());
                controls.push(this.delayInfoFooter());
                return this.createContainerWithControls(controls, "completePage");
            };
            /**
             * Handles a change of a inout data for the date control
             * @param change change event object wrapper.
             * @param type Start date vs End Date.
             */
            DelayDialogControl.prototype._onChange = function (type, change) {
                var controlValue = change ? new Date(change) : null;
                this._id_delayedSendTime = controlValue;
                this._notifyOutputChanged();
                this.renderControl(true);
            };
            /**
            * Initiate the request render available in the utils
            */
            DelayDialogControl.prototype.renderControl = function (render, callback) {
                if (render === void 0) { render = false; }
                if (callback === void 0) { callback = null; }
                if (render) {
                    this._context.utils.requestRender(callback);
                }
            };
            /**
             * This function will create the Date Time Component
             */
            DelayDialogControl.prototype.createDateTimeComponent = function () {
                var _this = this;
                var typeString = this._context.resources.getString("CustomControl_EmailEngagementDelay_Start_Date");
                var send_At_Label = this._context.resources.getString("CustomControl_EmailEngagementDelay_Send_At");
                var inputDate = this._id_delayedSendTime;
                var properties = {
                    "parameters": {
                        "value": {
                            Usage: 3 /*PropertyUsage.FalseBound*/,
                            Static: true,
                            Value: inputDate,
                            Type: "DateAndTime.DateAndTime",
                            Callback: function (change) { return _this._changeHandler(typeString, change); },
                            Attributes: {
                                Format: "datetime",
                                Type: "datetime",
                                Behavior: 1,
                                RequiredLevel: 1
                            }
                        },
                        "deviceSizeMode": {
                            Usage: 1,
                            Static: true,
                            Value: 0,
                            Type: "Enum",
                            Primary: false
                        },
                        "describedByElementId": {
                            Usage: 1,
                            Value: this._context.accessibility.getUniqueId("send_label"),
                            Static: true
                        }
                    },
                    style: {
                        padding: this._context.theming.measures.measure050,
                        fontFamilies: this._context.theming.fontfamilies.regular,
                        fonstSize: this._context.theming.fontsizes.font100,
                        color: this._context.theming.colors.grays.gray07
                    }
                };
                var dateLabel = this._context.factory.createElement("LABEL", {
                    id: "send_label",
                    key: "send_label",
                    accessibilityLabel: send_At_Label,
                    style: {
                        fontSize: "16px",
                        width: "8rem",
                        alignItems: "center",
                        flexGrow: "0",
                        overflow: "hidden"
                    }
                }, send_At_Label);
                var dateComponent = this._context.factory.createComponent("MscrmControls.FieldControls.DateTimeControl", "Start_Date_MDD", properties);
                var infoIcon = this._context.factory.createElement('MICROSOFTICON', {
                    key: 'Condition_requiredIcon',
                    id: 'Condition_requiredIcon',
                    type: 181,
                    accessibilityHidden: true
                });
                var infoIconWrapper = this._context.factory.createElement('CONTAINER', {
                    key: 'condition_icon_wrapper',
                    id: 'condition_icon_wrapper',
                    style: {
                        padding: "5px",
                        width: "20px",
                        color: "#ff0000"
                    }
                }, infoIcon);
                return this._context.factory.createElement("CONTAINER", {
                    key: "date_time_Container",
                    id: "date_time_Container",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        alignItems: "center",
                        paddingBottom: this._context.theming.measures.measure050,
                        borderBottom: this._context.theming.borders.border02
                    }
                }, [infoIconWrapper, dateLabel, dateComponent]);
            };
            /**
             * This function will create the footer for Delay Section
             */
            DelayDialogControl.prototype.delayInfoFooter = function () {
                var delay_Time = this._id_delayedSendTime.localeFormat(this._context.client.dateFormattingInfo.ShortTimePattern.toString());
                var delay_Date = this._id_delayedSendTime.localeFormat(this._context.client.dateFormattingInfo.ShortDatePattern.toString());
                this.delayInfoLabel = MscrmCommon.ControlUtils.String.Format(this._context.resources.getString("CustomControl_EmailEngagementDelay_Email_Delay_Footer"), delay_Date, delay_Time);
                var footerLabel = this._context.factory.createElement("LABEL", {
                    id: "send_footer_label",
                    key: "send_footer_label",
                    accessibilityLabel: this.delayInfoLabel,
                    style: {
                        fontSize: "16px",
                        paddingRight: this._context.theming.measures.measure075
                    }
                }, this.delayInfoLabel);
                return this._context.factory.createElement("CONTAINER", {
                    key: "delay_MDD_footer",
                    id: "delay_MDD_footer",
                    style: {
                        backgroundColor: this._context.theming.colors.whitebackground,
                        justifyContent: "space-between",
                        display: "flex",
                        paddingBottom: this._context.theming.measures.measure075,
                        paddingTop: this._context.theming.measures.measure075
                    }
                }, footerLabel);
            };
            DelayDialogControl.prototype.getTimeInUserPrefTimeZone = function (date) {
                date.setMinutes(date.getMinutes() + date.getTimezoneOffset() + this._context.client.getUserTimeZoneUtcOffset(date));
                return date;
            };
            /**
              * Generates container element for passed array with controls
              * @param controls - array with elements which are need to be wrapped
              * @param containerSuffix - suffix for the container id and key
              * @returns container element with passed controls
              */
            DelayDialogControl.prototype.createContainerWithControls = function (controls, containerSuffix) {
                return this._context.factory.createElement("CONTAINER", {
                    key: "containerWithControls" + containerSuffix,
                    id: "containerWithControls" + containerSuffix,
                    style: {
                        flexDirection: "column",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        width: "100%"
                    }
                }, controls);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            DelayDialogControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                var result = {
                    id_lastButtonClicked: this._id_lastButtonClicked,
                    id_delayedSendTime: this._id_delayedSendTime,
                    id_now: this._id_now,
                    id_footerText: this._id_footerText,
                    id_dateErrorText: this._id_dateErrorText
                };
                return result;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            DelayDialogControl.prototype.destroy = function () {
            };
            return DelayDialogControl;
        }());
        EmailDelayDialogControl.DelayDialogControl = DelayDialogControl;
    })(EmailDelayDialogControl = MscrmControls.EmailDelayDialogControl || (MscrmControls.EmailDelayDialogControl = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="EmailDelaySendControl.ts" /> 
