var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="GenericTreeControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/// <reference path="privatereferences.ts"/>
/// <reference path="CommonReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var GenericTree;
        (function (GenericTree) {
            'use strict';
            var TreeManager = (function () {
                function TreeManager(context, notifyOutputChanged) {
                    this._context = context;
                    this._treeView = new GenericTree.TreeView(context, this);
                    this._treeNodes = {};
                    this._notifyOutputChanged = notifyOutputChanged;
                }
                /**
                 * Returns the final component containing the tree structures
                 * @param nodes the list of nodes from which tree is to be created
                 */
                TreeManager.prototype.getTreeComponent = function (nodes) {
                    this._buildTree(nodes);
                    return this._treeView.getTreeComponent(this._treeNodes);
                };
                /**
                 * Toggle the expanded/collapsed states of node
                 * @param nodeId the node id upon which the action is done
                 * @param mode current status of the node
                 */
                TreeManager.prototype.toggleNodeExpandedState = function (nodeId) {
                    this.setSelectedNode(nodeId);
                    if (!this._treeNodes[nodeId].expanded) {
                        this._treeNodes[nodeId].expanded = true;
                    }
                    else {
                        this._treeNodes[nodeId].expanded = false;
                    }
                };
                /**
                 * set the expanded state to mode
                 * @param nodeId the node id upon which the action is done
                 * @param mode to which the state should be
                 */
                TreeManager.prototype.setNodeState = function (nodeId, mode) {
                    this.setSelectedNode(nodeId);
                    if (mode === undefined) {
                        mode = false;
                    }
                    this._treeNodes[nodeId].expanded = mode;
                };
                /**
                 * Sets the id, entity referece and formatted value of the selected subject.
                 * @param subjectId the subject id
                 * @param reference the entity reference
                 * @param value the formatted value
                 */
                TreeManager.prototype.setSelectedNode = function (nodeId, dblclick) {
                    if (nodeId == null) {
                        this.selectedNode = null;
                        this.setSelectedNodeEntityReference(null);
                    }
                    else {
                        this.selectedNode = this._treeNodes[nodeId];
                        if (dblclick != null && dblclick == true) {
                            this.selectedNode.additionalParams = {
                                dblclick: true
                            };
                        }
                        else {
                            this.selectedNode.additionalParams = null;
                        }
                        this.setSelectedNodeEntityReference(this.selectedNode);
                    }
                    this._notifyOutputChanged();
                };
                /**
                 * Returns currently selected node id
                 * @returns {string}
                 */
                TreeManager.prototype.getSelectedNodeId = function () {
                    if (this.selectedNode) {
                        return this.selectedNode.id;
                    }
                    return null;
                };
                /**
                 * Returns tree node object by id
                 * @param nodeId identifier of the node
                 * @returns {ITreeNode}
                 */
                TreeManager.prototype.getTreeNode = function (nodeId) {
                    return this._treeNodes[nodeId];
                };
                /**
                 * Build the tree out of list of nodes
                 * @param nodes the list of nodes from which tree is to be constructed
                 */
                TreeManager.prototype._buildTree = function (nodes) {
                    var _this = this;
                    var refreshedNodes = {};
                    nodes.forEach(function (node) {
                        if (!_this._treeNodes[node.id]) {
                            var newNode = {};
                            newNode.id = node.id;
                            newNode.children = [];
                            newNode.displayValue = node.displayValue;
                            newNode.expanded = false;
                            newNode.depth = -1;
                            newNode.parentNode = null;
                            refreshedNodes[node.id] = newNode;
                        }
                        else {
                            _this._treeNodes[node.id].children.length = 0;
                            _this._treeNodes[node.id].parentNode = null;
                            _this._treeNodes[node.id].depth = -1;
                            _this._treeNodes[node.id].displayValue = node.displayValue;
                            refreshedNodes[node.id] = _this._treeNodes[node.id];
                        }
                    });
                    this._treeNodes = refreshedNodes;
                    // refreshing the parent child nodes
                    nodes.forEach(function (node) {
                        if (node.parentId) {
                            var parentNode = _this._treeNodes[node.parentId];
                            var childNode = _this._treeNodes[node.id];
                            parentNode.children.push(childNode);
                            childNode.parentNode = parentNode;
                        }
                    });
                    //update depth
                    this._updateDepth(0);
                };
                /**
                 * DFS to update depth of each node in the tree
                 * @param depth the current depth
                 * @param recordNode the node currently in consideration
                 */
                TreeManager.prototype._updateDepth = function (depth, recordNode) {
                    var _this = this;
                    if (recordNode && recordNode.depth == -1) {
                        return;
                    }
                    if (depth == 0) {
                        for (var treeNode in this._treeNodes) {
                            var node = this._treeNodes[treeNode];
                            if (!node.parentNode) {
                                node.depth = depth;
                                this._updateDepth(depth + 1, node);
                            }
                        }
                    }
                    else {
                        recordNode.children.forEach(function (node) {
                            node.depth = depth;
                            _this._updateDepth(depth + 1, node);
                        });
                    }
                };
                TreeManager.prototype.setSelectedNodeEntityReference = function (selectedNode) {
                    var id = selectedNode ? selectedNode.id : null;
                    var name = selectedNode ? selectedNode.displayValue : null;
                    var parentNode = selectedNode ? selectedNode.parentNode : null;
                    var _additionalParams = selectedNode ? selectedNode.additionalParams : null;
                    var selectedSubject = {
                        displayValue: name,
                        id: id,
                        parentId: parentNode ? parentNode.id : null,
                        additionalParams: _additionalParams
                    };
                    this.setSelectedNodeEntityReferenceInternal(selectedSubject);
                };
                TreeManager.prototype.setSelectedNodeEntityReferenceInternal = function (reference) {
                    this.node = reference;
                };
                TreeManager.prototype.getSelectedNodeEntityReference = function () {
                    return this.node;
                };
                return TreeManager;
            }());
            GenericTree.TreeManager = TreeManager;
        })(GenericTree = AppCommon.GenericTree || (AppCommon.GenericTree = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/// <reference path="privatereferences.ts"/>
/// <reference path="CommonReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var GenericTree;
        (function (GenericTree) {
            'use strict';
            var TreeView = (function () {
                function TreeView(context, treeManager) {
                    this._context = context;
                    this._treeManager = treeManager;
                    this._applyStyles = new GenericTree.TreeStyles(context);
                    this._dblclickhandler = {};
                }
                /**
                 * Gets the component with the entire tree rendered
                 * @param treeNodes the list of tree nodes that are to be rendered
                 */
                TreeView.prototype.getTreeComponent = function (treeNodes) {
                    var _this = this;
                    this._treeComponents = [];
                    this._indexIdMapping = {};
                    this._idIndexMapping = {};
                    this._counter = 0;
                    this._getTreeNodes(this._treeComponents, treeNodes);
                    return this._context.factory.createElement("CONTAINER", {
                        id: "tree-container",
                        key: "tree-container",
                        role: "tree-container",
                        paddingLeft: this._context.theming.measures.measure100,
                        style: {
                            display: "block",
                            overflow: "auto",
                            width: "100%",
                            padding: "10px",
                        },
                        onClick: ((this._context.mode.isControlDisabled) ? null : function (event) {
                            _this._selectNode(null);
                        }),
                    }, this._treeComponents);
                };
                /**
                 * Returns the element containing the node and its children
                 * @param nodeId the identifier of the node which is to be rendered
                 * @param cNode the subtree that is to be rendered for this node
                 * @param lastNodeOnLevel whether it is a leaf node or not
                 */
                TreeView.prototype._getTreeElement = function (nodeId, cNode, lastNodeOnLevel) {
                    return this._context.factory.createElement("LIST", {
                        id: "treenode-container-" + nodeId,
                        key: "treenode-container-" + nodeId,
                        role: "treenode-container",
                        style: lastNodeOnLevel ? this._applyStyles.treeLastElementStyle : this._applyStyles.treeInnerElementStyle
                    }, cNode);
                };
                /**
                 * Makes the list of all the nodes with no parent and their subtree
                 * @param treeComponents the list which should contain the elemtents with no parent
                 * @param treeNodes the nodes list from which tree is to be made
                 */
                TreeView.prototype._getTreeNodes = function (treeComponents, treeNodes) {
                    var counter = 0;
                    for (var node in treeNodes)
                        if (treeNodes[node].depth == 0)
                            counter++;
                    for (var node in treeNodes) {
                        if (treeNodes[node].depth == 0) {
                            counter--;
                            var lastNodeOnLevel = (counter == 0);
                            this._indexIdMapping[this._counter] = treeNodes[node].id;
                            this._idIndexMapping[treeNodes[node].id] = this._counter;
                            var cNode = void 0;
                            cNode = [];
                            treeComponents.push(this._getTreeNode(treeNodes[node], lastNodeOnLevel));
                            this._counter++;
                            if (treeNodes[node].expanded) {
                                this._getChildNodes(cNode, treeNodes[node]);
                            }
                            if (cNode.length != 0) {
                                treeComponents.push(this._getTreeElement(treeNodes[node].id, cNode, lastNodeOnLevel));
                            }
                        }
                    }
                };
                /**
                 * DFS to make the subtree with given parent node
                 * @param treeComponents the list which should contain the elemtents with given parent
                 * @param treeNode the parent node whose subtree is to be rendered
                 */
                TreeView.prototype._getChildNodes = function (treeComponents, treeNode) {
                    var _this = this;
                    treeNode.children.forEach(function (node) {
                        var lastNodeOnLevel = (treeNode.children[treeNode.children.length - 1] == node);
                        _this._indexIdMapping[_this._counter] = node.id;
                        _this._idIndexMapping[node.id] = _this._counter;
                        var cNode;
                        cNode = [];
                        treeComponents.push(_this._getTreeNode(node, lastNodeOnLevel));
                        _this._counter++;
                        if (node.expanded) {
                            _this._getChildNodes(cNode, node);
                        }
                        if (cNode.length != 0) {
                            treeComponents.push(_this._getTreeElement(node.id, cNode, lastNodeOnLevel));
                        }
                    });
                };
                /**
                 * Created the list item that renders a node
                 * @param treeNode the node which is to be created
                 * @param lastNodeOnLevel whether its a leaf node
                 */
                TreeView.prototype._getTreeNode = function (treeNode, lastNodeOnLevel) {
                    var _this = this;
                    var nodeId = treeNode.id;
                    var _a = this._context.theming, _b = _a.lookup, tagbackgroundcolor = _b.tagbackgroundcolor, tagpadding = _b.tagpadding, restmodecolor = _a.textbox.restmodecolor;
                    var index = this._idIndexMapping[treeNode.id];
                    var childNodes = treeNode.children;
                    var showChildNodes = childNodes.length > 0 && treeNode.expanded;
                    var listItemId = "treeitem-" + index;
                    var listItem = this._context.factory.createElement("LISTITEM", {
                        id: listItemId,
                        key: listItemId,
                        accessibilityExpanded: treeNode.children.length > 0 ? treeNode.expanded : null,
                        accessibilityLevel: treeNode.depth + 1,
                        isSelected: false,
                        role: "treeitem",
                        tabIndex: ((index == 0) && (this._treeManager.getSelectedNodeId() == null)) ? 0 : -1,
                        style: lastNodeOnLevel ? this._applyStyles.treeLastItemStyle : this._applyStyles.treeInnerItemStyle,
                        onKeyDown: this._context.mode.isControlDisabled ? null : function (event) {
                            _this._onSubjectKeyDown(event, nodeId);
                        },
                        onFocus: ((this._context.mode.isControlDisabled)) ? null : function (event) {
                            _this._selectNode(nodeId);
                        }
                    }, [this._getLineIcon(treeNode, lastNodeOnLevel), this._getLineLabel(treeNode)]);
                    return listItem;
                };
                /**
                 * Renders the subject expand icon
                 * @param treeNode a subject node element
                 * @param lastNodeOnLevel flag indicating whether to render the border or not
                 * @returns a subject icon component
                 */
                TreeView.prototype._getLineIcon = function (treeNode, lastNodeOnLevel) {
                    var _this = this;
                    var nodeId = treeNode.id;
                    var iconId = nodeId + "-icon";
                    var dashId = nodeId + "-icon-dash";
                    var iconContainerId = nodeId + "-icon-container";
                    var iconRole = (treeNode.children.length > 0) ? (treeNode.expanded ? "icon-role-expanded" : "icon-role-collapsed") : "icon-role-none";
                    if (this._context.userSettings.isRTL) {
                        iconRole = iconRole + '-rtl';
                    }
                    var ico = this._context.factory.createElement("CONTAINER", {
                        id: iconId,
                        key: iconId,
                        role: iconRole,
                        accessibilityLabel: treeNode.expanded ? "Group expanded" : "Group collapsed",
                        style: {
                            display: "block",
                            width: "14px",
                            height: "14px",
                        },
                        onClick: ((this._context.mode.isControlDisabled)) ? null : function (event) {
                            _this._onSubjectLineClick(event, treeNode);
                        },
                        onFocus: ((this._context.mode.isControlDisabled)) ? null : function (event) {
                            _this._selectNode(nodeId);
                        }
                    }, []);
                    var dash = this._context.factory.createElement("CONTAINER", {
                        id: dashId,
                        key: dashId,
                        style: {
                            width: this._context.theming.measures.measure125,
                            height: "50%",
                            marginBottom: "50%",
                            display: "inline-block",
                            borderBottom: this._applyStyles._customBorderStyle.border,
                            borderLeft: (this._context.userSettings.isRTL) ? "inherent" : (lastNodeOnLevel ? this._applyStyles._customBorderStyle.border : "inherent"),
                            borderRight: (!this._context.userSettings.isRTL) ? "inherent" : (lastNodeOnLevel ? this._applyStyles._customBorderStyle.border : "inherent"),
                        },
                    });
                    return this._context.factory.createElement("CONTAINER", {
                        id: iconContainerId,
                        key: iconContainerId,
                        style: {
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                        }
                    }, [dash, ico]);
                };
                /**
                 * Handles onkeydown event for the subject line in the control.
                 * @param event the keyboard event
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._onSubjectKeyDown = function (event, nodeId) {
                    var keyCode = event.keyCode;
                    if (keyCode == 37 && this._context.userSettings.isRTL) {
                        keyCode = 39;
                    }
                    else if (keyCode == 39 && this._context.userSettings.isRTL) {
                        keyCode = 37;
                    }
                    switch (keyCode) {
                        case 13:
                            // Press enter to select
                            this._selectNode(nodeId);
                            break;
                        case 35:
                            this.moveFocusToTreeLastElement();
                            break;
                        case 36:
                            this.moveFocusToTreeFirstElement();
                            break;
                        case 37:
                            event.preventDefault();
                            this._collapseBranch(nodeId);
                            break;
                        case 39:
                            event.preventDefault();
                            var branch = this._treeManager.getTreeNode(nodeId);
                            if ((branch.expanded === false) && (branch.children.length != 0)) {
                                this._expandBranch(nodeId);
                            }
                            break;
                        case 38:
                            event.preventDefault();
                            this._moveFocusUp(nodeId);
                            break;
                        case 40:
                            event.preventDefault();
                            this._moveFocusDown(nodeId);
                            break;
                    }
                };
                /**
                 * Renders the subject label for list component
                 * @param treeNode a subject node element
                 * @returns a subject label component
                 */
                TreeView.prototype._getLineLabel = function (treeNode) {
                    var _this = this;
                    var formattedValue = treeNode.displayValue;
                    var index = this._idIndexMapping[treeNode.id];
                    var nodeId = treeNode.id;
                    return this._context.factory.createElement("LABEL", {
                        id: "treeitemlabel-" + index,
                        key: "treeitemlabel-" + index,
                        title: formattedValue,
                        style: this._applyStyles.treeLabelStyle,
                        onClick: ((this._context.mode.isControlDisabled)) ? null : function (event) {
                            _this._onSubjectLineClick(event, treeNode);
                        },
                        onFocus: ((this._context.mode.isControlDisabled)) ? null : function (event) {
                            _this._selectNode(nodeId);
                        }
                    }, formattedValue);
                };
                /**
                 * Handles onclick event for the subject line in the control.
                 * @param event
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._onSubjectLineClick = function (event, treeNode) {
                    var _this = this;
                    if (this._dblclickhandler[treeNode.id] == null) {
                        this._dblclickhandler[treeNode.id] = true;
                        setTimeout(function () {
                            if (_this._dblclickhandler[treeNode.id] == true) {
                                _this._handleSingleClick(event, treeNode);
                            }
                            _this._dblclickhandler[treeNode.id] = null;
                        }, 200);
                    }
                    else {
                        this._dblclickhandler[treeNode.id] = null;
                        this._handleDoubleClick(event, treeNode);
                    }
                };
                /**
                 * Handles singleclick event for the subject line in the control.
                 * @param event
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._handleSingleClick = function (event, treeNode) {
                    var nodeId = treeNode.id;
                    var focus = event.type == "focus";
                    this._dblclickhandler[treeNode.id] = null;
                    event.stopPropagation();
                    this._selectNode(nodeId);
                    if (treeNode.children.length > 0) {
                        this._toggleBranch(nodeId);
                    }
                };
                /**
                 * Handles doubleclick event for the subject line in the control.
                 * @param event
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._handleDoubleClick = function (event, treeNode) {
                    var nodeId = treeNode.id;
                    this._dblclickhandler[treeNode.id] = null;
                    var focus = event.type == "focus";
                    event.stopPropagation();
                    this._selectNode(nodeId, true);
                };
                /**
                 * Toggles selected branch
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._toggleBranch = function (nodeId) {
                    this._treeManager.toggleNodeExpandedState(nodeId);
                    this._context.utils.requestRender();
                };
                /**
                 * Selects a node.
                 * @param nodeId id of the node to be selected
                 */
                TreeView.prototype._selectNode = function (nodeId, dblclick) {
                    var currSelectedNodeId = this._treeManager.getSelectedNodeId();
                    var currSelectedNodeBranchIndex = this._idIndexMapping[currSelectedNodeId];
                    if (currSelectedNodeId && currSelectedNodeBranchIndex != undefined) {
                        var currSelectedNodeUniqueId = this._context.accessibility.getUniqueId("treeitem-" + currSelectedNodeBranchIndex);
                        var currSelectedNodeDOM = document.getElementById(currSelectedNodeUniqueId);
                        currSelectedNodeDOM.setAttribute('tabindex', '-1');
                        currSelectedNodeDOM.setAttribute('aria-selected', 'false');
                    }
                    this._treeManager.setSelectedNode(nodeId, dblclick);
                    if (nodeId) {
                        var nextSelectedNodeId = this._treeManager.getSelectedNodeId();
                        var nextSelectedNodeBranchIndex = this._idIndexMapping[nextSelectedNodeId];
                        var nextSelectedNodeUniqueId = this._context.accessibility.getUniqueId("treeitem-" + nextSelectedNodeBranchIndex);
                        var nextSelectedNodeDOM = document.getElementById(nextSelectedNodeUniqueId);
                        nextSelectedNodeDOM.setAttribute('tabindex', '0');
                        nextSelectedNodeDOM.setAttribute('aria-selected', 'true');
                        var branchIndex = this._idIndexMapping[nodeId];
                        this._context.accessibility.focusElementById("treeitem-" + branchIndex);
                    }
                    else if (this._indexIdMapping[0]) {
                        var nextSelectedNodeBranchIndex = 0;
                        var nextSelectedNodeUniqueId = this._context.accessibility.getUniqueId("treeitem-" + nextSelectedNodeBranchIndex);
                        var nextSelectedNodeDOM = document.getElementById(nextSelectedNodeUniqueId);
                        nextSelectedNodeDOM.setAttribute('tabindex', '0');
                    }
                };
                /**
                 * Expands selected branch
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._expandBranch = function (nodeId) {
                    this._treeManager.setNodeState(nodeId, true);
                    this._context.utils.requestRender();
                };
                /**
                 * Collapses selected branch
                 * @param nodeId identifier of the subject in the result list
                 */
                TreeView.prototype._collapseBranch = function (nodeId) {
                    this._treeManager.setNodeState(nodeId, false);
                    this._context.utils.requestRender();
                };
                /**
                 * Moves focus to the first list item on the tree.
                 */
                TreeView.prototype.moveFocusToTreeFirstElement = function () {
                    this._selectNode(this._indexIdMapping[0]);
                };
                /**
                 * Moves focus to the last list item on the tree.
                 */
                TreeView.prototype.moveFocusToTreeLastElement = function () {
                    this._selectNode(this._indexIdMapping[this._counter - 1]);
                };
                /**
                 * move focus to the element above, don't loop around
                 * @param nodeId the identifier of the node at whcih the event started
                 */
                TreeView.prototype._moveFocusUp = function (nodeId) {
                    var branchIndex = this._idIndexMapping[nodeId];
                    if (branchIndex == 0) {
                        return;
                    }
                    branchIndex--;
                    this._selectNode(this._indexIdMapping[branchIndex]);
                };
                /**
                 * move focus to the element below, don't loop around
                 * @param nodeId the identifier of the node at whcich the event started
                 */
                TreeView.prototype._moveFocusDown = function (nodeId) {
                    var branchIndex = this._idIndexMapping[nodeId];
                    if (branchIndex == this._counter) {
                        return;
                    }
                    branchIndex++;
                    this._selectNode(this._indexIdMapping[branchIndex]);
                };
                return TreeView;
            }());
            GenericTree.TreeView = TreeView;
        })(GenericTree = AppCommon.GenericTree || (AppCommon.GenericTree = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
/// <reference path="privatereferences.ts"/>
/// <reference path="CommonReferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var GenericTree;
        (function (GenericTree) {
            'use strict';
            var TreeStyles = (function () {
                function TreeStyles(context) {
                    this._customBorderStyle = {
                        border: "1px dashed "
                    };
                    this._context = context;
                    this._customBorderStyle.border += this._context.theming.colors.grays.gray04;
                }
                Object.defineProperty(TreeStyles.prototype, "treeInnerElementStyle", {
                    get: function () {
                        return {
                            paddingLeft: (this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure200,
                            borderLeft: (this._context.userSettings.isRTL) ? "inherent" : this._customBorderStyle.border,
                            paddingRight: (!this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure200,
                            borderRight: (!this._context.userSettings.isRTL) ? "inherent" : this._customBorderStyle.border,
                            display: "block"
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TreeStyles.prototype, "treeLastElementStyle", {
                    get: function () {
                        return {
                            paddingLeft: (this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure200,
                            borderLeft: (this._context.userSettings.isRTL) ? "inherent" : "0px",
                            paddingRight: (!this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure200,
                            borderRight: (!this._context.userSettings.isRTL) ? "inherent" : "0px",
                            display: "block"
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TreeStyles.prototype, "treeInnerItemStyle", {
                    get: function () {
                        return {
                            backgroundColor: "inherent",
                            height: this._context.theming.measures.measure250,
                            cursor: "pointer",
                            display: "flex",
                            flexDirection: "row",
                            flexWrap: "inherent",
                            borderLeft: this._context.userSettings.isRTL ? "inherent" : this._customBorderStyle.border,
                            borderRight: this._context.userSettings.isRTL ? this._customBorderStyle.border : "inherent",
                            ":focus label": {
                                backgroundColor: this._context.theming.colors.grays.gray03
                            }
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TreeStyles.prototype, "treeLastItemStyle", {
                    get: function () {
                        return {
                            backgroundColor: "inherent",
                            height: this._context.theming.measures.measure250,
                            cursor: "pointer",
                            display: "flex",
                            flexDirection: "row",
                            flexWrap: "inherent",
                            borderLeft: this._context.userSettings.isRTL ? "inherent" : "",
                            borderRight: this._context.userSettings.isRTL ? "" : "inherent",
                            ":focus label": {
                                backgroundColor: this._context.theming.colors.grays.gray03
                            },
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TreeStyles.prototype, "treeLineIconStyle", {
                    get: function () {
                        return {
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: this._context.theming.fontsizes.font085,
                            marginLeft: (this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure050,
                            marginRight: (!this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure050,
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(TreeStyles.prototype, "treeLabelStyle", {
                    get: function () {
                        return {
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            paddingTop: this._context.theming.measures.measure050,
                            paddingBottom: this._context.theming.measures.measure050,
                            paddingRight: (!this._context.userSettings.isRTL) ? this._context.theming.measures.measure600 : this._context.theming.measures.measure100,
                            paddingLeft: (this._context.userSettings.isRTL) ? this._context.theming.measures.measure600 : this._context.theming.measures.measure100,
                            fontSize: "15px",
                            color: this._context.theming.textbox.contentcolor,
                            display: "block",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                            whiteSpace: "nowrap",
                            cursor: "inherit",
                            marginLeft: (this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure025,
                            marginRight: (!this._context.userSettings.isRTL) ? "inherent" : this._context.theming.measures.measure025,
                            ":hover": {
                                backgroundColor: this._context.theming.colors.grays.gray01
                            }
                        };
                    },
                    enumerable: true,
                    configurable: true
                });
                return TreeStyles;
            }());
            GenericTree.TreeStyles = TreeStyles;
        })(GenericTree = AppCommon.GenericTree || (AppCommon.GenericTree = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="TreeManager.ts"/>
/// <reference path="TreeView.ts"/>
/// <reference path="TreeStyles.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var GenericTree;
        (function (GenericTree) {
            'use strict';
            var GenericTreeControl = (function () {
                /**
                 * Constructor requires a function as parameter to retreive the tree contents
                 * @param _treeData
                 * @param _context
                 */
                function GenericTreeControl() {
                    this.treeNodes = {};
                    this.selectedNode = null;
                    this.treeData = [];
                }
                /**
                 * Returns the final component containing the tree structures
                 */
                GenericTreeControl.prototype.getTreeComponent = function () {
                    return this.treeManager.getTreeComponent(this.treeData);
                };
                /**
                 * Returns the identifier for the node which is currently selected
                 */
                GenericTreeControl.prototype.getSelectedNodeId = function () {
                    return this.treeManager.getSelectedNodeId();
                };
                GenericTreeControl.prototype.getSelectedNodeEntityReference = function () {
                    return this.treeManager.getSelectedNodeEntityReference();
                };
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                GenericTreeControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this.context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this.treeManager = new GenericTree.TreeManager(context, this._notifyOutputChanged);
                    this.isRTL = this.context.userSettings.isRTL;
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                GenericTreeControl.prototype.updateView = function (context) {
                    this.treeData = this.context.parameters.treeData.raw;
                    return this.getTreeComponent();
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                GenericTreeControl.prototype.getOutputs = function () {
                    return {
                        value: this.getSelectedNodeEntityReference()
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                GenericTreeControl.prototype.destroy = function () {
                };
                return GenericTreeControl;
            }());
            GenericTree.GenericTreeControl = GenericTreeControl;
        })(GenericTree = AppCommon.GenericTree || (AppCommon.GenericTree = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../AppCommon/Client/Controls/FREShell/libs/FREShell.d.ts" />
/// <reference path="../../../../AppCommon/Client/Controls/FREShell/libs/frecommon-lib.d.ts" />
/// <reference path="../../../../AppCommon/Client/Controls/GenericTree/GenericTreeControl.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var Constants = (function () {
                function Constants() {
                }
                return Constants;
            }());
            /**
             * Path for Icon for Subject Tree.
             * Images need be shipped as WebResources.
             */
            Constants.HeaderNormalIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SubjectTreeConfig.svg";
            Constants.HeaderHighContrastIconImagePath = "../../WebResources/AppCommon/ControlWS/HeaderIconImages/SubjectTreeConfig_HC.svg";
            Constants.SubjectAddButtonIconContainerKey = "SubjectTreeConfigPage.AddButton_label";
            Constants.SubjectAddButtonKey = "SubjectTreeConfigPage.AddButton";
            Constants.SubjectRemoveButtonIconContainerKey = "SubjectTreeConfigPage.RemoveButton_label";
            Constants.SubjectRemoveButtonKey = "SubjectTreeConfigPage.RemoveButton";
            Constants.SubjectEditButtonIconContainerKey = "SubjectTreeConfigPage.EditButton_label";
            Constants.SubjectEditButtonKey = "SubjectTreeConfigPage.EditButton";
            Constants.SubjectHeaderSeparatorContainerKey = "SubjectTreeConfigPage.ButtonSeparator";
            Constants.SubjectHeaderRightContainerKey = "SubjectTreeConfigPage.HeaderRightContainer";
            Constants.AddSubjectDialogName = "AddSubject";
            Constants.SubjectRetrieveTableName = "subject";
            Constants.EditSubjectDialogName = "EditSubject";
            SubjectTreeConfig.Constants = Constants;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var FREShell = MscrmControls.AppCommon.FREShell;
            var SubjectTreeConfigControl = (function () {
                /**
                 *  constructor.
                 */
                function SubjectTreeConfigControl() {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                    this._treeData = [];
                    this._fetchedNodesFromDB = false;
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 */
                SubjectTreeConfigControl.prototype.init = function (context, notifyOutputChanged, state) {
                    this._context = context;
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this._freShell = new FREShell(context, this._context.resources.getString(SubjectTreeConfig.LabelId.AdvancedSettingsText));
                    this._applyStyles = new SubjectTreeConfig.SubjectTreeConfigStyles(context);
                    if (!this._fetchedNodesFromDB)
                        this._updateSubjectTreeData();
                    /**
                     * telemetry end points and data to be added...
                     */
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                SubjectTreeConfigControl.prototype.updateView = function (context) {
                    this._context = context;
                    return this._freShell.getVirtualComponents(this.getChildControls());
                };
                /**
                 * Provides child controls to the shell which can then be used to create correct hierarchy of controls.
                 */
                SubjectTreeConfigControl.prototype.getChildControls = function () {
                    var params = {};
                    params.normalIconImagePath = SubjectTreeConfig.Constants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = SubjectTreeConfig.Constants.HeaderHighContrastIconImagePath;
                    params.areaLabel = this._context.resources.getString(SubjectTreeConfig.LabelId.AreaLabel);
                    params.subAreaLabel = this._context.resources.getString(SubjectTreeConfig.LabelId.SubAreaLabel);
                    // Create the right container having buttons.
                    params.headerRightContainerChild = this.createHeaderRightContainer();
                    //icon content
                    params.normalIconImagePath = SubjectTreeConfig.Constants.HeaderNormalIconImagePath;
                    params.highContrastIconImagePath = SubjectTreeConfig.Constants.HeaderHighContrastIconImagePath;
                    if (this._treeData.length != 0) {
                        var properties = {
                            parameters: {},
                            key: "subjectTreeControl",
                            id: "subjectTreeControl",
                            contextString: "subgrid",
                            configuration: {
                                FormFactor: 3 /* Desktop */,
                                CustomControlId: "MscrmControls.AppCommon.GenericTree.GenericTreeControl",
                                Name: "treeControl-Config",
                                Version: "1.0.0",
                                Parameters: {
                                    value: this.getValueParameter(this.onSelectionChanged.bind(this)),
                                    treeData: {
                                        Static: true,
                                        Type: "IInputNode",
                                        Value: this._treeData,
                                        Primary: false,
                                    }
                                }
                            }
                        };
                        params.contentContainerChild = this._context.factory.createComponent("MscrmControls.AppCommon.GenericTree.GenericTreeControl", "treeControl", properties);
                    }
                    return params;
                };
                SubjectTreeConfigControl.prototype.getValueParameter = function (callback) {
                    return {
                        Usage: 3,
                        Static: false,
                        Value: [],
                        Type: "IInputNode",
                        Callback: callback,
                    };
                };
                SubjectTreeConfigControl.prototype.onSelectionChanged = function (e) {
                    if (e) {
                        var selectedSubject = {
                            id: e.id,
                            LogicalName: "Subject",
                            name: e.displayValue,
                            entityName: "Subject"
                        };
                        this.selectedSubjectParentId = e.parentId;
                        this.selectedSubject = selectedSubject;
                        this._notifyOutputChanged();
                        if (e.additionalParams && e.additionalParams["dblclick"]) {
                            this.onEditSubjectClick(null);
                        }
                    }
                    else {
                        console.log("Unexpected value recieved: " + e);
                    }
                };
                SubjectTreeConfigControl.prototype._updateSubjectTreeData = function (pagenumber) {
                    var _this = this;
                    this._fetchedNodesFromDB = true;
                    if (!pagenumber) {
                        pagenumber = 1;
                        this._treeData.length = 0;
                    }
                    var fetchAllSubjectRecords = '?$select=title,subjectid,_parentsubject_value,description';
                    var pagenumberSelector = '&$skiptoken=<cookie pagenumber="' + pagenumber.toString() + '"/>';
                    this._context.webAPI.retrieveMultipleRecords(SubjectTreeConfig.Constants.SubjectRetrieveTableName, fetchAllSubjectRecords + pagenumberSelector).then(function (subjectRecordsResponse) {
                        var data = [];
                        if (subjectRecordsResponse.entities.length > 0) {
                            subjectRecordsResponse.entities.forEach(function (subject) {
                                var node = {
                                    displayValue: subject.title,
                                    id: subject.subjectid,
                                    parentId: subject._parentsubject_value,
                                    additionalParams: {
                                        description: subject.description
                                    }
                                };
                                data.push(node);
                            });
                        }
                        if (_this._treeData.length == 0) {
                            _this._treeData = data;
                        }
                        else {
                            _this._treeData = _this._treeData.concat(data);
                        }
                        if (subjectRecordsResponse.nextLink) {
                            _this._updateSubjectTreeData(pagenumber + 1);
                        }
                        else {
                            _this._context.utils.requestRender();
                        }
                    }, function (error) {
                        _this._fetchedNodesFromDB = false;
                        console.log(error);
                    });
                };
                /**
                 * Creates RightContainer for header
                 */
                SubjectTreeConfigControl.prototype.createHeaderRightContainer = function () {
                    var addSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectAddButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectAddButtonIconContainerKey,
                        type: 8,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var addSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectAddButtonKey, id: SubjectTreeConfig.Constants.SubjectAddButtonKey,
                        onClick: this.onAddSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectButtonToolTip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [addSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectButtonLabel)]);
                    var editSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectEditButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectEditButtonIconContainerKey,
                        type: 4,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var editSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectEditButtonKey, id: SubjectTreeConfig.Constants.SubjectEditButtonKey,
                        onClick: this.onEditSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectButtonToolTip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [editSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectButtonLabel)]);
                    var removeSubjectButtonIcon = this._context.factory.createElement("MICROSOFTICON", {
                        key: SubjectTreeConfig.Constants.SubjectRemoveButtonIconContainerKey, id: SubjectTreeConfig.Constants.SubjectRemoveButtonIconContainerKey,
                        type: 7,
                        style: this._applyStyles.FRERightButtonIconContainer()
                    }, []);
                    var removeSubjectButton = this._context.factory.createElement("BUTTON", {
                        key: SubjectTreeConfig.Constants.SubjectRemoveButtonKey, id: SubjectTreeConfig.Constants.SubjectRemoveButtonKey,
                        onClick: this.onRemoveSubjectClick.bind(this),
                        title: this._context.resources.getString(SubjectTreeConfig.LabelId.RemoveSubjectButtonToolTip), tabindex: "0",
                        style: this._applyStyles.FREHeaderRightButtonStyle()
                    }, [removeSubjectButtonIcon, this._context.resources.getString(SubjectTreeConfig.LabelId.RemoveSubjectButtonLabel)]);
                    var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                        key: SubjectTreeConfig.Constants.SubjectHeaderSeparatorContainerKey, id: SubjectTreeConfig.Constants.SubjectHeaderSeparatorContainerKey,
                        style: this._applyStyles.FREHeaderSeparatorContainer()
                    }, []);
                    var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                        key: SubjectTreeConfig.Constants.SubjectHeaderRightContainerKey, id: SubjectTreeConfig.Constants.SubjectHeaderRightContainerKey,
                        style: this._applyStyles.FREHeaderRightContainer()
                    }, [headerSeparatorContainer, addSubjectButton, headerSeparatorContainer, editSubjectButton, headerSeparatorContainer, removeSubjectButton]);
                    return headerRightContainer;
                };
                SubjectTreeConfigControl.prototype.onAddSubjectClick = function (event) {
                    var dialogOptions = {};
                    dialogOptions.position = 2 /* side */;
                    var dialogArguements = {};
                    dialogArguements["selected_subject"] = this.selectedSubject;
                    var _that = this;
                    this._context.navigation.openDialog(SubjectTreeConfig.Constants.AddSubjectDialogName, dialogOptions, dialogArguements)
                        .then(function (resp) {
                        if (resp.parameters.last_selected_button == "save") {
                            _that._updateSubjectTreeData();
                            var confirmMessage = _that._context.resources.getString(SubjectTreeConfig.LabelId.AddSubjectConfirmation);
                            _that._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                //Notification displayed successfully
                            }, function (error) {
                                console.error("Error displaying notification : " + error);
                            });
                        }
                        _that.selectedSubject = null;
                    }, function (error) {
                        _that.errorCallback(error);
                    });
                };
                SubjectTreeConfigControl.prototype.onEditSubjectClick = function (event) {
                    var _this = this;
                    var selectedEditSubject = this.selectedSubject;
                    if (selectedEditSubject && selectedEditSubject['name']) {
                        var parentSubjectId_1, parentSubjectName_1, description_1;
                        this._treeData.forEach(function (node) {
                            if (node.id == _this.selectedSubjectParentId) {
                                parentSubjectId_1 = node.id;
                                parentSubjectName_1 = node.displayValue;
                            }
                            if (node.id == selectedEditSubject.id) {
                                description_1 = node.additionalParams.description;
                            }
                        });
                        var selectedSubjectParent = {
                            id: (parentSubjectId_1 == undefined) ? null : parentSubjectId_1,
                            LogicalName: "Subject",
                            name: (parentSubjectName_1 == undefined) ? null : parentSubjectName_1,
                            entityName: "Subject",
                            childName: selectedEditSubject.name,
                            childId: selectedEditSubject.id,
                            description: description_1
                        };
                        var dialogOptions = {};
                        dialogOptions.position = 2 /* side */;
                        var dialogArguements = {};
                        dialogArguements["selected_subject"] = selectedSubjectParent;
                        var _that_1 = this;
                        this._context.navigation.openDialog(SubjectTreeConfig.Constants.EditSubjectDialogName, dialogOptions, dialogArguements)
                            .then(function (resp) {
                            if (resp.parameters.last_selected_button == "save") {
                                _that_1._updateSubjectTreeData();
                                var confirmMessage = _that_1._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectConfirmation);
                                _that_1._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                    //Notification displayed successfully
                                }, function (error) {
                                    console.error("Error displaying notification : " + error);
                                });
                            }
                            _that_1.selectedSubject = null;
                        }, function (error) {
                            _that_1.errorCallback(error);
                        });
                    }
                    else {
                        //Open Alert Dialog
                        var alertMessage = {
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.EditSubjectAlertDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.OK)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                    }
                };
                SubjectTreeConfigControl.prototype.onRemoveSubjectClick = function (event) {
                    if (this.selectedSubject && this.selectedSubject.id) {
                        var _that_2 = this;
                        //Open a confirm dialog
                        var dialogOptions = {};
                        dialogOptions.position = 1 /* center */;
                        var confirmDialogStrings = {
                            title: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteDialogConfirmationTitle),
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteDialogConfirmationDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteLabel),
                            cancelButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.CancelLabel)
                        };
                        this._context.navigation.openConfirmDialog(confirmDialogStrings, dialogOptions)
                            .then(function (result) {
                            if (result.confirmed) {
                                _that_2._context.webAPI.deleteRecord("subject", _that_2.selectedSubject.id).then(function (success) {
                                    _that_2._updateSubjectTreeData();
                                    var confirmMessage = _that_2._context.resources.getString(SubjectTreeConfig.LabelId.DeleteSubjectConfrimation);
                                    _that_2._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, confirmMessage, "", null).then(function (response) {
                                        //Notification displayed successfully
                                    }, function (error) {
                                        console.error("Error displaying notification : " + error);
                                    });
                                }, function (failure) {
                                    _that_2.errorCallback(failure);
                                });
                            }
                            _that_2.selectedSubject = null;
                        });
                    }
                    else {
                        //Open Alert Dialog
                        var alertMessage = {
                            text: this._context.resources.getString(SubjectTreeConfig.LabelId.DeleteSubjectAlertDescription),
                            confirmButtonLabel: this._context.resources.getString(SubjectTreeConfig.LabelId.OK)
                        };
                        this._context.navigation.openAlertDialog(alertMessage);
                    }
                };
                SubjectTreeConfigControl.prototype.errorCallback = function (error) {
                    Mscrm.AppCommon.Common.Utility.actionFailedErrorDialog(error);
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                SubjectTreeConfigControl.prototype.getOutputs = function () {
                    return {
                        selectedSubject: this.selectedSubject
                    };
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                SubjectTreeConfigControl.prototype.destroy = function () {
                    this._context = null;
                    this._freShell = null;
                    this._applyStyles = null;
                };
                return SubjectTreeConfigControl;
            }());
            SubjectTreeConfig.SubjectTreeConfigControl = SubjectTreeConfigControl;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
///<reference path="privatereferences.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var LabelId = (function () {
                function LabelId() {
                }
                return LabelId;
            }());
            /**
             * Subject Tree Configuration Control ARIA label.
             * Label value: SubjectTreeConfigControl
             */
            LabelId.AreaLabel = "SubjectHomePage.AreaLabel";
            LabelId.SubAreaLabel = "SubjectHomePage.SubAreaLabel";
            LabelId.AddSubjectButtonLabel = "SubjectHomePage.AddSubjectButtonLabel";
            LabelId.AddSubjectButtonToolTip = "SubjectHomePage.AddSubjectButtonToolTip";
            LabelId.EditSubjectButtonLabel = "SubjectHomePage.EditSubjectButtonLabel";
            LabelId.EditSubjectButtonToolTip = "SubjectHomePage.EditSubjectButtonToolTip";
            LabelId.RemoveSubjectButtonLabel = "SubjectHomePage.RemoveSubjectButtonLabel";
            LabelId.RemoveSubjectButtonToolTip = "SubjectHomePage.RemoveSubjectButtonToolTip";
            LabelId.DeleteDialogConfirmationTitle = "SubjectDialogue.DeleteSubjectConfirmationTitle";
            LabelId.DeleteDialogConfirmationDescription = "SubjectDialogue.DeleteSubjectConfirmationDescription";
            LabelId.DeleteLabel = "SubjectDialogue.DeleteLabel";
            LabelId.ConfirmLabel = "SubjectDialogue.ConfirmLabel";
            LabelId.CancelLabel = "SubjectDialogue.CancelLabel";
            LabelId.DeleteSubjectAlertDescription = "SubjectDialogue.DeleteSubjectAlertDescription";
            LabelId.EditSubjectAlertDescription = "SubjectDialogue.EditSubjectAlertDescription";
            LabelId.AddSubjectConfirmation = "SubjectHomePage.AddSubjectConfirmation";
            LabelId.EditSubjectConfirmation = "SubjectHomePage.EditSubjectConfirmation";
            LabelId.DeleteSubjectConfrimation = "SubjectHomePage.DeleteSubjectConfirmation";
            LabelId.OK = "SubjectDialogue.OK";
            LabelId.AdvancedSettingsText = "AdvancedSettingsText";
            LabelId.MicrosoftDynamics365Text = "MicrosoftDynamics365Text";
            SubjectTreeConfig.LabelId = LabelId;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var SubjectTreeConfig;
        (function (SubjectTreeConfig) {
            'use strict';
            var SubjectTreeConfigStyles = (function (_super) {
                __extends(SubjectTreeConfigStyles, _super);
                function SubjectTreeConfigStyles(context) {
                    var _this = _super.call(this, context) || this;
                    _this._subjectTreeConfigAddSubjectButtonIcon = {};
                    _this._subjectTreeConfigAddSubjectButtonLabel = {};
                    _this._subjectTreeConfigAddSubjectButtonText = {};
                    _this._subjectTreeConfigEditSubjectButtonIcon = {};
                    _this._subjectTreeConfigEditSubjectButtonLabel = {};
                    _this._subjectTreeConfigEditSubjectButtonText = {};
                    _this._subjectTreeConfigRemoveSubjectButtonIcon = {};
                    _this._subjectTreeConfigRemoveSubjectButtonLabel = {};
                    _this._subjectTreeConfigRemoveSubjectButtonText = {};
                    _this._context = context;
                    _this._subjectTreeConfigAddSubjectButtonIcon = null;
                    _this._subjectTreeConfigAddSubjectButtonLabel = null;
                    _this._subjectTreeConfigAddSubjectButtonText = null;
                    _this._subjectTreeConfigEditSubjectButtonIcon = null;
                    _this._subjectTreeConfigEditSubjectButtonLabel = null;
                    _this._subjectTreeConfigEditSubjectButtonText = null;
                    _this._subjectTreeConfigRemoveSubjectButtonIcon = null;
                    _this._subjectTreeConfigRemoveSubjectButtonLabel = null;
                    _this._subjectTreeConfigRemoveSubjectButtonText = null;
                    return _this;
                }
                SubjectTreeConfigStyles.prototype.SubjectTreeConfigAddSubjectButtonIcon = function () {
                    if (this._context.utils.isNullOrUndefined(this._subjectTreeConfigAddSubjectButtonIcon)) {
                        this._subjectTreeConfigAddSubjectButtonIcon = {};
                        this._subjectTreeConfigAddSubjectButtonIcon["margin"] = "0px";
                    }
                    return this._subjectTreeConfigAddSubjectButtonIcon;
                };
                SubjectTreeConfigStyles.prototype.SubjectTreeConfigAddSubjectButtonText = function () {
                    if (this._context.utils.isNullOrUndefined(this._subjectTreeConfigAddSubjectButtonText)) {
                        this._subjectTreeConfigAddSubjectButtonText = {};
                        this._subjectTreeConfigAddSubjectButtonText["margin"] = "0px";
                        this._subjectTreeConfigAddSubjectButtonText["fontSize"] = "16px";
                        this._subjectTreeConfigAddSubjectButtonText["color"] = "#0078D7";
                        this._subjectTreeConfigAddSubjectButtonText["letterSpacing"] = "0px";
                        this._subjectTreeConfigAddSubjectButtonText["whiteSpace"] = "nowrap";
                    }
                    return this._subjectTreeConfigAddSubjectButtonText;
                };
                return SubjectTreeConfigStyles;
            }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
            SubjectTreeConfig.SubjectTreeConfigStyles = SubjectTreeConfigStyles;
        })(SubjectTreeConfig = AppCommon.SubjectTreeConfig || (AppCommon.SubjectTreeConfig = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="Constants.ts" />
/// <reference path="SubjectTreeConfigControl.ts" />
/// <reference path="LabelId.ts" />
/// <reference path="SubjectTreeConfigStyles.ts" /> 
//# sourceMappingURL=SubjectTreeConfigControl.js.map