var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        var EmbeddedKnowledgeSearchConstants = (function () {
            function EmbeddedKnowledgeSearchConstants() {
            }
            return EmbeddedKnowledgeSearchConstants;
        }());
        // Constants for resx file
        EmbeddedKnowledgeSearchConstants.HeaderTitle = "HeaderTitle";
        EmbeddedKnowledgeSearchConstants.HeaderDescription = "HeaderDescription";
        EmbeddedKnowledgeSearchConstants.SaveLabel = "SaveLabel";
        EmbeddedKnowledgeSearchConstants.RecordTypeLabel = "RecordTypeLabel";
        EmbeddedKnowledgeSearchConstants.RecordTypeDescription = "RecordTypeDescription";
        EmbeddedKnowledgeSearchConstants.SupportPortalConnectionLabel = "SupportPortalConnectionLabel";
        EmbeddedKnowledgeSearchConstants.SupportPortalConnectionDescription = "SupportPortalConnectionDescription";
        EmbeddedKnowledgeSearchConstants.PortalLabel = "PortalLabel";
        EmbeddedKnowledgeSearchConstants.CheckboxLabel = "CheckboxLabel";
        EmbeddedKnowledgeSearchConstants.CheckboxDescription = "CheckboxDescription";
        EmbeddedKnowledgeSearchConstants.UrlFormatLabel = "UrlFormatLabel";
        EmbeddedKnowledgeSearchConstants.InvalidCrmUrl = "InvalidCrmUrl";
        EmbeddedKnowledgeSearchConstants.InvalidUrlNoKbNumber = "InvalidUrlNoKbNo";
        EmbeddedKnowledgeSearchConstants.InvalidUrlFormat = "InvalidUrlFormat";
        EmbeddedKnowledgeSearchConstants.SaveSuccessMessage = "SaveSuccessMessage";
        EmbeddedKnowledgeSearchConstants.SaveFailureMessage = "SaveFailureMessage";
        EmbeddedKnowledgeSearchConstants.EmptyUrlMessage = "EmptyUrlMessage";
        // Constants for element ids
        EmbeddedKnowledgeSearchConstants.DualListContainerId = "EKSEntityDualListContainer";
        EmbeddedKnowledgeSearchConstants.DualListId = "EKSEntityDualList";
        EmbeddedKnowledgeSearchConstants.SaveButtonId = "EKSSaveButton";
        EmbeddedKnowledgeSearchConstants.HeaderRightContainerId = "EKSHeaderRightContainer";
        EmbeddedKnowledgeSearchConstants.RecordTypeContainerId = "EKSRecordTypeContainer";
        EmbeddedKnowledgeSearchConstants.RecordTypeLabelId = "EKSRecordTypeLabel";
        EmbeddedKnowledgeSearchConstants.RecordTypeLabelContainerId = "EKSRecordTypeLabelContainer";
        EmbeddedKnowledgeSearchConstants.RecordTypeDescriptionId = "EKSRecordTypeDescription";
        EmbeddedKnowledgeSearchConstants.MainContainerId = "EKSMainContainer";
        EmbeddedKnowledgeSearchConstants.SupportPortalConnectionLabelId = "EKSSupportPortalConnectionLabel";
        EmbeddedKnowledgeSearchConstants.SupportProtalConnectionLabelcontainerId = "EKSSupportPortalConnectionLabelcontainer";
        EmbeddedKnowledgeSearchConstants.SupportPortalConnectionDescriptionId = "EKSSupportPortalConnectionDescription";
        EmbeddedKnowledgeSearchConstants.SupportPortalConnectionConatinerId = "EKSSupportPortalConnectionConatinerId";
        EmbeddedKnowledgeSearchConstants.PortalLabelId = "EKSPortalLabel";
        EmbeddedKnowledgeSearchConstants.PortalLabelConatinerId = "EKSPortalLabelContainer";
        EmbeddedKnowledgeSearchConstants.PortalColonLabel = "EKSPortalColonLabel";
        EmbeddedKnowledgeSearchConstants.CheckboxId = "EKSCheckbox";
        EmbeddedKnowledgeSearchConstants.CheckboxHolderId = "EKSCheckboxHolder";
        EmbeddedKnowledgeSearchConstants.CheckboxLabelId = "EKSCheckboxLabel";
        EmbeddedKnowledgeSearchConstants.Checkbox_Label_ContainerId = "EKSCheckbox_Label_Container";
        EmbeddedKnowledgeSearchConstants.CheckboxContainerId = "EKSCheckboxContainer";
        EmbeddedKnowledgeSearchConstants.CheckboxDescriptionId = "EKSCheckboxDescription";
        EmbeddedKnowledgeSearchConstants.Checkbox_Label_Description_ContainerId = "EKSCheckbox_Label_Description_Container";
        EmbeddedKnowledgeSearchConstants.UrlFormatLabelId = "EKSUrlFormatLabel";
        EmbeddedKnowledgeSearchConstants.UrlFormatColonLabelId = "EKSUrlFormatColonLabel";
        EmbeddedKnowledgeSearchConstants.UrlFormatLabelContainerId = "EKSUrlFormatLabelContainer";
        EmbeddedKnowledgeSearchConstants.UrlInputBoxId = "EKSUrlInputBox";
        EmbeddedKnowledgeSearchConstants.SaveIconContainerKey = "EKSSaveIconContainerKey";
        EmbeddedKnowledgeSearchConstants.HeaderSeparatorContainerKey = "EKSHeaderSeparatorContainerKey";
        // Constants for urls
        EmbeddedKnowledgeSearchConstants.RetrieveEntitiesMetadataUrl = "/api/data/v9.0/EntityDefinitions";
        EmbeddedKnowledgeSearchConstants.EntityMetadataFilter = "?$select=DisplayName,LogicalName,IsKnowledgeManagementEnabled&$filter=IsCustomizable/Value eq true and CanModifyAdditionalSettings/Value eq true";
        EmbeddedKnowledgeSearchConstants.UpdateEntityUrl = "/api/data/v9.0/EntityDefinitions";
        EmbeddedKnowledgeSearchConstants.BatchUrl = "/api/data/v9.0/$batch";
        EmbeddedKnowledgeSearchConstants.KMSettingsFilter = "?$select=kmsettings";
        // Entity names
        EmbeddedKnowledgeSearchConstants.Organization = "organization";
        EmbeddedKnowledgeSearchConstants.KMSettingsXml = "<KMSettings><UseExternalPortal>{0}</UseExternalPortal><NativeCrmUrl>{1}</NativeCrmUrl></KMSettings>";
        EmbeddedKnowledgeSearchConstants.UrlPlaceholder = "http://support.microsoft.com/kb/{kbnum}";
        //string constant
        EmbeddedKnowledgeSearchConstants.Colon = ":";
        // Header icon path
        EmbeddedKnowledgeSearchConstants.Header_Icon_Image = "../../WebResources/Service/_imgs/Controls/EmbeddedKnowledgeSearch/EmbeddedKnowledgeSearch.svg";
        EmbeddedKnowledgeSearchConstants.Header_Icon_HighContrast_Image = "../../WebResources/Service/_imgs/Controls/EmbeddedKnowledgeSearch/EmbeddedKnowledgeSearch_HC.svg";
        EKSearch.EmbeddedKnowledgeSearchConstants = EmbeddedKnowledgeSearchConstants;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        'use strict';
        var FREShell = MscrmControls.AppCommon.FREShell;
        var EKSearchControl = (function () {
            function EKSearchControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             */
            EKSearchControl.prototype.init = function (context, notifyOutputChanged, state) {
                this._context = context;
                EKSearch.EmbeddedKnowledgeSearchStyles.initialize(this._context.theming, this._context.client.isRTL);
                this._notifyOutputChanged = notifyOutputChanged;
                var title = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.HeaderTitle);
                this._freShell = new FREShell(context, title);
                if (this._context.utils.isNullOrUndefined(this._EKSearchModel)) {
                    this._EKSearchModel = new EKSearch.EmbeddedKnowledgeSearchModel(context);
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            EKSearchControl.prototype.updateView = function (context) {
                return this._freShell.getVirtualComponents(this.getChildControls(context));
            };
            EKSearchControl.prototype.getChildControls = function (context) {
                this._context = context;
                var params = {};
                params.normalIconImagePath = EKSearch.EmbeddedKnowledgeSearchConstants.Header_Icon_Image;
                params.highContrastIconImagePath = EKSearch.EmbeddedKnowledgeSearchConstants.Header_Icon_HighContrast_Image;
                // Setting header title
                params.areaLabel = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.HeaderDescription);
                params.subAreaLabel = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.HeaderTitle);
                // Setting Save button
                params.headerRightContainerChild = this.CreateHeaderRightContainer();
                var innerBodyContainer = null;
                if (this._context.utils.isNullOrUndefined(this._EKSearchModel)) {
                    this._EKSearchModel = new EKSearch.EmbeddedKnowledgeSearchModel(context);
                }
                else if (this._EKSearchModel.AllEntities.length > 0) {
                    innerBodyContainer = this.RenderMainPage();
                }
                params.contentContainerChild = innerBodyContainer;
                return params;
            };
            EKSearchControl.prototype.RenderMainPage = function () {
                // Creating Record type label
                var recordTypeLabel = this._context.factory.createElement("LABEL", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeLabelId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeLabelId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.headingLabel
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeLabel));
                var recordTypeLabelContainer = this._context.factory.createElement("CONTAINER", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeLabelContainerId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeLabelContainerId,
                }, [recordTypeLabel]);
                // Creating Record type description
                var recordTypeDescription = this._context.factory.createElement("LABEL", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeDescriptionId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeDescriptionId
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeDescription));
                // Putting record type label and description into one container
                var recordTypeContainer = this._context.factory.createElement("CONTAINER", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeContainerId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.RecordTypeContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.recordTypeContainer
                }, [recordTypeLabelContainer, recordTypeDescription]);
                // Setting properties for dual selection list
                var properties = {
                    "parameters": {
                        JsonOptions: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: JSON.stringify(this._EKSearchModel.AllEntities.map(function (c) {
                                return {
                                    Id: c.LogicalName, DisplayName: c.DisplayName
                                };
                            })),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "all_attributes",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: "text",
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        Selection: {
                            Usage: 3,
                            Static: true,
                            Type: "SingleLine.Text",
                            Value: this._EKSearchModel.SelectedEntities,
                            Callback: this.DualListSelectionCallback.bind(this),
                            Attributes: {
                                DisplayName: null,
                                LogicalName: "cc_selectedAttributes_id",
                                Type: "string",
                                IsSecured: false,
                                RequiredLevel: 0,
                                MaxLength: 2147483647,
                                EntityLogicalName: "",
                                Format: null,
                                ImeMode: -1,
                                Behavior: null
                            }
                        },
                        SelectionOrderBy: {
                            Value: 2,
                            Usage: 3,
                            Static: true,
                            Type: "Enum",
                            Attributes: {},
                        },
                        OptionSet: {
                            Usage: 3,
                            Static: true,
                            Type: null,
                            attributes: {},
                        }
                    }
                };
                // Creating dual list container
                var dualListContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.DualListContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.DualListContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.dualListContainer
                }, [this._context.factory.createComponent("MscrmControls.DualListSelection.DualListSelectionControl", EKSearch.EmbeddedKnowledgeSearchConstants.DualListId, properties)]);
                // Creating Support Portal connection label
                var supportProtalConnectionLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionLabelId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionLabelId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.headingLabel
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionLabel));
                var supportProtalConnectionLabelcontainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SupportProtalConnectionLabelcontainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SupportProtalConnectionLabelcontainerId,
                }, [supportProtalConnectionLabel]);
                // Creating Support Portal connection description
                var supportPortalConnectionDescription = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionDescriptionId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionDescriptionId
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionDescription));
                // Putting Support Portal connection label and description into one container
                var supportPortalConnectionContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionConatinerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SupportPortalConnectionConatinerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.supportPortalConnectionContainer
                }, [supportProtalConnectionLabelcontainer, supportPortalConnectionDescription]);
                // Creating portal label
                var portalLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.PortalLabelId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.PortalLabelId
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.PortalLabel));
                var portalColonLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.PortalColonLabel,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.PortalColonLabel,
                }, EKSearch.EmbeddedKnowledgeSearchConstants.Colon);
                var portalcontainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.PortalLabelConatinerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.PortalLabelConatinerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.headingLabel
                }, [portalLabel, portalColonLabel]);
                // Creating use an external portal checkbox
                var checkboxProperties = {
                    type: "checkbox",
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxId,
                    tagname: "INPUT",
                    tabIndex: 1,
                    value: this._EKSearchModel.UseExternalPortal,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkbox,
                    onValueChange: this.CheckBoxChanged.bind(this)
                };
                var checkbox = this._context.factory.createElement("BOOLEAN", checkboxProperties);
                var checkboxHolder = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxHolderId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxHolderId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkbox
                }, [checkbox]);
                // Creating label for checkbox
                var checkboxLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxLabelId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxLabelId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkboxLabel,
                    forElementId: this._context.accessibility.getUniqueId(EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxId)
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxLabel));
                var checkbox_Label_Container = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.Checkbox_Label_ContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.Checkbox_Label_ContainerId,
                }, [checkboxHolder, checkboxLabel]);
                // Creating description below checkbox
                var checkboxDescription = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxDescriptionId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxDescriptionId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkboxDescription
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxDescription));
                var checkbox_Label_Description_Container = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.Checkbox_Label_Description_ContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.Checkbox_Label_Description_ContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkbox_Label_Description_Container
                }, [checkbox_Label_Container, checkboxDescription]);
                // Moving portalLabel, checkbox and its label and description into one container
                var checkboxContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.CheckboxContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.checkboxContainer
                }, [portalcontainer, checkbox_Label_Description_Container]);
                // Creating url format label
                var urlFormatLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabelId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabelId
                }, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabel));
                var urlFormatColonLabel = this._context.factory.createElement("LABEL", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatColonLabelId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatColonLabelId
                }, EKSearch.EmbeddedKnowledgeSearchConstants.Colon);
                var urlFormatLabelContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabelContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabelContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.headingLabel
                }, [urlFormatLabel, urlFormatColonLabel]);
                // Creating url input box
                var urlInputBox = this._context.factory.createElement("TEXTINPUT", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.UrlInputBoxId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.UrlInputBoxId,
                    disabled: !this._EKSearchModel.UseExternalPortal,
                    value: this._EKSearchModel.NativeCrmUrl,
                    tabIndex: 1,
                    onChangeText: this.UrlInputboxChanged.bind(this),
                    placeholder: EKSearch.EmbeddedKnowledgeSearchConstants.UrlPlaceholder,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.urlInputBox,
                    accessibilityLabel: this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.UrlFormatLabel)
                });
                var urlContainer = this._context.factory.createElement("CONTAINER", {
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.urlContainer
                }, [urlFormatLabelContainer, urlInputBox]);
                // Creating main container and adding all elements into it
                var mainContainer = this._context.factory.createElement("CONTAINER", {
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.MainContainerId,
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.MainContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.mainContainer
                }, [recordTypeContainer, dualListContainer, supportPortalConnectionContainer, checkboxContainer, urlContainer]);
                return mainContainer;
            };
            EKSearchControl.prototype.CheckBoxChanged = function (value) {
                this._EKSearchModel.UseExternalPortal = value;
                this._context.utils.requestRender();
            };
            EKSearchControl.prototype.UrlInputboxChanged = function (value) {
                this._EKSearchModel.NativeCrmUrl = value;
            };
            EKSearchControl.prototype.CreateHeaderRightContainer = function () {
                var saveIconContainer = this._context.factory.createElement("CONTAINER", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SaveIconContainerKey,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SaveIconContainerKey,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.freRightButtonIconContainer
                }, []);
                var saveButton = this._context.factory.createElement("BUTTON", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.SaveButtonId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.SaveButtonId,
                    onClick: this.OnSaveButtonClicked.bind(this),
                    tabIndex: 1,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyle
                }, [saveIconContainer, this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SaveLabel)]);
                var headerSeparatorContainer = this._context.factory.createElement("CONTAINER", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.HeaderSeparatorContainerKey,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.HeaderSeparatorContainerKey,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.freHeaderSeparatorContainer
                }, []);
                var headerRightContainer = this._context.factory.createElement("CONTAINER", {
                    key: EKSearch.EmbeddedKnowledgeSearchConstants.HeaderRightContainerId,
                    id: EKSearch.EmbeddedKnowledgeSearchConstants.HeaderRightContainerId,
                    style: EKSearch.EmbeddedKnowledgeSearchStyles.freHeaderRightContainer
                }, [headerSeparatorContainer, saveButton]);
                return headerRightContainer;
            };
            EKSearchControl.prototype.OnSaveButtonClicked = function () {
                this._EKSearchModel.onSaveClick();
            };
            EKSearchControl.prototype.DualListSelectionCallback = function (selectedValues) {
                this._EKSearchModel.SelectedEntities = selectedValues;
                this.notifyOutputChangeAndRequestRerender();
            };
            EKSearchControl.prototype.notifyOutputChangeAndRequestRerender = function () {
                this._notifyOutputChanged();
                this._context.utils.requestRender();
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            EKSearchControl.prototype.getOutputs = function () {
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            EKSearchControl.prototype.destroy = function () {
            };
            return EKSearchControl;
        }());
        EKSearch.EKSearchControl = EKSearchControl;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
 * IMPORTANT!
 * DO NOT MAKE CHANGES TO THIS FILE - THIS FILE IS AUTO-GENERATED FROM ODATA CSDL METADATA DOCUMENT
 * SEE https://msdn.microsoft.com/en-us/library/mt607990.aspx FOR MORE INFORMATION
 */
var ODataContract;
(function (ODataContract) {
    /* tslint:disable:crm-force-fields-private */
    var RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest = (function () {
        function RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest() {
        }
        RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest.prototype.getMetadata = function () {
            var metadata = {
                boundParameter: null,
                parameterTypes: {},
                operationName: "RetrieveEmbeddedKMSearchCanBeEnabledEntities",
                operationType: 1,
            };
            return metadata;
        };
        return RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest;
    }());
    ODataContract.RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest = RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest;
})(ODataContract || (ODataContract = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../../TypeDefinitions/AppCommon/Controls/FREShell/libs/FREShell.d.ts" />
/// <reference path="../../../../../references/internal/TypeDefinitions/CommonControl/CommonControl.d.ts" />
/// <reference path="../../ServiceClientCommon/DataContracts/Function/RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest.ts" />
/// <reference path="PrivateReferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        var EmbeddedKnowledgeSearchModel = (function () {
            function EmbeddedKnowledgeSearchModel(context) {
                this._allEntities = [];
                this._selectedEntities = "";
                this._initiallySelectedEntities = "";
                this._useExternalPortal = false;
                this._nativeCrmUrl = "";
                this._context = context;
                this.initialize();
            }
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "AllEntities", {
                get: function () {
                    return this._allEntities;
                },
                set: function (value) {
                    this._allEntities = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "SelectedEntities", {
                get: function () {
                    return this._selectedEntities;
                },
                set: function (value) {
                    this._selectedEntities = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "UseExternalPortal", {
                get: function () {
                    return this._useExternalPortal;
                },
                set: function (value) {
                    this._useExternalPortal = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(EmbeddedKnowledgeSearchModel.prototype, "NativeCrmUrl", {
                get: function () {
                    return this._nativeCrmUrl;
                },
                set: function (value) {
                    this._nativeCrmUrl = value;
                },
                enumerable: true,
                configurable: true
            });
            EmbeddedKnowledgeSearchModel.prototype.initialize = function () {
                var _this = this;
                var request = new ODataContract.RetrieveEmbeddedKMSearchCanBeEnabledEntitiesRequest();
                Xrm.WebApi.online.execute(request).then(function (response) {
                    if (!_this._context.utils.isNullOrUndefined(response)) {
                        response.json().then(function (jsonResponse) {
                            if (!_this._context.utils.isNullOrUndefined(jsonResponse.Result)) {
                                _this.createEntitiesFromJsonResponse(JSON.parse(jsonResponse.Result));
                                _this._context.utils.requestRender();
                            }
                        });
                    }
                }, function (error) {
                    //TODO Log telemetry (Task Id 1131504)
                });
                // Retrieve KM settings from organization table
                this._context.webAPI.retrieveMultipleRecords(EKSearch.EmbeddedKnowledgeSearchConstants.Organization, EKSearch.EmbeddedKnowledgeSearchConstants.KMSettingsFilter).then(function (response) {
                    _this._organizationId = (response.entities)[0].organizationid;
                    _this.intializeKMSettings((response.entities)[0].kmsettings);
                    _this._context.utils.requestRender();
                }, function (error) {
                    //TODO Log telemetry (Task Id 1131504)
                });
            };
            EmbeddedKnowledgeSearchModel.prototype.intializeKMSettings = function (kmsettingsxml) {
                if (!this._context.utils.isNullOrUndefined(kmsettingsxml)) {
                    var kmsettings = void 0;
                    if (window.DOMParser) {
                        var parser = new DOMParser();
                        kmsettings = parser.parseFromString(kmsettingsxml, "application/xml");
                    }
                    else {
                        kmsettings = new ActiveXObject("Microsoft.XMLDOM");
                        kmsettings.async = false;
                        kmsettings.loadXML(kmsettingsxml);
                    }
                    if (kmsettings.getElementsByTagName("UseExternalPortal")[0] && kmsettings.getElementsByTagName("UseExternalPortal")[0].childNodes[0]) {
                        this._useExternalPortal = kmsettings.getElementsByTagName("UseExternalPortal")[0].childNodes[0].nodeValue == 'true' ? true : false;
                    }
                    if (kmsettings.getElementsByTagName("NativeCrmUrl")[0] && kmsettings.getElementsByTagName("NativeCrmUrl")[0].childNodes[0]) {
                        this._nativeCrmUrl = kmsettings.getElementsByTagName("NativeCrmUrl")[0].childNodes[0].nodeValue;
                    }
                }
            };
            // Returns the entities which are newly added
            EmbeddedKnowledgeSearchModel.prototype.getAddedEntities = function () {
                var _this = this;
                return this._selectedEntities.split(',').filter(function (i) { return _this._initiallySelectedEntities.indexOf(i) < 0; });
            };
            // Returns the entities which are newly removed
            EmbeddedKnowledgeSearchModel.prototype.getDeletedEntities = function () {
                var _this = this;
                return this._initiallySelectedEntities.split(',').filter(function (i) { return _this._selectedEntities.indexOf(i) < 0; });
            };
            EmbeddedKnowledgeSearchModel.prototype.onSaveClick = function () {
                var _this = this;
                if (this._useExternalPortal && !this.validateUrl()) {
                    var alertMessage = { text: this._invalidUrlErrorMessage };
                    this._context.navigation.openAlertDialog(alertMessage);
                    return;
                }
                this.saveEntities().then(function (response) {
                    // Update Initially selected values after saving
                    _this._initiallySelectedEntities = _this._selectedEntities;
                    _this.saveUrl().then(function (response) {
                        _this._context.utils.addGlobalNotification(1 /* toast */, 1 /* success */, _this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SaveSuccessMessage), null, null);
                    }, function (error) {
                        var alertMessage = { text: _this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SaveFailureMessage) };
                        _this._context.navigation.openAlertDialog(alertMessage);
                        // TODO: Log telemetry (Task Id 1131504)
                    });
                }, function (error) {
                    var alertMessage = { text: _this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.SaveFailureMessage) };
                    _this._context.navigation.openAlertDialog(alertMessage);
                    // TODO: Log telemetry (Task Id 1131504)
                });
            };
            EmbeddedKnowledgeSearchModel.prototype.validateUrl = function () {
                if (this._nativeCrmUrl === "") {
                    this._invalidUrlErrorMessage = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.EmptyUrlMessage);
                    return false;
                }
                // Check for Scheme name
                var urlObj = this.extractUrlComponents();
                if (urlObj.Scheme !== "http" && urlObj.Scheme !== "https") {
                    this._invalidUrlErrorMessage = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.InvalidCrmUrl);
                    return false;
                }
                // Check for "{kbnum}"
                if (this._nativeCrmUrl.indexOf("{kbnum}") === -1) {
                    this._invalidUrlErrorMessage = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.InvalidUrlNoKbNumber);
                    return false;
                }
                // Check for Host name
                if (urlObj.Host.indexOf(".") < 1 || urlObj.Host.length <= urlObj.Host.lastIndexOf(".") + 2) {
                    this._invalidUrlErrorMessage = this._context.resources.getString(EKSearch.EmbeddedKnowledgeSearchConstants.InvalidUrlFormat);
                    return false;
                }
                return true;
            };
            EmbeddedKnowledgeSearchModel.prototype.extractUrlComponents = function () {
                var urlObj = new UrlObject();
                // Extract Scheme name
                var queryStringStartIndex = -1;
                queryStringStartIndex = this._nativeCrmUrl.indexOf("?");
                var colonIndex = this._nativeCrmUrl.indexOf(":");
                if (colonIndex > queryStringStartIndex && queryStringStartIndex !== -1)
                    colonIndex = -1;
                if (colonIndex === -1) {
                    return urlObj;
                }
                var endOfScheme = colonIndex + 1;
                while (this._nativeCrmUrl.charAt(endOfScheme) === "/")
                    endOfScheme++;
                var schemeDelimiter = this._nativeCrmUrl.substr(colonIndex, endOfScheme - colonIndex);
                if (schemeDelimiter !== "://") {
                    return urlObj;
                }
                urlObj.Scheme = this._nativeCrmUrl.substr(0, colonIndex).toLowerCase();
                // Extract Host name
                var slashIndex = -1;
                var portIndex = -1;
                for (var i = endOfScheme; i < this._nativeCrmUrl.length && slashIndex === -1; i++) {
                    switch (this._nativeCrmUrl.charAt(i)) {
                        case "/":
                            slashIndex = i;
                            break;
                        case ":":
                            portIndex = i;
                            break;
                    }
                }
                if (slashIndex === -1)
                    slashIndex = this._nativeCrmUrl.length;
                if (portIndex === -1)
                    portIndex = slashIndex;
                urlObj.Host = this._nativeCrmUrl.substr(endOfScheme, portIndex - endOfScheme);
                return urlObj;
            };
            EmbeddedKnowledgeSearchModel.prototype.saveEntities = function () {
                var addedEntities = this.getAddedEntities();
                var deletedEntities = this.getDeletedEntities();
                // Creating a batch request to update added/removed entities 
                var batchUniqueNo = Math.floor(Math.random() * 1000);
                var changeSetUniqueNo = Math.floor(Math.random() * 1000);
                var counter = 1;
                var batchUrl = this._context.utils.createCrmUri(EKSearch.EmbeddedKnowledgeSearchConstants.BatchUrl);
                var header = {
                    'Content-Type': 'multipart/mixed;boundary=batch_' + batchUniqueNo,
                    'Accept': 'application/json'
                };
                var payload = [];
                payload.push('--batch_' + batchUniqueNo);
                payload.push('Content-Type: multipart/mixed;boundary=changeset_' + changeSetUniqueNo);
                payload.push('');
                var _loop_1 = function (i) {
                    var entityId = $.grep(this_1._allEntities, function (item) { return item.LogicalName === addedEntities[i]; })[0].Id;
                    this_1.addChangesetSection(entityId, changeSetUniqueNo, counter++, payload, '{"IsKnowledgeManagementEnabled": true}');
                };
                var this_1 = this;
                for (var i = 0; i < addedEntities.length; i++) {
                    _loop_1(i);
                }
                var _loop_2 = function (i) {
                    var entityId = $.grep(this_2._allEntities, function (item) { return item.LogicalName === deletedEntities[i]; })[0].Id;
                    this_2.addChangesetSection(entityId, changeSetUniqueNo, counter++, payload, '{"IsKnowledgeManagementEnabled": false}');
                };
                var this_2 = this;
                for (var i = 0; i < deletedEntities.length; i++) {
                    _loop_2(i);
                }
                payload.push('--changeset_' + changeSetUniqueNo + '--');
                payload.push('--batch_' + batchUniqueNo + '--');
                var finalPayload = payload.join('\r\n');
                return this.ajaxCall(batchUrl, 'POST', finalPayload, header);
            };
            EmbeddedKnowledgeSearchModel.prototype.saveUrl = function () {
                var kmSettings = this.getKmSettingsData();
                return this._context.webAPI.updateRecord(EKSearch.EmbeddedKnowledgeSearchConstants.Organization, this._organizationId, { "kmsettings": kmSettings });
            };
            EmbeddedKnowledgeSearchModel.prototype.getKmSettingsData = function () {
                var kmSettings = "";
                var url = "";
                if (this._useExternalPortal) {
                    url = Xrm.Encoding.xmlEncode(this._nativeCrmUrl);
                }
                kmSettings = MscrmCommon.ControlUtils.String.Format(EKSearch.EmbeddedKnowledgeSearchConstants.KMSettingsXml, this._useExternalPortal, url);
                return kmSettings;
            };
            // Method adds changeset corresponding to each entity in the the payload
            EmbeddedKnowledgeSearchModel.prototype.addChangesetSection = function (entityId, changeSetUniqueNo, counter, payload, data) {
                var url = this._context.utils.createCrmUri(EKSearch.EmbeddedKnowledgeSearchConstants.UpdateEntityUrl + '(' + entityId + ')');
                payload.push('--changeset_' + changeSetUniqueNo);
                payload.push('Content-Type:application/http');
                payload.push('Content-Transfer-Encoding:binary');
                payload.push('Content-ID:' + counter);
                payload.push('');
                payload.push('PUT ' + url + ' HTTP/1.1');
                payload.push('Content-Type:application/json;type=entry');
                payload.push('');
                payload.push(data);
            };
            EmbeddedKnowledgeSearchModel.prototype.ajaxCall = function (url, type, payload, header) {
                return $.ajax({
                    url: url,
                    type: type,
                    async: true,
                    data: payload,
                    headers: header,
                });
            };
            // Method extracts required information from the json data and creates entities out of it
            EmbeddedKnowledgeSearchModel.prototype.createEntitiesFromJsonResponse = function (data) {
                for (var i = 0; i < data.length; i++) {
                    if (this._context.utils.isNullOrUndefined(data[i].UserLocalizedLabel))
                        continue;
                    var entity = new Entity;
                    entity.Id = data[i].MetadataId;
                    entity.LogicalName = data[i].LogicalName;
                    entity.DisplayName = data[i].UserLocalizedLabel;
                    entity.IsKnowledgeManagementEnabled = data[i].IsKnowledgeManagementEnabled;
                    this._allEntities.push(entity);
                    if (entity.IsKnowledgeManagementEnabled) {
                        this._initiallySelectedEntities = this._initiallySelectedEntities + ',' + entity.LogicalName;
                    }
                }
                this._allEntities = this._allEntities.sort(function (a, b) { return a.DisplayName.localeCompare(b.DisplayName); });
                this._selectedEntities = this._initiallySelectedEntities;
            };
            return EmbeddedKnowledgeSearchModel;
        }());
        EKSearch.EmbeddedKnowledgeSearchModel = EmbeddedKnowledgeSearchModel;
        var Entity = (function () {
            function Entity() {
            }
            return Entity;
        }());
        EKSearch.Entity = Entity;
        var UrlObject = (function () {
            function UrlObject() {
            }
            return UrlObject;
        }());
        EKSearch.UrlObject = UrlObject;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var EKSearch;
    (function (EKSearch) {
        'use strict';
        var EmbeddedKnowledgeSearchStyles = (function (_super) {
            __extends(EmbeddedKnowledgeSearchStyles, _super);
            function EmbeddedKnowledgeSearchStyles() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            EmbeddedKnowledgeSearchStyles.initialize = function (theming, isRTL) {
                EmbeddedKnowledgeSearchStyles.freRightButtonIconContainer = {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    backgroundColor: "transparent",
                    margin: theming.measures.measure025
                };
                EmbeddedKnowledgeSearchStyles.freHeaderSeparatorContainer = {
                    borderRight: theming.borders.border02,
                    width: "1px",
                    height: "2.1rem",
                    alignSelf: "center"
                };
                EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyleHover = {
                    fontFamily: theming.fontfamilies.semibold
                };
                EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyleFocus = {
                    fontFamily: theming.fontfamilies.semibold,
                    border: "1px solid #666666",
                    outline: "none"
                };
                EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyle = {
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    alignSelf: "center",
                    border: "none",
                    backgroundColor: "transparent",
                    cursor: "pointer",
                    padding: "2px",
                    marginLeft: theming.measures.measure075,
                    marginRight: theming.measures.measure075,
                    fontFamily: theming.fontfamilies.regular,
                    fontSize: theming.fontsizes.font100,
                    color: "#0063B1",
                    lineHeight: "1.4rem",
                    whiteSpace: "nowrap",
                    hover: this.freHeaderRightButtonStyleHover,
                    focus: this.freHeaderRightButtonStyleFocus,
                };
                EmbeddedKnowledgeSearchStyles.freHeaderRightContainer = {
                    display: "flex",
                    alignItems: "center",
                    margin: theming.measures.measure075
                };
                EmbeddedKnowledgeSearchStyles.checkboxContainer = {
                    display: "flex",
                    marginTop: theming.measures.measure150,
                    width: "45%",
                    marginLeft: theming.measures.measure100,
                };
                EmbeddedKnowledgeSearchStyles.checkbox = {
                    width: "auto",
                    margin: "auto",
                    display: "inline-block"
                };
                EmbeddedKnowledgeSearchStyles.recordTypeContainer = {
                    marginTop: theming.measures.measure150,
                    marginLeft: theming.measures.measure100,
                    display: "block"
                };
                EmbeddedKnowledgeSearchStyles.dualListContainer = {
                    marginTop: theming.measures.measure150
                };
                EmbeddedKnowledgeSearchStyles.supportPortalConnectionContainer = {
                    width: "45%",
                    marginTop: theming.measures.measure150,
                    marginLeft: theming.measures.measure100,
                    display: "block"
                };
                EmbeddedKnowledgeSearchStyles.urlContainer = {
                    marginTop: theming.measures.measure150,
                    marginLeft: theming.measures.measure100,
                    width: "45%"
                };
                EmbeddedKnowledgeSearchStyles.headingLabel = {
                    fontFamily: theming.fontfamilies.semibold,
                    color: theming.colors.basecolor.black,
                    width: "20%"
                };
                EmbeddedKnowledgeSearchStyles.urlInputBox = {
                    width: "80%"
                };
                EmbeddedKnowledgeSearchStyles.checkboxDescription = {
                    marginTop: theming.measures.measure100
                };
                EmbeddedKnowledgeSearchStyles.checkboxLabel = {
                    marginRight: theming.measures.measure100,
                    marginLeft: theming.measures.measure100
                };
                EmbeddedKnowledgeSearchStyles.checkbox_Label_Description_Container = {
                    width: "80%",
                    display: "block"
                };
                EmbeddedKnowledgeSearchStyles.mainContainer = {
                    fontFamily: theming.fontfamilies.regular,
                    color: theming.colors.grays.gray07,
                    display: "block",
                    textAlign: "justify",
                    width: "100%",
                    overflow: "auto"
                };
            };
            return EmbeddedKnowledgeSearchStyles;
        }(MscrmControls.AppCommon.AdvancedSettingCommonStyle));
        EmbeddedKnowledgeSearchStyles.freRightButtonIconContainer = {};
        EmbeddedKnowledgeSearchStyles.freHeaderSeparatorContainer = {};
        EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyle = {};
        EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyleHover = {};
        EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyleFocus = {};
        EmbeddedKnowledgeSearchStyles.freHeaderRightButtonStyleDisabled = {};
        EmbeddedKnowledgeSearchStyles.freHeaderRightContainer = {};
        EmbeddedKnowledgeSearchStyles.checkboxContainer = {};
        EmbeddedKnowledgeSearchStyles.checkbox = {};
        EmbeddedKnowledgeSearchStyles.recordTypeContainer = {};
        EmbeddedKnowledgeSearchStyles.dualListContainer = {};
        EmbeddedKnowledgeSearchStyles.supportPortalConnectionContainer = {};
        EmbeddedKnowledgeSearchStyles.urlContainer = {};
        EmbeddedKnowledgeSearchStyles.headingLabel = {};
        EmbeddedKnowledgeSearchStyles.urlInputBox = {};
        EmbeddedKnowledgeSearchStyles.checkboxDescription = {};
        EmbeddedKnowledgeSearchStyles.checkboxLabel = {};
        EmbeddedKnowledgeSearchStyles.checkbox_Label_Description_Container = {};
        EmbeddedKnowledgeSearchStyles.mainContainer = {};
        EKSearch.EmbeddedKnowledgeSearchStyles = EmbeddedKnowledgeSearchStyles;
    })(EKSearch = MscrmControls.EKSearch || (MscrmControls.EKSearch = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=EmbeddedKnowledgeSearchControl.js.map