/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var AzureAPIStatus;
(function (AzureAPIStatus) {
    AzureAPIStatus[AzureAPIStatus["NotInitiated"] = 0] = "NotInitiated";
    AzureAPIStatus[AzureAPIStatus["Initiated"] = 1] = "Initiated";
    AzureAPIStatus[AzureAPIStatus["Success"] = 2] = "Success";
    AzureAPIStatus[AzureAPIStatus["Failed"] = 3] = "Failed";
})(AzureAPIStatus || (AzureAPIStatus = {}));
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        'use strict';
        var SimilarCasesGridControl = (function () {
            function SimilarCasesGridControl() {
                this._APIResponse = null;
                this._context = null;
                this._dataProvider = null;
                this._dataSetRecord = null;
                this._isDataFetched = AzureAPIStatus.NotInitiated;
                this._applyStyles = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            SimilarCasesGridControl.prototype.init = function (context, notifyOutputChanged, state) {
                var _this = this;
                this._context = context;
                this._applyStyles = new Containers.SimilarCaseGridControlStyles(context);
                this._isDataFetched = AzureAPIStatus.Initiated;
                this.retrieveSimilarRecords().then(function (successResponse) {
                    _this._APIResponse = successResponse;
                    _this._isDataFetched = AzureAPIStatus.Success;
                    _this.parseSuccessResponse(successResponse).then(function (dataSetRecords) {
                        _this._dataSetRecord = dataSetRecords;
                        _this._context.utils.requestRender();
                    });
                }, function (errorResponse) {
                    _this._APIResponse = errorResponse;
                    _this._isDataFetched = AzureAPIStatus.Failed;
                    _this._context.utils.requestRender();
                });
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            SimilarCasesGridControl.prototype.updateView = function (context) {
                var titleLabel = this.createTitleLabel();
                if (this._isDataFetched.valueOf() === AzureAPIStatus.Success) {
                    this._dataProvider = new Containers.SimilarRecordsDataProvider(this._dataSetRecord);
                    this._dataProvider.setIncidentGridColumns(this.retrieveColumns());
                    var gridControl = this.createGridControl(this._context);
                    return this._context.factory.createElement("CONTAINER", {
                        key: Containers.DOMId.GridContainerId,
                        id: Containers.DOMId.GridContainerId,
                        style: this._applyStyles.Container(),
                    }, [titleLabel, gridControl]);
                }
                else if (this._isDataFetched.valueOf() === AzureAPIStatus.Failed) {
                    var errorResponse = this._APIResponse;
                    var errorMessageLabel = this.createErrorMessageLabel(errorResponse.message);
                    return this._context.factory.createElement("CONTAINER", {
                        key: Containers.DOMId.ErrorContainerId,
                        id: Containers.DOMId.ErrorContainerId,
                        style: this._applyStyles.Container(),
                    }, [titleLabel, errorMessageLabel]);
                }
                else {
                    return this._context.factory.createElement("CONTAINER", {
                        key: Containers.DOMId.EmptyConatinerId,
                        id: Containers.DOMId.EmptyConatinerId,
                        style: this._applyStyles.Container(),
                    }, [titleLabel]);
                }
            };
            /**
             * Creates the Title label
             * @param context
             */
            SimilarCasesGridControl.prototype.createTitleLabel = function () {
                var titleLabel = this._context.factory.createElement("LABEL", {
                    key: Containers.DOMId.SimilarCaseLabelId,
                    id: Containers.DOMId.SimilarCaseLabelId,
                    style: this._applyStyles.TitleLabel()
                }, this._context.resources.getString(Containers.ResourceKeys.SimilarCases));
                return titleLabel;
            };
            /**
             * Creates the Error Message label
             * @param context
             */
            SimilarCasesGridControl.prototype.createErrorMessageLabel = function (errorMessage) {
                var errorMessageLabel = this._context.factory.createElement("LABEL", {
                    key: Containers.DOMId.ErrorMessageLabelId,
                    id: Containers.DOMId.ErrorMessageLabelId,
                    style: this._applyStyles.ErrorMessageLabel()
                }, errorMessage);
                return errorMessageLabel;
            };
            /**
             * Create SimilarCaseGridControl with custom data provider.
             * @param context
             */
            SimilarCasesGridControl.prototype.createGridControl = function (context) {
                var properties = {
                    //Not Required to override contextOverride parameter, if the Bug 1003543 is fixed.
                    "contextOverrides": {
                        openForm: this._context.navigation.openForm.bind(this._context.navigation),
                    },
                    "parameters": {
                        Grid: {
                            Primary: true,
                            TargetEntityType: Containers.Entity.Incident,
                            DataProvider: this._dataProvider,
                            Type: "Grid",
                        },
                        EnableGroupBy: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        EnableFiltering: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        },
                        EnableEditing: {
                            Usage: 1,
                            Static: true,
                            Type: "Enum",
                            Value: "No",
                            Primary: false
                        }
                    }
                };
                return context.factory.createComponent("MscrmControls.Grid.GridControl", Containers.DOMId.GridId, properties);
            };
            /**
             * Retreives the set of columns to be rendered in the grid control.
             */
            SimilarCasesGridControl.prototype.retrieveColumns = function () {
                var caseTitle = {
                    name: Containers.Columns.Title,
                    displayName: this._context.resources.getString(Containers.ResourceKeys.Title),
                    dataType: "SingleLine.Text",
                    alias: Containers.Columns.Title,
                    visualSizeFactor: 250,
                    isHidden: false,
                    isPrimary: true,
                    order: 1,
                    attributes: {
                        format: "Text",
                        type: "string"
                    },
                    validator: null,
                    disableSorting: false
                };
                var modifiedOn = {
                    name: Containers.Columns.ModifiedOn,
                    displayName: this._context.resources.getString(Containers.ResourceKeys.ModifiedOn),
                    dataType: "DateAndTime.DateAndTime",
                    alias: Containers.Columns.ModifiedOn,
                    visualSizeFactor: 170,
                    isHidden: false,
                    order: 2,
                    attributes: {
                        format: "datetime",
                        type: "datetime"
                    },
                    validator: null,
                    disableSorting: true
                };
                return [caseTitle, modifiedOn];
            };
            /**
             * This method parse the success response of GetSimilarRecord API and
             * returns the collection of DataSetRecord to be shown in the grid.
             * @param response
             */
            SimilarCasesGridControl.prototype.parseSuccessResponse = function (successResponse) {
                var dataSetRecords = [];
                return successResponse.json().then(function (response) {
                    var entityRecords = response.value;
                    for (var recordIdx = 0; recordIdx < entityRecords.length; ++recordIdx) {
                        var entityRecord = entityRecords[recordIdx];
                        var fields = {};
                        fields[Containers.Columns.Title] = entityRecord[Containers.Columns.Title];
                        fields[Containers.Columns.ModifiedOn] = entityRecord[Containers.Columns.FormattedModifiedOn];
                        var id = entityRecord.incidentid;
                        var dataSetRecord = new Containers.SimilarCaseDataSetRecord(id, fields, Containers.Entity.Incident);
                        dataSetRecords.push(dataSetRecord);
                    }
                    return dataSetRecords;
                }, function (error) {
                    //TODO:Need to add telemrtry.
                    console.error("error while parsing the records returned from AzureAPI");
                    return dataSetRecords;
                });
            };
            /**
             * This method calls the GetSimilarRecord API for the current incident entity.
             */
            SimilarCasesGridControl.prototype.retrieveSimilarRecords = function () {
                var entity = {
                    id: this._context.page.entityId,
                    entityType: this._context.page.entityTypeName,
                };
                var columns = [Containers.Columns.Title, Containers.Columns.ModifiedOn];
                var columnSet = new Containers.ColumnSet(false, columns);
                var getSimilarRecordRequest = new Containers.GetSimilarRecordsRequest(entity, null, columnSet);
                return this._context.webAPI.execute(getSimilarRecordRequest);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            SimilarCasesGridControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            SimilarCasesGridControl.prototype.destroy = function () {
            };
            return SimilarCasesGridControl;
        }());
        Containers.SimilarCasesGridControl = SimilarCasesGridControl;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" /> 
/// <reference path="../privatereferences.ts"/>
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        'use strict';
        var GetSimilarRecordsRequest = (function () {
            /// <summary>
            /// Initializes a new instance of the GetSimilarRecordsRequest class.
            /// </summary>
            /// <param name="id">The Id for the request i.e. (the id:"the id of record" and the entityType:"the name of the entity")</param>
            function GetSimilarRecordsRequest(Id, filter, columnsSet) {
                this.Id = Id;
                this.Filter = filter;
                this.ReturnFields = columnsSet;
            }
            GetSimilarRecordsRequest.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    parameterTypes: {
                        "Id": {
                            "typeName": "Microsoft.Dynamics.CRM.crmbaseentity",
                            "structuralProperty": 5,
                        },
                        "Filter": {
                            "typeName": "Edm.String",
                            "structuralProperty": 1,
                        },
                        "ReturnFields": {
                            "typeName": "Microsoft.Dynamics.CRM.ColumnSet",
                            "structuralProperty": 2,
                        },
                    },
                    operationName: "GetSimilarRecords",
                    operationType: 1,
                };
                return metadata;
            };
            return GetSimilarRecordsRequest;
        }());
        Containers.GetSimilarRecordsRequest = GetSimilarRecordsRequest;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="SimilarCasesGridControl.ts" />
/// <reference path="OdataContract/GetSimilarRecordsRequest.ts" />
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var Columns;
        (function (Columns) {
            Columns.ModifiedOn = "modifiedon";
            Columns.Title = "title";
            Columns.FormattedModifiedOn = "modifiedon@OData.Community.Display.V1.FormattedValue";
        })(Columns = Containers.Columns || (Containers.Columns = {}));
        var Entity;
        (function (Entity) {
            Entity.Incident = "incident";
            Entity.SimilarCasesViewId = "BD15C679-DF0B-E611-80D2-00155DB1076F";
        })(Entity = Containers.Entity || (Containers.Entity = {}));
        var DOMId;
        (function (DOMId) {
            DOMId.SimilarCaseLabelId = "SimilarCasesLabelId";
            DOMId.ErrorMessageLabelId = "ErrorMessageLabelId";
            DOMId.GridId = "SimilarCasesGridControlId";
            DOMId.GridContainerId = "SimilarCasesGridContainerId";
            DOMId.ErrorContainerId = "ErrorContainerId";
            DOMId.EmptyConatinerId = "EmptyContainerId";
        })(DOMId = Containers.DOMId || (Containers.DOMId = {}));
        var ResourceKeys;
        (function (ResourceKeys) {
            ResourceKeys.ModifiedOn = "SCG_ModifiedOn_Column";
            ResourceKeys.Title = "SCG_Title_Column";
            ResourceKeys.SimilarCases = "SCG_SimilarCases_Label";
            ResourceKeys.Error = "SCG_Error_Label";
        })(ResourceKeys = Containers.ResourceKeys || (Containers.ResourceKeys = {}));
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        'use strict';
        var ColumnSet = (function () {
            function ColumnSet(allColumns, columns) {
                this.AllColumns = allColumns;
                this.Columns = columns;
            }
            ColumnSet.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    parameterTypes: {
                        "AllColumns": {
                            "typeName": "Edm.Boolean",
                            "structuralProperty": 1,
                        },
                        "Columns": {
                            "typeName": "Edm.String",
                            "structuralProperty": 4,
                        },
                    },
                    operationName: null,
                    operationType: null,
                };
                return metadata;
            };
            return ColumnSet;
        }());
        Containers.ColumnSet = ColumnSet;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var SimilarCaseGridControlStyles = (function () {
            function SimilarCaseGridControlStyles(context) {
                this._TitleLabel = {};
                this._ErrorMessageLabel = {};
                this._Container = {};
                this._context = context;
            }
            SimilarCaseGridControlStyles.prototype.Container = function () {
                this._Container = {};
                this._Container["display"] = "flex";
                this._Container["flexDirection"] = "column";
                this._Container["width"] = "100%";
                return this._Container;
            };
            SimilarCaseGridControlStyles.prototype.TitleLabel = function () {
                this._TitleLabel = {};
                this._TitleLabel["fontFamily"] = this._context.theming.fontfamilies.semibold;
                this._TitleLabel["fontSize"] = this._context.theming.fontsizes.font100;
                this._TitleLabel["marginTop"] = this._context.theming.measures.measure125;
                this._TitleLabel["marginBottom"] = this._context.theming.measures.measure125;
                this._TitleLabel["lineHeight"] = "1.4rem";
                this._TitleLabel["color"] = this._context.theming.colors.basecolor.grey.grey7;
                return this._TitleLabel;
            };
            SimilarCaseGridControlStyles.prototype.ErrorMessageLabel = function () {
                this._ErrorMessageLabel = {};
                this._ErrorMessageLabel["fontFamily"] = this._context.theming.fontfamilies.regular;
                this._ErrorMessageLabel["fontSize"] = this._context.theming.fontsizes.font100;
                this._ErrorMessageLabel["lineHeight"] = "1.4rem";
                this._ErrorMessageLabel["color"] = this._context.theming.colors.basecolor.grey.grey4;
                return this._ErrorMessageLabel;
            };
            return SimilarCaseGridControlStyles;
        }());
        Containers.SimilarCaseGridControlStyles = SimilarCaseGridControlStyles;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
/**
 * @license Copyright (c) Microsoft Corporation.  All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var SimilarCaseDataSetRecord = (function () {
            function SimilarCaseDataSetRecord(id, record, logicalName) {
                this._record = {};
                this._id = id;
                this._record = record;
                this._logicalName = logicalName;
            }
            SimilarCaseDataSetRecord.prototype.getRecordId = function () {
                return this._id;
            };
            SimilarCaseDataSetRecord.prototype.getValue = function (columnName) {
                return this._record[columnName];
            };
            SimilarCaseDataSetRecord.prototype.setValue = function (columnName, newValue) {
                throw new Error("Not implemented");
            };
            SimilarCaseDataSetRecord.prototype.save = function () {
                throw new Error("Not implemented");
            };
            SimilarCaseDataSetRecord.prototype.getFormattedValue = function (columnName) {
                return this._record[columnName];
            };
            SimilarCaseDataSetRecord.prototype.isEditable = function (columnName) {
                return window.Promise.resolve(false);
            };
            SimilarCaseDataSetRecord.prototype.isSecured = function (columnName) {
                return window.Promise.resolve(false);
            };
            SimilarCaseDataSetRecord.prototype.isReadable = function (columnName) {
                return window.Promise.resolve(true);
            };
            SimilarCaseDataSetRecord.prototype.getFieldRequiredLevel = function (columnName) {
                return window.Promise.resolve(-1 /* Unknown */);
            };
            SimilarCaseDataSetRecord.prototype.getAttributes = function (column) {
                return null;
            };
            SimilarCaseDataSetRecord.prototype.getValidator = function (column) {
                return null;
            };
            SimilarCaseDataSetRecord.prototype.getNamedReference = function () {
                var _this = this;
                return {
                    Id: {
                        guid: this._id,
                        toString: function () { return _this._id; }
                    },
                    Name: null,
                    LogicalName: this._logicalName
                };
            };
            SimilarCaseDataSetRecord.prototype.getActivityPartyRecord = function () {
                return null;
            };
            SimilarCaseDataSetRecord.prototype.getErrorMessage = function () {
                return null;
            };
            SimilarCaseDataSetRecord.prototype.isDirty = function () {
                return false;
            };
            SimilarCaseDataSetRecord.prototype.isRecordValid = function () {
                return true;
            };
            SimilarCaseDataSetRecord.prototype.getNotification = function (columnName) {
                return null;
            };
            SimilarCaseDataSetRecord.prototype.isValid = function (columnName) {
                return true;
            };
            SimilarCaseDataSetRecord.prototype.validateAllColumns = function () {
                return null;
            };
            return SimilarCaseDataSetRecord;
        }());
        Containers.SimilarCaseDataSetRecord = SimilarCaseDataSetRecord;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var Containers;
    (function (Containers) {
        var SimilarRecordsDataProvider = (function () {
            function SimilarRecordsDataProvider(records) {
                this._sorting = null;
                SimilarRecordsDataProvider._that = this;
                this._records = records;
            }
            SimilarRecordsDataProvider.prototype.refresh = function () {
                return window.Promise.resolve(this.getRecords());
            };
            SimilarRecordsDataProvider.prototype.isLoading = function () {
                return this._isLoading;
            };
            SimilarRecordsDataProvider.prototype.isError = function () {
                return false;
            };
            SimilarRecordsDataProvider.prototype.getErrorMessage = function () {
                return null;
            };
            SimilarRecordsDataProvider.prototype.setSorting = function (sorting) {
                this._sorting = sorting;
                this._records = this._records.sort(this.compareDataSetRecord);
            };
            SimilarRecordsDataProvider.prototype.compareDataSetRecord = function (a, b) {
                var that = SimilarRecordsDataProvider._that;
                if (that._sorting.length == 1) {
                    var columName = that._sorting[0].name;
                    var sortingDirection = that._sorting[0].sortDirection;
                    var firstValue = a.getValue(columName);
                    var secondValue = b.getValue(columName);
                    if (firstValue != undefined && secondValue != undefined)
                        return that.compare(firstValue, secondValue, sortingDirection);
                    else
                        return 0;
                }
                else {
                    return 0;
                }
            };
            SimilarRecordsDataProvider.prototype.compare = function (a, b, sortingDirection) {
                var ret;
                if (sortingDirection == 0 /* Ascending */)
                    a > b ? ret = 1 : ret = -1;
                else if (sortingDirection == 1 /* Descending */)
                    a < b ? ret = 1 : ret = -1;
                else
                    ret = 0;
                return ret;
            };
            SimilarRecordsDataProvider.prototype.setFiltering = function (filtering) {
                this._filtering = filtering;
            };
            SimilarRecordsDataProvider.prototype.getColumns = function () {
                return this._columns || [];
            };
            SimilarRecordsDataProvider.prototype.getRecords = function () {
                return this._records;
            };
            SimilarRecordsDataProvider.prototype.getPaging = function () {
                return undefined;
            };
            SimilarRecordsDataProvider.prototype.save = function (record) {
                throw new Error("Not implemented");
            };
            SimilarRecordsDataProvider.prototype.setIncidentGridColumns = function (columns) {
                this._columns = columns;
            };
            return SimilarRecordsDataProvider;
        }());
        Containers.SimilarRecordsDataProvider = SimilarRecordsDataProvider;
    })(Containers = MscrmControls.Containers || (MscrmControls.Containers = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=SimilarCasesGridControl.js.map