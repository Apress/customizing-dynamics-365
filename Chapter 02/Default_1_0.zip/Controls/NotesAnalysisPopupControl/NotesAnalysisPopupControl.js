/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupConstants = (function () {
            function NotesAnalysisPopupConstants() {
            }
            return NotesAnalysisPopupConstants;
        }());
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_DESCRIPTION = "NOTES_ANALYSIS_MEETING_REQUEST_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_DESCRIPTION = "NOTES_ANALYSIS_ISSUE_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_DESCRIPTION = "NOTES_ANALYSIS_SEND_CONTENT_REQUEST_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_DESCRIPTION = "NOTES_ANALYSIS_CALL_ACTIVITY_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_DESCRIPTION = "NOTES_ANALYSIS_MEETING_ACTIVITY_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_DESCRIPTION = "NOTES_ANALYSIS_NEWCONTACT_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_REQUEST_DESCRIPTION = "NOTES_ANALYSIS_ACTION_ITEM_REQUEST_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_DESCRIPTION = "NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_DESCRIPTION = "NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_DESCRIPTION";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_TITLE = "NOTES_ANALYSIS_MEETING_REQUEST_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_TITLE = "NOTES_ANALYSIS_ISSUE_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_TITLE = "NOTES_ANALYSIS_SEND_CONTENT_REQUEST_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_TITLE = "NOTES_ANALYSIS_CALL_ACTIVITY_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_TITLE = "NOTES_ANALYSIS_MEETING_ACTIVITY_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_TITLE = "NOTES_ANALYSIS_NEWCONTACT_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_REQUEST_TITLE = "NOTES_ANALYSIS_ACTION_ITEM_REQUEST_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_TITLE = "NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_TITLE = "NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_DEFAULT_TITLE = "NOTES_ANALYSIS_DEFAULT_TITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_SUBTITLE = "NOTES_ANALYSIS_MEETING_REQUEST_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_SUBTITLE = "NOTES_ANALYSIS_ISSUE_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_SUBTITLE = "NOTES_ANALYSIS_SEND_CONTENT_REQUEST_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_SUBTITLE = "NOTES_ANALYSIS_CALL_ACTIVITY_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_SUBTITLE = "NOTES_ANALYSIS_MEETING_ACTIVITY_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_SUBTITLE = "NOTES_ANALYSIS_NEWCONTACT_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_REQUEST_SUBTITLE = "NOTES_ANALYSIS_ACTION_ITEM_REQUEST_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_SUBTITLE = "NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_SUBTITLE = "NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_DEFAULT_SUBTITLE = "NOTES_ANALYSIS_DEFAULT_SUBTITLE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ON = "NOTES_ANALYSIS_ON";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_WITH = "NOTES_ANALYSIS_WITH";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_AT = "NOTES_ANALYSIS_AT";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_AND = "NOTES_ANALYSIS_AND";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_REGARDING = "NOTES_ANALYSIS_REGARDING";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_COMMA = "NOTES_ANALYSIS_COMMA";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE = "NOTES_ANALYSIS_SPACE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_QUESTION_MARK = "NOTES_ANALYSIS_QUESTION_MARK";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENITY_CREATION_SUCCESSFULL = "NOTES_ANALYSIS_ENITY_CREATION_SUCCESSFULL";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENTITY_CREATION_FAILURE = "NOTES_ANALYSIS_ENTITY_CREATION_FAILURE";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_VIEW_RECORD = "NOTES_ANALYSIS_VIEW_RECORD";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_UNABLE_TO_OPEN_FORM = "NOTES_ANALYSIS_UNABLE_TO_OPEN_FORM";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_DIALOG = "NOTES_ANALYSIS_CLOSE_DIALOG";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT = "Next Insight";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT = "Previous Insight";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP = "CLOSE_POPUP";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK = "ON_NEXT_INSIGHT_CLICK";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN = "ON_NEXT_INSIGHT_KEYDOWN";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_CLICK = "ON_PREVIOUS_INSIGHT_CLICK";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_KEYDOWN = "ON_PREVIOUS_INSIGHT_KEYDOWN";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_CLICK = "ON_ACTION_CLICK";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_KEYDOWN = "ON_ACTION_KEYDOWN";
        NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_ICON_KEYDOWN = "ON_CLOSE_ICON_KEYDOWN";
        NotesAnalysisPopupConstants.MeetingRequestType = "MeetingRequest";
        NotesAnalysisPopupConstants.IssueType = "Issue";
        NotesAnalysisPopupConstants.SendContentRequestType = "SendContentRequest";
        NotesAnalysisPopupConstants.NewContactType = "NewContact";
        NotesAnalysisPopupConstants.CallActivityType = "CallActivity";
        NotesAnalysisPopupConstants.MeetingActivityType = "MeetingActivity";
        NotesAnalysisPopupConstants.ActionItemDelegatedType = "ActionItemDelegated";
        NotesAnalysisPopupConstants.ActionItemCommitmentType = "ActionItemCommitment";
        NotesAnalysisPopupConstants.ActionItemRequestType = "ActionItemRequest";
        NotesAnalysisPopupConstants.InsightTypeRanks = {
            MeetingActivity: 0.9,
            CallActivity: 1,
            NewContact: 2,
            ActionItemRequest: 3,
            ActionItemDelegated: 4,
            ActionItemCommitment: 5,
            MeetingRequest: 6,
            SendContentRequest: 7,
            IssueType: 8
        };
        NotesAnalysisContainer.NotesAnalysisPopupConstants = NotesAnalysisPopupConstants;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupHelper = (function () {
            function NotesAnalysisPopupHelper() {
            }
            NotesAnalysisPopupHelper.GetDescriptionLabel = function (insight, _context) {
                var description;
                // Not adding particiapants to description for now
                switch (insight.teeType) {
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingRequestType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_DESCRIPTION, _context);
                        description = NotesAnalysisPopupHelper.AddScheduledTime(description, insight, _context);
                        //description = NotesAnalysisPopupHelper.AddAttendees(description, insight, _context); 
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.IssueType:
                        var issueDetail = NotesAnalysisPopupHelper.GetParameter(insight, "subject");
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_DESCRIPTION, _context);
                        if (issueDetail) {
                            description += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context)
                                + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_REGARDING, _context)
                                + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context)
                                + issueDetail;
                        }
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.SendContentRequestType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_DESCRIPTION, _context);
                        break;
                    //TODO: TITLE
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.NewContactType:
                        var contactName = NotesAnalysisPopupHelper.GetParameter(insight, "lastname");
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_DESCRIPTION, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + contactName;
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.CallActivityType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_DESCRIPTION, _context);
                        description = NotesAnalysisPopupHelper.AddScheduledTime(description, insight, _context);
                        //description = NotesAnalysisPopupHelper.AddAttendees(description, insight, _context); 
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingActivityType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_DESCRIPTION, _context);
                        description = NotesAnalysisPopupHelper.AddScheduledTime(description, insight, _context);
                        //description = NotesAnalysisPopupHelper.AddAttendees(description, insight, _context); 
                        break;
                    //TODO: OWNERS
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemDelegatedType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_DESCRIPTION, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemCommitmentType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_DESCRIPTION, _context);
                        break;
                    //TODO: OWNERS
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemRequestType:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_DESCRIPTION, _context);
                        break;
                    default:
                        description = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_DESCRIPTION, _context);
                        break;
                }
                description += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_QUESTION_MARK, _context);
                return description;
            };
            NotesAnalysisPopupHelper.GetTitleLabel = function (insight, _context) {
                var title;
                switch (insight.teeType) {
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingRequestType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.IssueType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.SendContentRequestType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.NewContactType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.CallActivityType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingActivityType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemDelegatedType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemCommitmentType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_TITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemRequestType:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_REQUEST_TITLE, _context);
                        break;
                    default:
                        title = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_DEFAULT_TITLE, _context);
                }
                return title;
            };
            NotesAnalysisPopupHelper.GetSubTitleLabel = function (insight, _context) {
                var subtitle;
                switch (insight.teeType) {
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingRequestType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_REQUEST_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.IssueType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ISSUE_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.SendContentRequestType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SEND_CONTENT_REQUEST_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.NewContactType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEWCONTACT_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.CallActivityType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CALL_ACTIVITY_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.MeetingActivityType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_MEETING_ACTIVITY_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemDelegatedType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_DELEGATED_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemCommitmentType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_COMMITMENT_SUBTITLE, _context);
                        break;
                    case NotesAnalysisContainer.NotesAnalysisPopupConstants.ActionItemRequestType:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_ITEM_REQUEST_SUBTITLE, _context);
                        break;
                    default:
                        subtitle = NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_DEFAULT_SUBTITLE, _context);
                }
                return subtitle;
            };
            NotesAnalysisPopupHelper.GetButtonTooltip = function (action, entityName, _context) {
                if (action.actionId == 3) {
                    return NotesAnalysisPopupHelper.Localize(action.actionName, _context);
                }
                return NotesAnalysisPopupHelper.Localize(action.actionName, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + NotesAnalysisPopupHelper.Localize(entityName, _context);
            };
            NotesAnalysisPopupHelper.Localize = function (content, _context) {
                return _context.resources.getString(content);
            };
            // Ranks the insights and removes duplicates
            NotesAnalysisPopupHelper.SortInsights = function (insights) {
                if (insights == null || insights.length == 0) {
                    return insights;
                }
                var sortedInsights = insights.sort(function (a, b) {
                    return NotesAnalysisContainer.NotesAnalysisPopupConstants.InsightTypeRanks[a.insight.teeType] - NotesAnalysisContainer.NotesAnalysisPopupConstants.InsightTypeRanks[b.insight.teeType];
                });
                var length = 1;
                for (var i = 1; i < sortedInsights.length; ++i) {
                    if (sortedInsights[length - 1].insight != sortedInsights[i].insight) {
                        sortedInsights[length] = sortedInsights[i];
                        length++;
                    }
                }
                sortedInsights.length = length;
                return sortedInsights;
            };
            NotesAnalysisPopupHelper.GetAttendees = function (attendees, _context) {
                var numberOfAttendees = attendees.length;
                if (numberOfAttendees == 1)
                    return attendees[0];
                var attendeeString = "";
                for (var i = 0; i < numberOfAttendees - 1; ++i) {
                    attendeeString += attendees[i] + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context);
                    if (i != numberOfAttendees - 2) {
                        attendeeString += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_COMMA, _context);
                    }
                }
                attendeeString += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_AND, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + attendees[numberOfAttendees - 1];
                return attendeeString;
            };
            NotesAnalysisPopupHelper.AddAttendees = function (description, insight, _context) {
                var attendees = NotesAnalysisPopupHelper.GetParameter(insight, "participants");
                if (attendees) {
                    description += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_WITH, _context)
                        + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + NotesAnalysisPopupHelper.GetAttendees(attendees, _context);
                }
                return description;
            };
            NotesAnalysisPopupHelper.AddScheduledTime = function (description, insight, _context) {
                var scheduledTime = NotesAnalysisPopupHelper.GetParameter(insight, "scheduledstart");
                if (!scheduledTime) {
                    scheduledTime = NotesAnalysisPopupHelper.GetParameter(insight, "scheduledend");
                }
                if (scheduledTime) {
                    description += NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ON, _context) + NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context) + NotesAnalysisPopupHelper.GetTimeInUserZone(scheduledTime, _context);
                }
                return description;
            };
            NotesAnalysisPopupHelper.GetTimeInUserZone = function (dateTimeString, _context) {
                return _context.formatting.formatDateLongAbbreviated(new Date(dateTimeString));
            };
            NotesAnalysisPopupHelper.GetParameter = function (insight, paramName) {
                if (insight.actionItem != null && insight.actionItem.length != 0 && insight.actionItem[0].parameters &&
                    insight.actionItem[0].parameters[paramName]) {
                    return insight.actionItem[0].parameters[paramName];
                }
                return null;
            };
            return NotesAnalysisPopupHelper;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupHelper = NotesAnalysisPopupHelper;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var PerformNotesAnalysisActionRequest = (function () {
            function PerformNotesAnalysisActionRequest() {
            }
            PerformNotesAnalysisActionRequest.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    operationName: "msdyn_PerformNotesAnalysisAction",
                    operationType: 0,
                    parameterTypes: {
                        "EntityName": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "SerializedAction": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "ParentEntityName": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        },
                        "ParentEntityId": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        }
                    }
                };
                return metadata;
            };
            return PerformNotesAnalysisActionRequest;
        }());
        NotesAnalysisContainer.PerformNotesAnalysisActionRequest = PerformNotesAnalysisActionRequest;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupModel = (function () {
            function NotesAnalysisPopupModel() {
                this.insights = null;
                this.primaryActionIndex = 0;
                this.currentInsightIndex = 0;
            }
            NotesAnalysisPopupModel.prototype.setInsight = function (insight) {
                var insights;
                try {
                    this.insights = JSON.parse(insight);
                    this.insights = NotesAnalysisContainer.NotesAnalysisPopupHelper.SortInsights(this.insights);
                }
                catch (e) {
                }
            };
            NotesAnalysisPopupModel.prototype.getInsight = function () {
                if (this.insights && this.insights.length > 0) {
                    return this.insights[this.currentInsightIndex];
                }
                else {
                    return null;
                }
            };
            NotesAnalysisPopupModel.prototype.getActionItemCount = function () {
                if (this.insights == null) {
                    return 0;
                }
                return this.insights[this.currentInsightIndex].insight.actionItem.length;
            };
            NotesAnalysisPopupModel.prototype.setPrimaryActionIndex = function (index) {
                this.primaryActionIndex = index;
            };
            NotesAnalysisPopupModel.prototype.getPrimaryActionIndex = function () {
                return this.primaryActionIndex;
            };
            NotesAnalysisPopupModel.prototype.getCurrentInsightIndex = function () {
                return this.currentInsightIndex;
            };
            NotesAnalysisPopupModel.prototype.incrementCurrentInsightIndex = function () {
                this.currentInsightIndex += 1;
            };
            NotesAnalysisPopupModel.prototype.decrementCurrentInsightIndex = function () {
                if (this.currentInsightIndex > 0) {
                    this.currentInsightIndex -= 1;
                }
            };
            NotesAnalysisPopupModel.prototype.getInsightsCount = function () {
                if (this.insights == null) {
                    return 0;
                }
                return this.insights.length;
            };
            return NotesAnalysisPopupModel;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupModel = NotesAnalysisPopupModel;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var ActionContainerView = (function () {
            function ActionContainerView(model, observer) {
                this.observer = observer;
                this.model = model;
            }
            ActionContainerView.prototype.getButtonLabel = function (content, _context) {
                return _context.factory.createElement("LABEL", {}, content);
            };
            ActionContainerView.prototype.getButtons = function (_context) {
                var insight = this.model.getInsight().insight;
                var actions = insight.actionItem;
                var buttons = [];
                var actionLength = actions.length;
                var currentIndex = 0;
                for (var i = 0; i < actions.length; ++i) {
                    if (actions[i].isPrimary) {
                        currentIndex = i;
                        break;
                    }
                }
                this.model.setPrimaryActionIndex(currentIndex);
                for (var i = 0; i < actions.length; ++i) {
                    var action = actions[currentIndex];
                    buttons.push(this.getButton(insight, currentIndex, _context));
                    currentIndex = (currentIndex + 1) % actionLength;
                }
                return buttons;
            };
            ActionContainerView.prototype.getButton = function (insight, index, _context) {
                var _this = this;
                var action = insight.actionItem[index];
                var label = NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(action.actionName, _context);
                var tooltip = NotesAnalysisContainer.NotesAnalysisPopupHelper.GetButtonTooltip(action, insight.entityName, _context);
                var buttonStyle = action.isPrimary ? _context.theming.buttons.button01primary : _context.theming.buttons.button01secondary;
                buttonStyle = JSON.parse(JSON.stringify(buttonStyle));
                buttonStyle[":focus"] = buttonStyle[":hover"];
                if (!action.isPrimary) {
                    buttonStyle["color"] = _context.theming.colors.maintheme.maincolor1.fill;
                    buttonStyle[":focus"]["color"] = _context.theming.colors.maintheme.maincolor1.text;
                }
                var button = _context.factory.createElement("BUTTON", {
                    key: this.getId("notesAnalysisbutton_" + index),
                    id: this.getId("notesAnalysisbutton_" + index),
                    tabIndex: 0,
                    title: tooltip,
                    role: "button",
                    accessibilityLabel: tooltip,
                    autoFocus: true,
                    onClick: function () { return _this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_CLICK, index); },
                    onKeyDown: function (event) { return _this.onKeyDownEvent.bind(_this)(event, index); },
                    style: buttonStyle
                }, this.getButtonLabel(label, _context));
                return _context.factory.createElement("CONTAINER", {
                    style: {
                        marginRight: _context.theming.measures.measure100
                    }
                }, button);
            };
            ActionContainerView.prototype.onKeyDownEvent = function (event, index) {
                this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_KEYDOWN, {
                    event: event,
                    index: index
                });
            };
            ActionContainerView.prototype.getComponent = function (_context) {
                var actionContainer = _context.factory.createElement("CONTAINER", {
                    key: this.getId("actionContainer"),
                    id: this.getId("actionContainer"),
                    autoFocus: true,
                    style: {
                        align: "right",
                        flexDirection: "row",
                        width: "100%",
                        justifyContent: "flex-end",
                        paddingBottom: _context.theming.measures.measure100
                    }
                }, this.getButtons(_context));
                return actionContainer;
            };
            ActionContainerView.prototype.getId = function (id) {
                return "notes_analysis" + "_" + "action_container_view" + "_" + id;
            };
            ActionContainerView.prototype.cleanup = function () {
                this.observer = null;
                this.model = null;
            };
            return ActionContainerView;
        }());
        NotesAnalysisContainer.ActionContainerView = ActionContainerView;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var IconView = (function () {
            function IconView(model, observer) {
                this.observer = observer;
                this.model = model;
            }
            IconView.prototype.getComponent = function (_context) {
                var imginfoControl = _context.factory.createElement("MICROSOFTICON", {
                    id: this.getId("imginfo_id"),
                    key: this.getId("imginfo_key"),
                    style: {
                        color: _context.theming.colors.grays.gray07,
                        fontSize: "16px",
                        margin: "0 auto"
                    },
                    type: 327
                });
                var popupIcon = _context.factory.createElement("CONTAINER", {
                    id: this.getId("popupIcon"),
                    key: this.getId("popupIcon"),
                    style: {
                        width: _context.theming.measures.measure250,
                        height: _context.theming.measures.measure250,
                        //lineHeight: this._context.theming.measures.measure300,
                        //marginRight: this._context.theming.measures.measure015,
                        //fontSize: this._context.theming.measures.measure100,
                        overflow: "hidden",
                        color: "#333333",
                        alignItems: "center",
                        verticalAlign: "middle",
                        borderRadius: "100%",
                        backgroundColor: _context.theming.colors.grays.gray03,
                        display: "flex"
                    }
                }, imginfoControl);
                var popupIconContainer = _context.factory.createElement("CONTAINER", {
                    id: this.getId("iconContainer"),
                    key: this.getId("iconContainer"),
                    style: {
                        textAlign: "center",
                        verticalAlign: "middle",
                        display: "table-cell",
                        marginRight: _context.client.isRTL ? _context.theming.measures.measure015 : "0"
                    }
                }, popupIcon);
                return popupIconContainer;
            };
            IconView.prototype.getId = function (id) {
                return "notes_analysis" + "_" + "icon_view" + "_" + id;
            };
            IconView.prototype.cleanup = function () {
                this.model = null;
                this.observer = null;
            };
            return IconView;
        }());
        NotesAnalysisContainer.IconView = IconView;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var PopupDetailView = (function () {
            function PopupDetailView(model, observer) {
                this.observer = observer;
                this.model = model;
                this.iconView = new NotesAnalysisContainer.IconView(model, observer);
                this.popupLabelView = new NotesAnalysisContainer.PopupLabelView(model, observer);
            }
            PopupDetailView.prototype.getComponent = function (_context) {
                var popupDetailsContainer = _context.factory.createElement("CONTAINER", {
                    key: this.getId("popupDetailsContainer"),
                    id: this.getId("popupDetailsContainer"),
                    style: {
                        paddingLeft: _context.theming.measures.measure100,
                        paddingRight: _context.theming.measures.measure100,
                        paddingTop: _context.theming.measures.measure100,
                        paddingBottom: _context.theming.measures.measure100,
                        whiteSpace: "normal"
                    }
                }, [this.iconView.getComponent(_context), this.popupLabelView.getComponent(_context)]);
                return popupDetailsContainer;
            };
            PopupDetailView.prototype.getId = function (id) {
                return "notes_analysis" + "_" + "popup_detail_view" + "_" + id;
            };
            PopupDetailView.prototype.cleanup = function () {
                this.iconView.cleanup();
                this.popupLabelView.cleanup();
                this.model = null;
                this.observer = null;
            };
            return PopupDetailView;
        }());
        NotesAnalysisContainer.PopupDetailView = PopupDetailView;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var PopupLabelView = (function () {
            function PopupLabelView(model, observer) {
                this.observer = observer;
                this.model = model;
            }
            PopupLabelView.prototype.getCloseIcon = function (_context) {
                var _this = this;
                var closePopupLabel = NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(_context.resources.getString(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_DIALOG), _context);
                var popupCloseIcon = _context.factory.createElement("MICROSOFTICON", {
                    id: this.getId("popupCloseIcon"),
                    key: this.getId("popupCloseIcon"),
                    style: {
                        margin: "0 auto",
                        color: _context.theming.colors.grays.gray07,
                        fontSize: "16px"
                    },
                    type: 97
                });
                var popupCloseContainer = _context.factory.createElement("CONTAINER", {
                    key: this.getId("popupCloseContainer"),
                    id: this.getId("popupCloseContainer"),
                    accessibilityLabel: closePopupLabel,
                    title: closePopupLabel,
                    role: "button",
                    tabIndex: 0,
                    style: {
                        display: "flex",
                        backgroundColor: _context.theming.colors.whitebackground,
                        whiteSpace: "normal",
                        alignItems: "center",
                        overflow: "hidden",
                        width: _context.theming.measures.measure250,
                        height: _context.theming.measures.measure250,
                        cursor: "pointer",
                        marginLeft: "auto"
                    },
                    onClick: function () { return _this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP); },
                    onKeyDown: function (event) { return _this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_ICON_KEYDOWN, event); }
                }, popupCloseIcon);
                return popupCloseContainer;
            };
            PopupLabelView.prototype.getNavigationIcon = function (isNextIcon, showIcon, clickEvent, keyDownEvent, _context) {
                var _this = this;
                var iconTooltip;
                if (isNextIcon) {
                    iconTooltip = NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(_context.resources.getString(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT), _context);
                }
                else {
                    iconTooltip = NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(_context.resources.getString(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT), _context);
                }
                var popupNextIconIcon = _context.factory.createElement("MICROSOFTICON", {
                    id: this.getId("popupIcon" + (isNextIcon ? "Next" : "Previous")),
                    key: this.getId("popupIcon" + (isNextIcon ? "Next" : "Previous")),
                    style: {
                        margin: "0 auto",
                        color: _context.theming.colors.grays.gray07,
                        fontSize: "16px"
                    },
                    type: isNextIcon ? 62 : 245
                });
                var popupNextIconContainer;
                if (showIcon) {
                    popupNextIconContainer = _context.factory.createElement("CONTAINER", {
                        key: this.getId("popupIconContainer" + (isNextIcon ? "Next" : "Previous")),
                        id: this.getId("popupIconContainer" + (isNextIcon ? "Next" : "Previous")),
                        accessibilityLabel: iconTooltip,
                        title: iconTooltip,
                        role: "button",
                        tabIndex: 0,
                        style: {
                            display: "flex",
                            backgroundColor: _context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            alignItems: "center",
                            overflow: "hidden",
                            width: _context.theming.measures.measure250,
                            height: _context.theming.measures.measure250,
                            cursor: "pointer",
                            ":hover": {
                                backgroundColor: _context.theming.colors.grays.gray02
                            }
                        },
                        onClick: function () { return _this.observer.publish(clickEvent); },
                        onKeyDown: function (event) { return _this.observer.publish(keyDownEvent, event); }
                    }, popupNextIconIcon);
                }
                else {
                    popupNextIconContainer = _context.factory.createElement("CONTAINER", {
                        key: this.getId("popupIconContainer" + (isNextIcon ? "Next" : "Previous")),
                        id: this.getId("popupIconContainer" + (isNextIcon ? "Next" : "Previous")),
                        tabIndex: -1,
                        style: {
                            display: "flex",
                            backgroundColor: _context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            alignItems: "center",
                            overflow: "hidden",
                            width: _context.theming.measures.measure250,
                            height: _context.theming.measures.measure250
                        }
                    }, null);
                }
                return popupNextIconContainer;
            };
            PopupLabelView.prototype.getNavigationIcons = function (_context) {
                if (this.model.getInsightsCount() <= 1) {
                    return [];
                }
                var showPreviousIcon = this.model.getCurrentInsightIndex() > 0;
                var showNextIcon = this.model.getCurrentInsightIndex() != this.model.getInsightsCount() - 1;
                var icons = [];
                if (showPreviousIcon || (!showPreviousIcon && !showNextIcon)) {
                    icons.push(this.getNavigationIcon(false, showPreviousIcon, NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_CLICK, NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_KEYDOWN, _context));
                }
                if (showNextIcon || (!showPreviousIcon && !showNextIcon)) {
                    icons.push(this.getNavigationIcon(true, showNextIcon, NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK, NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN, _context));
                }
                return icons;
            };
            PopupLabelView.prototype.getInsightCount = function () {
                var currentInsight = this.model.getCurrentInsightIndex() + 1;
                var totalInsights = this.model.getInsightsCount();
                return currentInsight + "/" + totalInsights;
            };
            PopupLabelView.prototype.getInsightCountSentence = function () {
                var currentInsight = this.model.getCurrentInsightIndex() + 1;
                var totalInsights = this.model.getInsightsCount();
                return currentInsight + " of " + totalInsights;
            };
            PopupLabelView.prototype.getComponent = function (_context) {
                var formatedTitle = NotesAnalysisContainer.NotesAnalysisPopupHelper.GetTitleLabel(this.model.getInsight().insight, _context);
                var popupSubTitleLabel = NotesAnalysisContainer.NotesAnalysisPopupHelper.GetSubTitleLabel(this.model.getInsight().insight, _context);
                var popupSubTitleDescription = NotesAnalysisContainer.NotesAnalysisPopupHelper.GetDescriptionLabel(this.model.getInsight().insight, _context);
                var popupDescriptionLabel = NotesAnalysisContainer.NotesAnalysisPopupHelper.GetDescriptionLabel(this.model.getInsight().insight, _context);
                var popupTitleText = formatedTitle
                    + (this.model.getInsightsCount() > 1 ? (NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context)
                        + this.getInsightCount()) : "");
                var popupTitleAccessibilityLabel = formatedTitle
                    + (this.model.getInsightsCount() > 1 ? (NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_SPACE, _context)
                        + this.getInsightCountSentence()) : "");
                var popupTitle = _context.factory.createElement("LABEL", {
                    key: this.getId("popupTitle"),
                    id: this.getId("popupTitle"),
                    title: popupTitleText,
                    accessibilityLabel: popupTitleAccessibilityLabel,
                    role: "heading",
                    style: {
                        color: "#3b79b7",
                        fontSize: _context.theming.fontsizes.font100,
                        fontFamily: _context.theming.fontfamilies.regular,
                        maxWidth: "calc(100% - 1rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap"
                    }
                }, popupTitleText);
                var titleWithForwardIcon = _context.factory.createElement("CONTAINER", {
                    key: this.getId("actionContainer"),
                    id: this.getId("actionContainer"),
                    autoFocus: true,
                    style: {
                        display: "flex",
                        flexDirection: "row",
                        width: "100%",
                        alignItems: "center"
                    }
                }, [popupTitle].concat(this.getNavigationIcons(_context)).concat(this.getCloseIcon(_context)));
                var popupSubTitle = _context.factory.createElement("LABEL", {
                    key: this.getId("popupSubTitle"),
                    id: this.getId("popupSubTitle"),
                    title: popupSubTitleLabel,
                    accessibilityLabel: popupSubTitleLabel,
                    style: {
                        fontFamily: _context.theming.fontfamilies.semibold,
                        fontSize: _context.theming.fontsizes.font100,
                        maxWidth: "calc(100% - 1rem)",
                        display: "block",
                        textOverflow: "ellipsis",
                        overflow: "hidden",
                        whiteSpace: "nowrap",
                        color: _context.theming.colors.base.black
                    }
                }, popupSubTitleLabel);
                //this element is for screen reader to read the title description
                var popupSubTitleDescriptionId = _context.factory.createElement("LABEL", {
                    key: this.getId("popupSubTitleDescriptionId"),
                    id: this.getId("popupSubTitleDescriptionId"),
                    accessibilityLabel: popupSubTitleDescription,
                    style: {
                        display: "none"
                    }
                }, popupSubTitleDescription);
                var popupDescription = _context.factory.createElement("LABEL", {
                    key: this.getId("popupDescription"),
                    id: this.getId("popupDescription"),
                    title: popupDescriptionLabel,
                    accessibilityLabel: popupDescriptionLabel,
                    style: {
                        fontFamily: _context.theming.fontfamilies.regular,
                        color: _context.theming.colors.grays.gray07,
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        position: "relative",
                        wordBreak: "break-word",
                        display: "block",
                        whiteSpace: "pre-wrap",
                        wordWrap: "break-word",
                        fontSize: _context.theming.fontsizes.font100,
                        paddingTop: _context.theming.measures.measure050
                    }
                }, popupDescriptionLabel);
                var popupLabelsContainer = _context.factory.createElement("CONTAINER", {
                    key: this.getId("popupLabelsContainer"),
                    id: this.getId("popupLabelsContainer"),
                    style: {
                        display: "block",
                        position: "relative",
                        width: "100%",
                        overflow: "hidden"
                    }
                }, [titleWithForwardIcon, popupSubTitle, popupDescription, popupSubTitleDescriptionId]);
                var popupLabelsMainContainer = _context.factory.createElement("CONTAINER", {
                    key: this.getId("popupLabelsMainContainer"),
                    id: this.getId("popupLabelsMainContainer"),
                    style: {
                        alignItems: "center",
                        paddingLeft: _context.theming.measures.measure075,
                        display: "block",
                        width: "100%",
                        overflow: "hidden"
                    }
                }, popupLabelsContainer);
                return popupLabelsMainContainer;
            };
            PopupLabelView.prototype.getId = function (id) {
                return "notes_analysis" + "_" + "popup_label_view" + "_" + id;
            };
            PopupLabelView.prototype.cleanup = function () {
                this.model = null;
                this.observer = null;
            };
            return PopupLabelView;
        }());
        NotesAnalysisContainer.PopupLabelView = PopupLabelView;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        /*
                                PopupView
                                /       \
                   PopupDetailView      ActionContainerView
                   /      |
           IconView PopupLabelView
        */
        var PopupView = (function () {
            function PopupView(model, observer) {
                this.observer = observer;
                this.model = model;
                this.actionContainerView = new NotesAnalysisContainer.ActionContainerView(model, this.observer);
                this.popupDetailView = new NotesAnalysisContainer.PopupDetailView(model, this.observer);
            }
            PopupView.prototype.getComponent = function (_context) {
                if (this.model.getInsight()) {
                    var popupWithActionsContainer = _context.factory.createElement("CONTAINER", {
                        key: this.getId("popupWithActionsContainer"),
                        id: this.getId("popupWithActionsContainer"),
                        autoFocus: true,
                        style: {
                            whiteSpace: "normal",
                            flexDirection: "column",
                            width: "100%"
                        }
                    }, [this.popupDetailView.getComponent(_context), this.actionContainerView.getComponent(_context)]);
                    var popupContainer = _context.factory.createElement("CONTAINER", {
                        key: this.getId("popupContainer"),
                        id: this.getId("popupContainer"),
                        style: {
                            display: "block",
                            height: "auto",
                            backgroundColor: _context.theming.colors.whitebackground,
                            whiteSpace: "normal",
                            border: _context.theming.borders.border02,
                            boxSizing: "border-box",
                            width: "25em",
                            maxWidth: "95vw",
                            boxShadow: "0px 2px 4px 0px rgba(0,0,0,0.5)"
                        }
                    }, popupWithActionsContainer);
                    return popupContainer;
                }
                else {
                    return _context.factory.createElement("CONTAINER", {});
                }
            };
            PopupView.prototype.getId = function (id) {
                return "notes_analysis" + "_" + "popup_view" + "_" + id;
            };
            PopupView.prototype.cleanup = function () {
                this.actionContainerView.cleanup();
                this.popupDetailView.cleanup();
                this.model = null;
                this.observer = null;
            };
            return PopupView;
        }());
        NotesAnalysisContainer.PopupView = PopupView;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupObserver = (function () {
            function NotesAnalysisPopupObserver() {
                this.subscribers = {};
            }
            NotesAnalysisPopupObserver.prototype.subscribe = function (event, callback) {
                if (!this.subscribers[event]) {
                    this.subscribers[event] = [];
                }
                this.subscribers[event].push(callback);
            };
            NotesAnalysisPopupObserver.prototype.publish = function (event, args) {
                if (!this.subscribers[event] || this.subscribers[event].length < 1)
                    return;
                this.subscribers[event].forEach(function (callback) {
                    try {
                        if (args == null) {
                            callback();
                        }
                        else {
                            callback(args);
                        }
                    }
                    catch (e) {
                    }
                });
            };
            NotesAnalysisPopupObserver.prototype.cleanup = function () {
                this.subscribers = {};
            };
            return NotesAnalysisPopupObserver;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupObserver = NotesAnalysisPopupObserver;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupController = (function () {
            function NotesAnalysisPopupController(context, insight) {
                this.CLOSE_POPUP_EVENT = "ClosePopup";
                this.context = context;
                this.model = new NotesAnalysisContainer.NotesAnalysisPopupModel();
                this.model.setInsight(insight);
                this.observer = new NotesAnalysisContainer.NotesAnalysisPopupObserver();
                this.view = new NotesAnalysisContainer.PopupView(this.model, this.observer);
                this.addSubscribers();
            }
            NotesAnalysisPopupController.prototype.getView = function (context) {
                this.context = context;
                return this.view.getComponent(context);
            };
            NotesAnalysisPopupController.prototype.cleanup = function (context) {
                return this.view.cleanup();
            };
            NotesAnalysisPopupController.prototype.onButtonClick = function (index) {
                var insight = this.model.getInsight().insight;
                var action = insight.actionItem[index];
                var actionId = action.actionId;
                var params = JSON.parse(JSON.stringify(action.parameters));
                var event = new NotesAnalysisContainer.NotesAnalysisPopupActionInvokedEvent(actionId, insight.teeType, this.getClient(), this.getOrganizationId());
                this.context.reporting.reportEvent(event);
                this.performAction(insight.entityName, action);
            };
            NotesAnalysisPopupController.prototype.performAction = function (entityName, action) {
                var that = this;
                var actionId = parseInt(action.actionId);
                switch (actionId) {
                    //Auto create
                    case 1:
                        this.sendPerformActionRequest(entityName, JSON.stringify(action), this.context.page.entityTypeName, this.context.page.entityId).then(function (response) {
                            response.json().then(function (value) {
                                var result = JSON.parse(value.Result);
                                if (result != null && result.IsSuccess) {
                                    that.context.utils.addGlobalNotification(1, 1, NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENITY_CREATION_SUCCESSFULL, that.context), "", {
                                        actionLabel: NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_VIEW_RECORD, that.context),
                                        eventHandler: function () {
                                            that.context.navigation.openForm({ entityName: entityName, entityId: result.output.EntityId, openInNewWindow: true });
                                        }
                                    }, null);
                                }
                                else {
                                    var event = new NotesAnalysisContainer.NotesAnalysisPopupErrorEvent("performAction: for actionId " + actionId + "\n" + result.output.Error, that.getClient(), that.getOrganizationId());
                                    that.context.reporting.reportEvent(event);
                                    that.context.utils.addGlobalNotification(1, 2, NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENTITY_CREATION_FAILURE, that.context), "", null, null);
                                }
                            }, function (reason) {
                                var event = new NotesAnalysisContainer.NotesAnalysisPopupErrorEvent("performAction: for actionId " + actionId + "\n" + reason, that.getClient(), that.getOrganizationId());
                                that.context.reporting.reportEvent(event);
                                that.context.utils.addGlobalNotification(1, 2, NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENTITY_CREATION_FAILURE, that.context), "", null, null);
                            });
                        }, function (err) {
                            var event = new NotesAnalysisContainer.NotesAnalysisPopupErrorEvent("performAction: for actionId " + actionId + "\n" + err.message, that.getClient(), that.getOrganizationId());
                            that.context.reporting.reportEvent(event);
                            that.context.utils.addGlobalNotification(1, 2, NotesAnalysisContainer.NotesAnalysisPopupHelper.Localize(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ENTITY_CREATION_FAILURE, that.context), "", null, null);
                        });
                        break;
                    //Edit and create
                    case 2:
                    //Send email
                    case 3:
                        var params = JSON.parse(JSON.stringify(action.parameters));
                        params["regardingobjectid"] = JSON.stringify({ id: this.context.page.entityId, entityType: this.context.page.entityTypeName });
                        if (entityName != null) {
                            var formOptions = {
                                entityName: entityName,
                                useQuickCreateForm: true,
                                openInNewWindow: true
                            };
                            this.context.navigation.openForm(formOptions, params).then(function (sucessResponse) {
                            }, function (errorResponse) {
                                var event = new NotesAnalysisContainer.NotesAnalysisPopupErrorEvent("performAction: for actionId " + actionId + "\n" + errorResponse.message, that.getClient(), that.getOrganizationId());
                                that.context.reporting.reportEvent(event);
                                // CRM is opening form in a new window vut still calling the error callback
                                //that.context.utils.addGlobalNotification(1, 2, NotesAnalysisPopupHelper.Localize(NotesAnalysisPopupConstants.NOTES_ANALYSIS_UNABLE_TO_OPEN_FORM, that.context), "", null, null);
                            });
                            break;
                        }
                }
                this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK);
            };
            NotesAnalysisPopupController.prototype.sendPerformActionRequest = function (entityName, serializedAction, parentEntityName, parentEntityId) {
                var that = this;
                var request = new NotesAnalysisContainer.PerformNotesAnalysisActionRequest();
                request.EntityName = entityName;
                request.SerializedAction = serializedAction;
                request.ParentEntityName = parentEntityName;
                request.ParentEntityId = parentEntityId;
                var start = performance.now();
                return this.context.webAPI.execute(request);
            };
            NotesAnalysisPopupController.prototype.onActionKeyDown = function (event, index) {
                var primaryActionIndex = this.model.getPrimaryActionIndex();
                var actionItemCount = this.model.getActionItemCount();
                // Handle Tab on last button - focus should move to first focusable item
                if (!event.shiftKey && event.keyCode == 9 && ((primaryActionIndex == 0 && index == actionItemCount - 1) || (primaryActionIndex != 0 && primaryActionIndex - 1 == index))) {
                    var elementToFocus = "notes_analysis_popup_label_view_popupCloseContainer";
                    if (this.model.getInsightsCount() > 1) {
                        elementToFocus = "notes_analysis_popup_label_view_popupIconContainerNext";
                        if (this.model.getCurrentInsightIndex() == this.model.getInsightsCount() - 1) {
                            elementToFocus = "notes_analysis_popup_label_view_popupIconContainerPrevious";
                        }
                    }
                    this.context.accessibility.focusElementById(elementToFocus);
                    event.preventDefault();
                    event.stopPropogation();
                }
                else if (event.keyCode == 13) {
                    this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_CLICK, index);
                    event.stopPropogation();
                }
            };
            NotesAnalysisPopupController.prototype.onCloseIconKeyDown = function (event) {
                if (event.keyCode == 13) {
                    this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP);
                    event.stopPropogation();
                }
            };
            NotesAnalysisPopupController.prototype.onNextIconKeyDown = function (event) {
                if (event.keyCode == 13) {
                    this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK);
                    event.stopPropogation();
                }
            };
            NotesAnalysisPopupController.prototype.onPreviousIconKeyDown = function (event) {
                if (event.keyCode == 13) {
                    this.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_CLICK);
                    event.stopPropogation();
                }
            };
            NotesAnalysisPopupController.prototype.getClient = function () {
                return this.context.client.getClient();
            };
            NotesAnalysisPopupController.prototype.getOrganizationId = function () {
                return this.context.orgSettings.organizationId;
            };
            NotesAnalysisPopupController.prototype.addSubscribers = function () {
                var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupInitEvent(this.getClient(), this.getOrganizationId());
                this.context.reporting.reportEvent(telemetryEvent);
                var that = this;
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP, function () {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupCloseClickEvent(that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.context.utils.fireEvent(that.CLOSE_POPUP_EVENT, {});
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK, function (index) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupClickEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_CLICK, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.model.incrementCurrentInsightIndex();
                    if (that.model.getCurrentInsightIndex() >= that.model.getInsightsCount()) {
                        that.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP);
                    }
                    else {
                        that.context.utils.requestRender(function () {
                            var elementToFocus = "notes_analysis_popup_label_view_popupIconContainerNext";
                            if (that.model.getCurrentInsightIndex() == that.model.getInsightsCount() - 1) {
                                elementToFocus = "notes_analysis_popup_label_view_popupIconContainerPrevious";
                            }
                            that.context.accessibility.focusElementById(elementToFocus);
                        });
                    }
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN, function (event) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupKeyDownEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN, event.keyCode, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.onNextIconKeyDown(event);
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_CLICK, function (index) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupClickEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_CLICK, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.model.decrementCurrentInsightIndex();
                    if (that.model.getCurrentInsightIndex() < 0) {
                        that.observer.publish(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_POPUP);
                    }
                    else {
                        that.context.utils.requestRender(function () {
                            var elementToFocus = "notes_analysis_popup_label_view_popupIconContainerPrevious";
                            if (that.model.getCurrentInsightIndex() == 0) {
                                elementToFocus = "notes_analysis_popup_label_view_popupIconContainerNext";
                            }
                            that.context.accessibility.focusElementById(elementToFocus);
                        });
                    }
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_KEYDOWN, function (event) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupKeyDownEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_PREVIOUS_INSIGHT_KEYDOWN, event.keyCode, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.onPreviousIconKeyDown(event);
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_CLICK, function (index) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupClickEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_CLICK, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.onButtonClick(index);
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_ACTION_KEYDOWN, function (params) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupKeyDownEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN, params.event.keyCode, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.onActionKeyDown(params.event, params.index);
                });
                this.observer.subscribe(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_CLOSE_ICON_KEYDOWN, function (event) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisPopupKeyDownEvent(NotesAnalysisContainer.NotesAnalysisPopupConstants.NOTES_ANALYSIS_NEXT_INSIGHT_KEYDOWN, event.keyCode, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    that.onCloseIconKeyDown(event);
                });
            };
            return NotesAnalysisPopupController;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupController = NotesAnalysisPopupController;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupClick = "NotesAnalysisPopupClick";
        var NotesAnalysisPopupClickEvent = (function () {
            function NotesAnalysisPopupClickEvent(event, client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupClick;
                this.addEventParameter("trigger", event);
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupClickEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupClickEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupClickEvent = NotesAnalysisPopupClickEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupActionInvoked = "NotesAnalysisPopupActionInvoked";
        var NotesAnalysisPopupActionInvokedEvent = (function () {
            function NotesAnalysisPopupActionInvokedEvent(actionId, category, client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupActionInvoked;
                this.addEventParameter("actionId", actionId);
                this.addEventParameter("category", category);
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupActionInvokedEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupActionInvokedEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupActionInvokedEvent = NotesAnalysisPopupActionInvokedEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupKeyDown = "NotesAnalysisPopupKeyDown";
        var NotesAnalysisPopupKeyDownEvent = (function () {
            function NotesAnalysisPopupKeyDownEvent(event, keyCode, client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupKeyDown;
                this.addEventParameter("trigger", event);
                this.addEventParameter("keyCode", keyCode);
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupKeyDownEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupKeyDownEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupKeyDownEvent = NotesAnalysisPopupKeyDownEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupCloseClick = "NotesAnalysisPopupCloseClick";
        var NotesAnalysisPopupCloseClickEvent = (function () {
            function NotesAnalysisPopupCloseClickEvent(client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupCloseClick;
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupCloseClickEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupCloseClickEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupCloseClickEvent = NotesAnalysisPopupCloseClickEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupError = "NotesAnalysisPopupError";
        var NotesAnalysisPopupErrorEvent = (function () {
            function NotesAnalysisPopupErrorEvent(error, client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupError;
                this.addEventParameter("error", error);
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupErrorEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupErrorEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupErrorEvent = NotesAnalysisPopupErrorEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupEventParameter = (function () {
            function NotesAnalysisPopupEventParameter(name, value) {
                this.name = name;
                this.value = value;
            }
            return NotesAnalysisPopupEventParameter;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupEventParameter = NotesAnalysisPopupEventParameter;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupInit = "NotesAnalysisPopupInit";
        var NotesAnalysisPopupInitEvent = (function () {
            function NotesAnalysisPopupInitEvent(client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisPopupInit;
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisPopupInitEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisPopupEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisPopupInitEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupInitEvent = NotesAnalysisPopupInitEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../jsreferences/internal/TypeDefinitions/XrmClientApi.d.ts" />
/// <reference path="CommonReferences.ts" />
/* util */
/// <reference path="utility/NotesAnalysisPopupConstants.ts" />
/// <reference path="utility/NotesAnalysisPopupHelper.ts" />
/// <reference path="utility/PerformNotesAnalysisActionRequest.ts" />
/* model */
/// <reference path="model/NotesAnalysisPopupModel.ts" />
/* view */
/// <reference path="interface/IView.ts" />
/// <reference path="view/ActionContainerView.ts" />
/// <reference path="view/IconView.ts" />
/// <reference path="view/PopupDetailView.ts" />
/// <reference path="view/PopupLabelView.ts" />
/// <reference path="view/PopupView.ts" />
/* observer */
/// <reference path="observer/NotesAnalysisPopupObserver.ts" />
/* controller */
/// <reference path="controller/NotesAnalysisPopupController.ts" />
/* telemetry */
/// <reference path="telemetry/NotesAnalysisPopupClickEvent.ts" />
/// <reference path="telemetry/NotesAnalysisPopupActionInvokedEvent.ts" />
/// <reference path="telemetry/NotesAnalysisPopupKeyDownEvent.ts" />
/// <reference path="telemetry/NotesAnalysisPopupCloseClickEvent.ts" />
/// <reference path="telemetry/NotesAnalysisPopupErrorEvent.ts" />
/// <reference path="telemetry/NotesAnalysisPopupEventParameter.ts" />
/// <reference path="telemetry/NotesAnalysisPopupInitEvent.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisPopupControl = (function () {
            function NotesAnalysisPopupControl() {
                /**
                 * The web resource information for web resource based chart, obtained from property bag
                 */
                this._webResourceState = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            NotesAnalysisPopupControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                this._context = context;
                this.controller = new NotesAnalysisContainer.NotesAnalysisPopupController(context, context.parameters.NAInsight.raw);
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            NotesAnalysisPopupControl.prototype.updateView = function (context) {
                // custom code goes here
                return this.controller.getView(context);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            NotesAnalysisPopupControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            NotesAnalysisPopupControl.prototype.destroy = function () {
            };
            return NotesAnalysisPopupControl;
        }());
        NotesAnalysisContainer.NotesAnalysisPopupControl = NotesAnalysisPopupControl;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="NotesAnalysisPopupControl.ts" />
/// <reference path="privatereferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var ResourceStrings = (function () {
            function ResourceStrings() {
            }
            return ResourceStrings;
        }());
        ResourceStrings._titleMeetingReqCard = "TitleMeetingReqCard";
        ResourceStrings._titleNewContactCard = "TitleNewContactCard";
        ResourceStrings._titleNewTaskCard = "TitleNewTaskCard";
        ResourceStrings._titlePhoneCallCard = "TitlePhoneCallCard";
        ResourceStrings._titleActivityCard = "TitleActivityCard";
        ResourceStrings._defaultDescMeeting = "DefaultMeetingDesc";
        ResourceStrings._defaultDescContact = "DefaultContactDesc";
        ResourceStrings._defaultDescTask = "DefaultTaskDesc";
        ResourceStrings._defaultDescPhoneCall = "DefaultPhoneCallDesc";
        ResourceStrings._defaultDescActivity = "DefaultActivityDesc";
        ResourceStrings._buttonCreate = "CreateButton";
        ResourceStrings._buttonEdit = "EditButton";
        ResourceStrings._errorLoadNAControl = "ErrorLoadNAControl";
        ResourceStrings._errorNoReadPrivilege = "ErrorNoReadPrivilege";
        ResourceStrings._errorNoCreatePrivilege = "ErrorNoCreatePrivilege";
        ResourceStrings._unableToRetrieveInsights = "UnableToRetrieveInsights";
        NotesAnalysisContainer.ResourceStrings = ResourceStrings;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
