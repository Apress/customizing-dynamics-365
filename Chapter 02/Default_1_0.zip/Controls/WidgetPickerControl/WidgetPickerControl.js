/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var WidgetPickerControl;
    (function (WidgetPickerControl_1) {
        "use strict";
        var WidgetPickerControl = (function () {
            function WidgetPickerControl() {
            }
            WidgetPickerControl.prototype.init = function (context, notifyOutputChanged, state, container) {
            };
            WidgetPickerControl.prototype.updateView = function (context) {
            };
            WidgetPickerControl.prototype.getOutputs = function () {
            };
            WidgetPickerControl.prototype.destroy = function () {
            };
            return WidgetPickerControl;
        }());
        WidgetPickerControl_1.WidgetPickerControl = WidgetPickerControl;
    })(WidgetPickerControl = MscrmControls.WidgetPickerControl || (MscrmControls.WidgetPickerControl = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=WidgetPickerControl.js.map