/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisControlEventParameter = (function () {
            function NotesAnalysisControlEventParameter(name, value) {
                this.name = name;
                this.value = value;
            }
            return NotesAnalysisControlEventParameter;
        }());
        NotesAnalysisContainer.NotesAnalysisControlEventParameter = NotesAnalysisControlEventParameter;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisControlInsightRetrieveFailure = "NAControlInsightRetrieveFailure";
        var NotesAnalysisControlInsightRetrieveFailureEvent = (function () {
            function NotesAnalysisControlInsightRetrieveFailureEvent(error, client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisControlInsightRetrieveFailure;
                this.addEventParameter("error", error);
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisControlInsightRetrieveFailureEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisControlEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisControlInsightRetrieveFailureEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisControlInsightRetrieveFailureEvent = NotesAnalysisControlInsightRetrieveFailureEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisControlInsightRetrieveSuccess = "NAControlInsightRetrieveSuccess";
        var NotesAnalysisControlInsightRetrieveSuccessEvent = (function () {
            function NotesAnalysisControlInsightRetrieveSuccessEvent(client, organizationId) {
                this.eventParameters = [];
                this.eventName = NotesAnalysisControlInsightRetrieveSuccess;
                this.addEventParameter("client", client);
                this.addEventParameter("organizationId", organizationId);
            }
            NotesAnalysisControlInsightRetrieveSuccessEvent.prototype.addEventParameter = function (name, value) {
                var event = new NotesAnalysisContainer.NotesAnalysisControlEventParameter(name, value);
                this.eventParameters.push(event);
            };
            return NotesAnalysisControlInsightRetrieveSuccessEvent;
        }());
        NotesAnalysisContainer.NotesAnalysisControlInsightRetrieveSuccessEvent = NotesAnalysisControlInsightRetrieveSuccessEvent;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../jsreferences/internal/TypeDefinitions/mscrm.d.ts" />
/// <reference path="../../../jsreferences/internal/TypeDefinitions/XrmClientApi.d.ts" />
/// <reference path="Typings/underscore.d.ts" />
/// <reference path="Typings/js-sha256.d.ts" />
/// <reference path="Typings/lscache.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="telemetry/NotesAnalysisControlEventParameter.ts" />
/// <reference path="telemetry/NotesAnalysisControlInsightRetrieveFailureEvent.ts" />
/// <reference path="telemetry/NotesAnalysisControlInsightRetrieveSuccessEvent.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        var Utility;
        (function (Utility) {
            'use strict';
            var NAConstants = (function () {
                function NAConstants() {
                }
                return NAConstants;
            }());
            NAConstants.annotationEntity = "annotation";
            NAConstants.postEntity = "post";
            NAConstants.activitypointerEntity = "activitypointer";
            NAConstants.emailEntity = "email";
            NAConstants.type = "@type";
            NAConstants.description = "description";
            //  public static name: string = "name";
            NAConstants.title = "title";
            NAConstants.scheduledTime = "scheduledTime";
            NAConstants.owner = "owner";
            NAConstants.scheduledTimeList = "scheduledTime/list";
            NAConstants.participantList = "participant/list";
            Utility.NAConstants = NAConstants;
        })(Utility = NotesAnalysisContainer.Utility || (NotesAnalysisContainer.Utility = {}));
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
/// <reference path="Utility/NAConstants.ts" />
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisRequest = (function () {
            function NotesAnalysisRequest() {
            }
            NotesAnalysisRequest.prototype.getMetadata = function () {
                var metadata = {
                    boundParameter: null,
                    operationName: "msdyn_GetNotesAnalysis",
                    operationType: 0,
                    parameterTypes: {
                        "NoteText": {
                            typeName: "Edm.String",
                            structuralProperty: 1 /* PrimitiveType */
                        }
                    }
                };
                return metadata;
            };
            return NotesAnalysisRequest;
        }());
        var NotesAnalysisControl = (function () {
            /**
             * Empty constructor.
             */
            function NotesAnalysisControl() {
                this.flexWidth = "0%";
                this.INSIGHT_FETCHED_EVENT = "InsightFetchedForText";
                /**
                 * The web resource information for web resource based chart, obtained from property bag
                 */
                this._webResourceState = null;
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The div element to draw this control in
             */
            NotesAnalysisControl.prototype.init = function (context, notifyOutputChanged, state) {
                // custom code goes here
                this.context = context;
                this.setOrganizationId();
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            NotesAnalysisControl.prototype.updateView = function (context) {
                var bodyDescriptionContent;
                // custom code goes here
                this.context = context;
                if (context.utils.isNullOrUndefined(this.organizationId)) {
                    this.setOrganizationId();
                }
                //const entityId = context.page.entityId;
                //this.context.utils.log("MscrmControls.NotesAnalysisContainer.NotesAnalysisControl", "Input received : " + this.context.parameters.TLInputText.raw, 2);
                //this.context.utils.log("MscrmControls.NotesAnalysisContainer.NotesAnalysisControl", "entityId received : " + entityId, 2);
                this.fetchNotes(this.context.parameters.TLInputText.raw);
                return this.context.factory.createElement("CONTAINER", {}, '');
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            NotesAnalysisControl.prototype.getOutputs = function () {
                // custom code goes here - remove the line below and return the correct output
                return null;
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            NotesAnalysisControl.prototype.destroy = function () {
            };
            NotesAnalysisControl.prototype.UpdateBodyText = function (notesAnalysisInsigths) {
                // Raise event along with the relative folder path of the clicked item for the parent to listen to.
                var eventParams = {};
                eventParams["insight"] = notesAnalysisInsigths;
                if (this.context.parameters) {
                    this.context.utils.fireEvent(this.INSIGHT_FETCHED_EVENT, eventParams);
                }
            };
            NotesAnalysisControl.prototype.fetchNotes = function (notesText) {
                var that = this;
                var textHash = sha256(notesText);
                lscache.setBucket(NotesAnalysisControl.hashKeyPrefix);
                if (lscache.get(textHash) != null) {
                    var cachedResp = lscache.get(textHash);
                    if (!_.isEmpty(cachedResp.NotesAnalysisResult) && !_.isEmpty(JSON.parse(cachedResp.NotesAnalysisResult))) {
                        this.UpdateBodyText(cachedResp.NotesAnalysisResult);
                    }
                    return;
                }
                var request = new NotesAnalysisRequest();
                request.NoteText = notesText;
                var start = performance.now();
                this.context.webAPI.execute(request).then(function (response) {
                    response.json().then(function (value) {
                        console.log("Call to fetchNotes took " + (performance.now() - start) + " milliseconds.");
                        console.log(value);
                        if (value.IsSuccess) {
                            var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisControlInsightRetrieveSuccessEvent(that.getClient(), that.getOrganizationId());
                            that.context.reporting.reportEvent(telemetryEvent);
                            if (!_.isEmpty(value.NotesAnalysisResult) && !_.isEmpty(JSON.parse(value.NotesAnalysisResult))) {
                                that.UpdateBodyText(value.NotesAnalysisResult);
                            }
                            if (!_.isEmpty(value.NotesAnalysisResult)) {
                                // Setting the json response in cache with expiry of one month
                                lscache.set(textHash, value, 60 * 24 * 30);
                            }
                        }
                        else {
                            var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisControlInsightRetrieveFailureEvent(value.NotesAnalysisResult, that.getClient(), that.getOrganizationId());
                            that.context.reporting.reportEvent(telemetryEvent);
                        }
                    });
                }, function (err) {
                    var telemetryEvent = new NotesAnalysisContainer.NotesAnalysisControlInsightRetrieveFailureEvent(err.message, that.getClient(), that.getOrganizationId());
                    that.context.reporting.reportEvent(telemetryEvent);
                    console.log("Failed fetchNotes took " + (performance.now() - start) + " milliseconds.");
                    console.log("fetchNotes failed: " + err);
                });
            };
            NotesAnalysisControl.prototype.setOrganizationId = function () {
                if (Xrm && Xrm.Utility) {
                    var globalContext = Xrm.Utility.getGlobalContext();
                    if (globalContext != null && globalContext.organizationSettings != null) {
                        this.organizationId = globalContext.organizationSettings.organizationId;
                    }
                }
                else {
                    var orgSettings = this.context.client.orgSettings;
                    if (!this.context.utils.isNullOrUndefined(orgSettings['organizationId'])) {
                        this.organizationId = orgSettings['organizationId'];
                    }
                    else if (!this.context.utils.isNullOrUndefined(orgSettings.attributes) && !this.context.utils.isNullOrUndefined(orgSettings.attributes['OrganizationId'])) {
                        this.organizationId = orgSettings['organizationId'];
                    }
                    else {
                        this.organizationId = null;
                    }
                }
                if (!this.context.utils.isNullOrUndefined(this.organizationId)) {
                    this.organizationId = this.organizationId.replace("{", "").replace("}", "");
                }
            };
            NotesAnalysisControl.prototype.getClient = function () {
                return this.context.client.getClient();
            };
            NotesAnalysisControl.prototype.getOrganizationId = function () {
                return this.context.orgSettings.organizationId;
            };
            return NotesAnalysisControl;
        }());
        NotesAnalysisControl.hashKeyPrefix = "msrina";
        NotesAnalysisContainer.NotesAnalysisControl = NotesAnalysisControl;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/// <reference path="privatereferences.ts" />
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var ResourceStrings = (function () {
            function ResourceStrings() {
            }
            return ResourceStrings;
        }());
        ResourceStrings._titleMeetingReqCard = "TitleMeetingReqCard";
        ResourceStrings._titleNewContactCard = "TitleNewContactCard";
        ResourceStrings._titleNewTaskCard = "TitleNewTaskCard";
        ResourceStrings._titlePhoneCallCard = "TitlePhoneCallCard";
        ResourceStrings._titleActivityCard = "TitleActivityCard";
        ResourceStrings._defaultDescMeeting = "DefaultMeetingDesc";
        ResourceStrings._defaultDescContact = "DefaultContactDesc";
        ResourceStrings._defaultDescTask = "DefaultTaskDesc";
        ResourceStrings._defaultDescPhoneCall = "DefaultPhoneCallDesc";
        ResourceStrings._defaultDescActivity = "DefaultActivityDesc";
        ResourceStrings._buttonCreate = "CreateButton";
        ResourceStrings._buttonEdit = "EditButton";
        ResourceStrings._errorLoadNAControl = "ErrorLoadNAControl";
        ResourceStrings._errorNoReadPrivilege = "ErrorNoReadPrivilege";
        ResourceStrings._errorNoCreatePrivilege = "ErrorNoCreatePrivilege";
        ResourceStrings._unableToRetrieveInsights = "UnableToRetrieveInsights";
        NotesAnalysisContainer.ResourceStrings = ResourceStrings;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="NotesAnalysisControl.ts" />
/// <reference path="ResourceStrings.ts" />
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NotesAnalysisModel = (function () {
            function NotesAnalysisModel() {
                this.postIds = [];
            }
            NotesAnalysisModel.prototype.addPost = function (postId) {
                this.postIds.push(postId);
            };
            NotesAnalysisModel.prototype.isPostPresent = function (postId) {
                for (var i = 0; i < this.postIds.length; i++) {
                    if (postId == this.postIds[i])
                        return true;
                }
                return false;
            };
            return NotesAnalysisModel;
        }());
        NotesAnalysisContainer.NotesAnalysisModel = NotesAnalysisModel;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
var MscrmControls;
(function (MscrmControls) {
    var NotesAnalysisContainer;
    (function (NotesAnalysisContainer) {
        'use strict';
        var NATelemetry = (function () {
            function NATelemetry() {
            }
            return NATelemetry;
        }());
        NotesAnalysisContainer.NATelemetry = NATelemetry;
    })(NotesAnalysisContainer = MscrmControls.NotesAnalysisContainer || (MscrmControls.NotesAnalysisContainer = {}));
})(MscrmControls || (MscrmControls = {}));
