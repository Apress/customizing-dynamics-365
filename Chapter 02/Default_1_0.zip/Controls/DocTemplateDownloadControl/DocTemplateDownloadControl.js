/**
 * This code was generated from a script.
 * Manual changes to this file will be overwritten if the code is regenerated.
 *
 * @license Copyright (c) Microsoft Corporation. All rights reserved.
 */
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../TypeDefinitions/mscrm.d.ts" />
/// <reference path="CommonReferences.ts" />
/// <reference path="../../../../../references/external/TypeDefinitions/jquery.d.ts" /> 
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DocTemplateDownload;
        (function (DocTemplateDownload) {
            'use strict';
            var DocTemplateDownloadControl = (function () {
                /**
                 * Empty constructor.
                 */
                function DocTemplateDownloadControl() {
                    var _this = this;
                    this.oneToManyData = [];
                    this.manyToOneData = [];
                    this.manyToManyData = [];
                    this._controlId = "cc_partylist_lookup1";
                    this._isViewDisabled = false;
                    this.callbackForStyleChanges = function () {
                        var that = _this;
                        $(".sol-selection li").css('padding-bottom', '0.625rem');
                        $(".sol-label").each(function (i, element) {
                            if (element.title != "") {
                                element.title = that._context.resources.getString("CustomControl_DocumentTemplate_EntityLabel") + ":" + element.title.replace('<br/>', " " + that._context.resources.getString("CustomControl_DocumentTemplate_SchemaNameLabel") + ":");
                            }
                        });
                        $(".sol-selection").last().css("max-height", "6rem");
                    };
                }
                /**
                 * This function should be used for any initial setup necessary for your control.
                 * @params context The "Input Bag" containing the parameters and other control metadata.
                 * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
                 * @params state The user state for this control set from setState in the last session
                 * @params container The div element to draw this control in
                 */
                DocTemplateDownloadControl.prototype.init = function (context, notifyOutputChanged, state) {
                    // custom code goes here
                    this._context = context;
                    this._entityNameMap = {};
                    this._entityName = context.parameters.entityname.raw;
                    this._viewId = context.parameters.viewid.raw;
                    var fileType = context.parameters.dialogtype.raw;
                    if (fileType === 1) {
                        this._dialogType = "EXCEL";
                    }
                    else {
                        this._dialogType = "WORD";
                    }
                    if (this._entityName === null || this._entityName === undefined) {
                        this._isViewDisabled = true;
                    }
                    var defaultViewOption = this._createSelectOption(this._context.resources.getString("CustomControl_DownloadTemplate_SelectViewLabel"), "", 0);
                    var defaultViewList = [defaultViewOption];
                    this._viewsProps = {
                        style: this.selectStyle(),
                        options: defaultViewList,
                        disabled: this._isViewDisabled,
                        onChange: this._onChangeViewHandler.bind(this),
                        value: defaultViewList[0]
                    };
                    this._oneToManyData = {
                        Usage: 3,
                        Static: false,
                        Type: "OptionSet",
                        Value: [],
                        Attributes: {
                            DefaultValue: { Label: "", text: "", Value: 0, Color: "" },
                            Options: [],
                            OptionSet: []
                        },
                        Callback: this._oneToManyChangeHandler.bind(this)
                    };
                    this._manyToOneData = {
                        Usage: 3,
                        Static: false,
                        Type: "OptionSet",
                        Value: [],
                        Attributes: {
                            DefaultValue: { Label: "", text: "", Value: 0, Color: "" },
                            Options: [],
                            OptionSet: []
                        },
                        Callback: this._manyToOneChangeHandler.bind(this)
                    };
                    this._manyToManyData = {
                        Usage: 3,
                        Static: false,
                        Type: "OptionSet",
                        Value: [],
                        Attributes: {
                            DefaultValue: { Label: "", text: "", Value: 0, Color: "" },
                            Options: [],
                            OptionSet: []
                        },
                        Callback: this._manyToManyChangeHandler.bind(this)
                    };
                    this._notifyOutputChanged = notifyOutputChanged || (function () { });
                    this.getEntities();
                    window.setTimeout(this.callbackForStyleChanges, 1000);
                    var docTemplateDownloadControlInitEvent = new DocTemplateDownload.DocTemplateDownloadControlInitEvent(this._entityName, this._dialogType);
                    Xrm.Reporting.reportEvent(docTemplateDownloadControlInitEvent);
                };
                DocTemplateDownloadControl.prototype.selectStyle = function () {
                    var _a = this._context.theming, noneborderstyle = _a.noneborderstyle, textbox = _a.textbox;
                    var backgroundColor = textbox.backgroundcolor;
                    var color = textbox.contentcolor;
                    var selectStyle = {
                        appearance: "normal",
                        width: "54%",
                        height: "2.5rem",
                        padding: "0.2em",
                        fontSize: textbox.fontsize,
                        fontWeight: textbox.fontweight,
                        boxShadow: "0 0 0 1px #cccccc inset",
                        backgroundColor: this._context.theming.colors.whitebackground,
                        color: color
                    };
                    var optionStyle = {
                        backgroundColor: backgroundColor,
                        color: color
                    };
                    return {
                        selectStyle: selectStyle,
                        optionStyle: optionStyle
                    };
                };
                DocTemplateDownloadControl.prototype.renderControl = function (render, callback) {
                    if (render === void 0) { render = false; }
                    if (render) {
                        this._context.utils.requestRender(callback);
                    }
                };
                DocTemplateDownloadControl.prototype._onChangeEnitityHandler = function (valueNew) {
                    var defaultValue = [
                        { value: "", text: "" }
                    ];
                    this._currentEntitySelected = valueNew;
                    this._isViewDisabled = false;
                    if (valueNew === null || valueNew === "undefined") {
                        return defaultValue;
                    }
                    this._entitiesProps.value = this._currentEntitySelected;
                    if (this._dialogType === "EXCEL") {
                        this._entityViewJsonData = null;
                        this._entityUserViewJsonData = null;
                        this._currentEntityViewSelected = "";
                        this.getEntityViews();
                    }
                    else if (this._dialogType === "WORD") {
                        this._oneToManyJsonData = null;
                        this._manyToManyJsonData = null;
                        this._manyToOneJsonData = null;
                        this._getOneToManyRelationshipData();
                    }
                    this.renderControl(true, this.callbackForStyleChanges);
                    this._notifyOutputChanged();
                };
                DocTemplateDownloadControl.prototype.createRelationShipControlRowView = function (Infolabel, relationshipLabel, relationship, relationshipData) {
                    var controlsList = [];
                    controlsList = controlsList.concat(this.createLabelContainers(this._context.resources.getString(Infolabel)));
                    controlsList = controlsList.concat(this.createRelationShipContainer(this._context.resources.getString(relationshipLabel), relationship, relationshipData, this._context.resources.getString(Infolabel)));
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingBottom: this._context.theming.measures.measure050,
                            display: "flex",
                            width: "100%",
                            justifyContent: "flex-start",
                            flexDirection: "column"
                        },
                        key: Infolabel,
                        id: Infolabel
                    }, controlsList);
                };
                DocTemplateDownloadControl.prototype.createEntitySelectorControl = function () {
                    // create the entitySelect combobox
                    var entitiesComboBox = this._context.factory.createElement("SELECT", this._entitiesProps, null);
                    var selectEntityLabel = this._context.factory.createElement("LABEL", {
                        style: {
                            color: this._context.theming.colors.grays.gray06,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            paddingBottom: this._context.theming.measures.measure025,
                            paddingTop: "0.25rem",
                            width: "30%",
                            marginLeft: "1rem",
                            alignSelf: "center"
                        }
                    }, this._context.resources.getString("CustomControl_DocumentTemplate_EntityLabel"));
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingBottom: this._context.theming.measures.measure050,
                            paddingLeft: this._context.theming.measures.measure125,
                            width: "100%",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: "entitySelectorContainer",
                        id: "entitySelectorContainer"
                    }, [selectEntityLabel, entitiesComboBox]);
                };
                DocTemplateDownloadControl.prototype.createViewSelectorControl = function () {
                    var viewselector = this._context.factory.createElement("SELECT", this._viewsProps);
                    var selectViewLabel = this._context.factory.createElement("LABEL", {
                        style: {
                            color: this._context.theming.colors.grays.gray06,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            paddingBottom: this._context.theming.measures.measure025,
                            paddingTop: "0.25rem",
                            width: "30%",
                            marginLeft: "1rem",
                            alignSelf: "center"
                        }
                    }, this._context.resources.getString("CustomControl_DocumentTemplate_ViewLabel"));
                    // return the container with the entitySelect combobox
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure125,
                            width: "100%",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: "viewSelectorContainer",
                        id: "viewSelectorContainer"
                    }, [selectViewLabel, viewselector]);
                };
                DocTemplateDownloadControl.prototype._oneToManyChangeHandler = function (value) {
                    console.log(value);
                    this.oneToManyData = value;
                    this.renderControl(false, this.callbackForStyleChanges);
                    this._notifyOutputChanged();
                };
                DocTemplateDownloadControl.prototype._manyToOneChangeHandler = function (value) {
                    console.log(value);
                    this.manyToOneData = value;
                    this.renderControl(false, this.callbackForStyleChanges);
                    this._notifyOutputChanged();
                };
                DocTemplateDownloadControl.prototype._manyToManyChangeHandler = function (value) {
                    console.log(value);
                    this.manyToManyData = value;
                    this.renderControl(false, this.callbackForStyleChanges);
                    this._notifyOutputChanged();
                };
                DocTemplateDownloadControl.prototype.createHeaderLabelContainers = function (label) {
                    // Create a Label Container and Return them
                    var labeltext = this._context.factory.createElement("LABEL", {
                        style: {
                            color: this._context.theming.colors.grays.gray06,
                            fontSize: "1rem",
                            paddingBottom: this._context.theming.measures.measure075,
                            whiteSpace: "normal"
                        }
                    }, label);
                    // return the container with the entitySelect combobox
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            width: "100%",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: label,
                        id: label
                    }, [labeltext]);
                };
                DocTemplateDownloadControl.prototype.createLabelContainers = function (label) {
                    // Create a Label Container and Return them
                    var labeltext = this._context.factory.createElement("LABEL", {
                        style: {
                            color: this._context.theming.colors.grays.gray06,
                            fontSize: this._context.theming.fontsizes.font100,
                            paddingBottom: this._context.theming.measures.measure025,
                            width: "94%",
                            whiteSpace: "normal"
                        }
                    }, label);
                    // return the container with the entitySelect combobox
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure125,
                            width: "100%",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: label,
                        id: label
                    }, [labeltext]);
                };
                DocTemplateDownloadControl.prototype.createRelationShipContainer = function (label, key, value, Infolabel) {
                    //const mapToOptionalAttributeComboBox = this.buildMultiPartyLookupControl(this._context, this.onSelectionChanged.bind(this));
                    var mapToOptionalAttributeComboBox = this._context.factory.createComponent("MscrmControls.MultiSelectPicklist.MultiSelectPicklistControl", key, {
                        parameters: { value: value }
                    });
                    var comboBoxContainer = this._context.factory.createElement("CONTAINER", {
                        style: {
                            width: "54%"
                        },
                        key: key + "wrapper",
                        id: key + "wrapper"
                    }, mapToOptionalAttributeComboBox);
                    var selectRelationShipLabel = this._context.factory.createElement("LABEL", {
                        style: {
                            color: this._context.theming.colors.grays.gray06,
                            fontSize: this._context.theming.fontsizes.font100,
                            fontFamily: this._context.theming.fontfamilies.semibold,
                            paddingBottom: this._context.theming.measures.measure025,
                            width: "30%",
                            marginLeft: "1rem",
                            alignSelf: "center",
                            whiteSpace: "normal"
                        }
                    }, label);
                    // return the container with the entitySelect combobox
                    return this._context.factory.createElement("CONTAINER", {
                        accessibilityLabel: label + Infolabel,
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure125,
                            width: "100%",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: key,
                        id: key
                    }, [selectRelationShipLabel, comboBoxContainer]);
                };
                DocTemplateDownloadControl.prototype.createEmptyContainer = function () {
                    // return the container with the entitySelect combobox
                    return this._context.factory.createElement("CONTAINER", {
                        style: {
                            paddingTop: this._context.theming.measures.measure075,
                            paddingLeft: this._context.theming.measures.measure125,
                            width: "100%",
                            height: "8rem",
                            display: "flex",
                            flexDirection: "row"
                        },
                        key: "EmptyContainer",
                        id: "EmptyContainer"
                    });
                };
                DocTemplateDownloadControl.prototype.buildMultiPartyLookupControl = function (context, callback) {
                    var returnValue = this.getValueParameter(callback);
                    var componentValue = context.factory.createComponent("MscrmControls.FieldControls.SimpleLookupControl", this._controlId, {
                        controlstates: {
                            hasFocus: context.mode.hasFocus,
                            isControlDisabled: false
                        },
                        descriptor: {
                            Id: "relationshipcontainer",
                            Label: "relationshipcontainerlabel",
                            Name: "relationshipcontainerName",
                            ShowLabel: false,
                            Visible: true,
                            Disabled: false
                        },
                        configuration: {
                            FormFactor: 3 /* Desktop */,
                            CustomControlId: "MscrmControls.FieldControls.SimpleLookupControl",
                            Name: "relationship-Config",
                            Version: "1.0.0",
                            Parameters: {
                                value: returnValue
                            }
                        }
                    });
                    return componentValue;
                };
                DocTemplateDownloadControl.prototype.getValueParameter = function (callback) {
                    //let options = [{ "_etn": "contact", "_id": "ffb49b44-55f4-e711-812e-000d3a719d2f", "_name": "User N" }, { "_etn": "lead", "_id": "7cae8d2d-29f4-e711-812e-000d3a719d2f", "_name": "Nancy Anderson (sample)" }, { "_etn": "account", "_id": "5cad8d2d-29f4-e711-812e-000d3a719d2f", "_name": "Adventure Works (sample)" }];
                    var options = ["testuser", "testuser2"];
                    return {
                        Usage: 3,
                        Static: false,
                        Value: this.selectedRecords,
                        Type: "Lookup.PartyList",
                        Attributes: {
                            Targets: options,
                        },
                        Callback: callback,
                    };
                };
                DocTemplateDownloadControl.prototype.onSelectionChanged = function (e) {
                    if (e && e.length > 0) {
                        this.selectedRecords = e.slice();
                        console.log(e.slice);
                        this._notifyOutputChanged();
                    }
                    else {
                        console.log("Unexpected value recieved: " + e);
                    }
                };
                DocTemplateDownloadControl.prototype._getOneToManyRelationshipData = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    if ((this._oneToManyJsonData == null || this._oneToManyJsonData == undefined) || (this._oneToManyJsonData != null && this._oneToManyJsonData.value == null)) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v9.0/EntityDefinitions(LogicalName='" + this._currentEntitySelected.text.LogicalName + "')/OneToManyRelationships?$select=ReferencingEntity,SchemaName").done(function (data) {
                            that._getManyToOneRelationshipData();
                            that._oneToManyJsonData = data;
                            var multiOptions = that._createRelationshipOptions(that._oneToManyJsonData, "1:N");
                            that._oneToManyData = {
                                Usage: 3,
                                Static: false,
                                Type: "OptionSet",
                                Value: [],
                                Attributes: {
                                    DefaultValue: multiOptions[0],
                                    Options: multiOptions,
                                    OptionSet: multiOptions
                                },
                                Callback: that._oneToManyChangeHandler.bind(that)
                            };
                        }).fail(function (error) {
                            var ERROR_ONETOMANYLOGICALNAME = this._context.resources.getString("CustomControl_ImportMapping_Error_Onetomany_NotFound");
                            var suggestedMitigationForOneToMany = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_OneToMany_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl._getOneToManyRelationshipData", Error(ERROR_ONETOMANYLOGICALNAME), suggestedMitigationForOneToMany, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl._getOneToManyRelationshipData" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype._getManyToOneRelationshipData = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    if ((this._manyToOneJsonData == null || this._manyToOneJsonData == undefined) || (this._manyToOneJsonData != null && this._manyToOneJsonData.value == null)) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v9.0/EntityDefinitions(LogicalName= '" + this._currentEntitySelected.text.LogicalName + "')/ManyToOneRelationships?$select=ReferencedEntity,SchemaName").done(function (data) {
                            that._getManyToManyRelationshipData();
                            that._manyToOneJsonData = data;
                            var multiOptions = that._createRelationshipOptions(that._manyToOneJsonData, "N:1");
                            that._manyToOneData = {
                                Usage: 3,
                                Static: false,
                                Type: "OptionSet",
                                Value: [],
                                Attributes: {
                                    DefaultValue: multiOptions[0],
                                    Options: multiOptions,
                                    OptionSet: multiOptions
                                },
                                Callback: that._manyToOneChangeHandler.bind(that)
                            };
                        }).fail(function (error) {
                            var ERROR_MANYTOONELOGICALNAME = this._context.resources.getString("CustomControl_ImportMapping_Error_Manytoone_NotFound");
                            var suggestedMitigationForManyToOne = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_ManyToOne_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl._getManyToOneRelationshipData", Error(ERROR_MANYTOONELOGICALNAME), suggestedMitigationForManyToOne, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl._getManyToOneRelationshipData" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype._getManyToManyRelationshipData = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    if ((this._manyToManyJsonData == null || this._manyToManyJsonData == undefined) || (this._manyToManyJsonData != null && this._manyToManyJsonData.value == null)) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v9.0/EntityDefinitions(LogicalName = '" + this._currentEntitySelected.text.LogicalName + "')/ManyToManyRelationships?$select=Entity1LogicalName,Entity2LogicalName,SchemaName").done(function (data) {
                            that._manyToManyJsonData = data;
                            var multiOptions = that._createRelationshipOptions(that._manyToManyJsonData, "N:N");
                            that._manyToManyData = {
                                Usage: 3,
                                Static: false,
                                Type: "OptionSet",
                                Value: [],
                                Attributes: {
                                    DefaultValue: multiOptions[0],
                                    Options: multiOptions,
                                    OptionSet: multiOptions
                                },
                                Callback: that._manyToManyChangeHandler.bind(that)
                            };
                            that.renderControl(true, this.callbackForStyleChanges);
                            $("div[data-id='DocumentTemplateDownload']").css("height", "auto");
                        }).fail(function (error) {
                            var ERROR_MANYTOMANYLOGICALNAME = this._context.resources.getString("CustomControl_ImportMapping_Error_Manytomany_NotFound");
                            var suggestedMitigationForManyToMany = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_ManyToMany_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl._getManyToManyRelationshipData", Error(ERROR_MANYTOMANYLOGICALNAME), suggestedMitigationForManyToMany, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl._getManyToManyRelationshipData" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype.createExportSection = function () {
                    // Return the container with the Export Type Selector, Entity Combobox, View Combobox and Export Button
                    var controls = [];
                    //Populate Header for Excel/Word Dialog
                    if (this._dialogType === "WORD") {
                        controls.push(this.createHeaderLabelContainers(this._context.resources.getString("CustomControl_DownloadWordTemplate_Header")));
                    }
                    else {
                        controls.push(this.createHeaderLabelContainers(this._context.resources.getString("CustomControl_DownloadExcelTemplate_Header")));
                    }
                    // Populate the Entity Select Control
                    controls.push(this.createEntitySelectorControl());
                    //If word Populate the Relationship Control
                    if (this._dialogType === "WORD") {
                        controls.push(this.createRelationShipControlRowView("CustomControl_DownloadTemplate_1NRelationshipHeader", "CustomControl_DocumentTemplate_1toNRelationshipLabel", "1_N_relationship", this._oneToManyData));
                        controls.push(this.createRelationShipControlRowView("CustomControl_DownloadTemplate_N1RelationshipHeader", "CustomControl_DocumentTemplate_Nto1RelationshipLabel", "N_1_relationship", this._manyToOneData));
                        controls.push(this.createRelationShipControlRowView("CustomControl_DownloadTemplate_NNRelationshipHeader", "CustomControl_DocumentTemplate_NtoNRelationshipLabel", "N_N_relationship", this._manyToManyData));
                        // Push all these Control to Main Controls
                        controls.push(this.createEmptyContainer());
                    }
                    else if (this._dialogType === "EXCEL") {
                        //Populate the Excel View Selector Otherwise
                        controls = controls.concat([this.createViewSelectorControl()]);
                    }
                    return this._context.factory.createElement("CONTAINER", {
                        key: "main_Container",
                        id: "main_Container",
                        style: {
                            display: "flex",
                            flexDirection: "column"
                        }
                    }, controls);
                };
                /**
                 * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
                 * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
                 * as well as resource, client, and theming info (see mscrm.d.ts)
                 * @params context The "Input Bag" as described above
                 */
                DocTemplateDownloadControl.prototype.updateView = function (context) {
                    // custom code goes here
                    return context.factory.createElement("CONTAINER", {
                        style: {
                            display: "flex",
                            flexDirection: "column",
                            width: "100%"
                        }
                    }, [this.createExportSection()]);
                };
                DocTemplateDownloadControl.prototype.getEntities = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined) || (this._entitiesJsonData != null && this._entitiesJsonData.value == null)) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v8.0/EntityDefinitions?$select=LogicalName,DisplayName,IsImportable,IsBPFEntity,ObjectTypeCode").done(function (data) {
                            that._entitiesJsonData = data;
                            that._entitiesProps = {
                                key: 'download_template_entity_combobox_container',
                                id: "download_template_entity-combobox",
                                labelledByElementId: "download template entity combobox",
                                describedByElementId: "download template entity combo description",
                                title: "Select entities",
                                onChange: that._onChangeEnitityHandler.bind(that),
                                disabled: false,
                                autoFocus: true,
                                options: that._createEntitiesList(),
                                value: that._currentEntitySelected,
                                style: that.selectStyle(),
                                accessibilityLabel: that._context.resources.getString("CustomControl_DocumentTemplate_EntityLabel")
                            };
                        }).fail(function (error) {
                            var ERROR_ENTITYLOGICALNAME = this._context.resources.getString("CustomControl_ImportMapping_Error_Entity_NotFound");
                            var suggestedMitigation = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_Entity_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl.getEntities", Error(ERROR_ENTITYLOGICALNAME), suggestedMitigation, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl.getEntities" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype._createRelationshipOptions = function (data, relation) {
                    var i;
                    var options = [];
                    for (i = 0; i < data.value.length; i++) {
                        var label = void 0;
                        switch (relation) {
                            case "1:N":
                                if (this._entityNameMap[data.value[i].ReferencingEntity] === undefined) {
                                    label = data.value[i].ReferencingEntity + "<br/>" + data.value[i].SchemaName;
                                }
                                else {
                                    label = this._entityNameMap[data.value[i].ReferencingEntity] + "<br/>" + data.value[i].SchemaName;
                                }
                                break;
                            case "N:1":
                                if (this._entityNameMap[data.value[i].ReferencedEntity] === undefined) {
                                    label = data.value[i].ReferencingEntity + "<br/>" + data.value[i].SchemaName;
                                }
                                else {
                                    label = this._entityNameMap[data.value[i].ReferencedEntity] + "<br/>" + data.value[i].SchemaName;
                                }
                                break;
                            case "N:N":
                                if (this._currentEntitySelected.text.LogicalName === data.value[i].Entity1LogicalName) {
                                    if (this._entityNameMap[data.value[i].Entity2LogicalName] === undefined) {
                                        label = data.value[i].Entity2LogicalName + "<br/>" + data.value[i].SchemaName;
                                    }
                                    else {
                                        label = this._entityNameMap[data.value[i].Entity2LogicalName] + "<br/>" + data.value[i].SchemaName;
                                    }
                                }
                                else {
                                    if (this._entityNameMap[data.value[i].Entity1LogicalName] === undefined) {
                                        label = data.value[i].Entity1LogicalName + "<br/>" + data.value[i].SchemaName;
                                    }
                                    else {
                                        label = this._entityNameMap[data.value[i].Entity1LogicalName] + "<br/>" + data.value[i].SchemaName;
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                        options = options.concat(this._createSelectOption(label, label, data.value[i].SchemaName));
                    }
                    return options.sort(compare);
                };
                DocTemplateDownloadControl.prototype._createEntitiesList = function () {
                    var defaultValue = [];
                    defaultValue = defaultValue.concat(this._createSelectOption(this._context.resources.getString("CustomControl_DownloadTemplate_SelectEntityLabel"), "", 0));
                    if ((this._entitiesJsonData == null || this._entitiesJsonData == undefined) || (this._entitiesJsonData != null && this._entitiesJsonData.value == null)) {
                        return defaultValue;
                    }
                    var i;
                    var entitiesOptions = [];
                    for (i = 0; i < this._entitiesJsonData.value.length; i++) {
                        var isImportable = this._entitiesJsonData.value[i].IsImportable;
                        var isBPFEntity = this._entitiesJsonData.value[i].IsBPFEntity;
                        if (this._entitiesJsonData.value[i].DisplayName.UserLocalizedLabel)
                            this._entityNameMap[this._entitiesJsonData.value[i].LogicalName] = this._entitiesJsonData.value[i].DisplayName.UserLocalizedLabel.Label;
                        //If it is not a BPF entity and the entity is importable then only add it to the list
                        if (isImportable && !isBPFEntity) {
                            var option = this._createSelectOption(this._entitiesJsonData.value[i].DisplayName.UserLocalizedLabel.Label, this._entitiesJsonData.value[i], i + 1);
                            if (this._entityName && this._entityName == this._entitiesJsonData.value[i].LogicalName) {
                                this._currentEntitySelected = option;
                                this._notifyOutputChanged();
                            }
                            entitiesOptions = entitiesOptions.concat(option);
                        }
                    }
                    entitiesOptions.sort(compare);
                    if (this._currentEntitySelected === null || this._currentEntitySelected === undefined) {
                        this._currentEntitySelected = defaultValue[0];
                    }
                    else {
                        (this._dialogType == 'EXCEL') ? this.getEntityViews() : this._getOneToManyRelationshipData();
                    }
                    return defaultValue.concat(entitiesOptions);
                };
                /**
                * Creates an option for the given value for entity population.
                */
                DocTemplateDownloadControl.prototype._createSelectOption = function (label, text, value) {
                    return { text: text, Label: label, Value: value, Color: "" };
                };
                /**
                 * Gets the list of the entity view names.
                */
                DocTemplateDownloadControl.prototype.getEntityViews = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    //Get System Views
                    if ((((this._entityViewJsonData == null || this._entityViewJsonData == undefined) || (this._entityViewJsonData != null && this._entityViewJsonData.value == null))) && !(this._currentEntitySelected.text === null || this._currentEntitySelected.text === " " || this._currentEntitySelected.text === "undefined")) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v8.0/savedqueries?$select=name,savedqueryid,fetchxml,layoutxml&$filter=returnedtypecode%20eq%20%27" + this._currentEntitySelected.text.LogicalName + "%27%20and%20querytype%20eq%200%20").done(function (data) {
                            that._entityViewJsonData = data;
                            that.getUserViews();
                        }).fail(function (error) {
                            var ERROR_ENTITYVIEWLOGICALNAME = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Error_Entity_View_NotFound");
                            var suggestedMitigationForEntityViews = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_EntityView_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl.getEntityViews", Error(ERROR_ENTITYVIEWLOGICALNAME), suggestedMitigationForEntityViews, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl.getEntityViews" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype.getUserViews = function () {
                    var that = this;
                    $.ajaxSetup({
                        async: false
                    });
                    //Get User Views
                    if ((((this._entityUserViewJsonData == null || this._entityUserViewJsonData == undefined) || (this._entityUserViewJsonData != null && this._entityUserViewJsonData.value == null))) && !(this._currentEntitySelected.text === null || this._currentEntitySelected.text === " " || this._currentEntitySelected.text === "undefined")) {
                        var ajaxCall = $.getJSON("../" + this._context.utils.createCrmUri("") + "/api/data/v8.0/userqueries?$select=name,userqueryid,fetchxml,layoutxml&$filter=returnedtypecode%20eq%20%27" + this._currentEntitySelected.text.LogicalName + "%27%20and%20querytype%20eq%200").done(function (data) {
                            that._entityUserViewJsonData = data;
                            that._viewsProps = {
                                key: 'download_template_view_combobox_container',
                                id: "download_template_view_combobox",
                                labelledByElementId: "download template view combobox",
                                describedByElementId: "download template view combo description",
                                title: "Select Views",
                                onChange: that._onChangeViewHandler.bind(that),
                                disabled: that._isViewDisabled,
                                autoFocus: true,
                                options: that._createViewList(),
                                value: that._currentEntityViewSelected,
                                style: that.selectStyle(),
                                accessibilityLabel: that._context.resources.getString("CustomControl_DocumentTemplate_ViewLabel")
                            };
                        }).fail(function (error) {
                            var ERROR_USERVIEWLOGICALNAME = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Error_User_View_NotFound");
                            var suggestedMitigationForEntityViews = this._context.resources.getString("CustomControl_DownloadExcelTemplate_Suggestion_UserView_NotFound");
                            that._context.reporting.reportFailure("MscrmControls.AppCommon.DocTemplateDownload.DocTemplateDownloadControl.getUserViews", Error(ERROR_USERVIEWLOGICALNAME), this.suggestedMitigation, [
                                { name: "FunctionName", value: "DocTemplateDownloadControl.getUserViews" },
                                { name: "Error", value: error.responseText },
                                { name: "EntityLogicalName", value: "DocumentTemplate" },
                                { name: "docType", value: this._dialogType }
                            ]);
                        });
                    }
                };
                DocTemplateDownloadControl.prototype._onChangeViewHandler = function (valueNew) {
                    var defaultValue = [
                        { value: "", text: "" }
                    ];
                    this._currentEntityViewSelected = valueNew;
                    if (valueNew === null || valueNew === "undefined") {
                        return defaultValue;
                    }
                    this._viewsProps.value = this._currentEntityViewSelected;
                    this.renderControl(true, this.callbackForStyleChanges);
                    this._notifyOutputChanged();
                };
                /**
             * Forms an array of the Combobox options.
             * @returns The virtual component array of options
             */
                DocTemplateDownloadControl.prototype._createViewList = function () {
                    var defaultSystemViewValue = [];
                    var defaultSystemViewValue = defaultSystemViewValue.concat(this._createSelectOption(this._context.resources.getString("CustomControl_DownloadTemplate_SelectViewLabel"), "", 0));
                    if ((this._entityViewJsonData == null || this._entityViewJsonData == undefined) || (this._entityViewJsonData != null && this._entityViewJsonData.value == null)) {
                        return defaultSystemViewValue;
                    }
                    var i;
                    var entityViewOptions = [];
                    for (i = 0; i < this._entityViewJsonData.value.length; i++) {
                        if (this._entityViewJsonData.value[i].fetchxml === null || this._entityViewJsonData.value[i].fetchxml === undefined || this._entityViewJsonData.value[i].fetchxml === " ")
                            continue;
                        var option = this._createSelectOption(this._entityViewJsonData.value[i].name, this._entityViewJsonData.value[i], this._entityViewJsonData.value[i].savedqueryid);
                        if (this._viewId && this._viewId.toLowerCase() == this._entityViewJsonData.value[i].savedqueryid) {
                            this._currentEntityViewSelected = option;
                            this._notifyOutputChanged();
                        }
                        entityViewOptions = entityViewOptions.concat(option);
                    }
                    entityViewOptions.sort();
                    //Get the list of user views
                    defaultSystemViewValue = defaultSystemViewValue.concat(entityViewOptions);
                    if ((this._entityUserViewJsonData == null || this._entityUserViewJsonData == undefined) || (this._entityUserViewJsonData != null && this._entityUserViewJsonData.value == null)) {
                        return defaultSystemViewValue;
                    }
                    var entityUserViewOptions = [];
                    for (i = 0; i < this._entityUserViewJsonData.value.length; i++) {
                        if (this._entityUserViewJsonData.value[i].fetchxml === null || this._entityUserViewJsonData.value[i].fetchxml === undefined || this._entityUserViewJsonData.value[i].fetchxml === " ")
                            continue;
                        var option = this._createSelectOption(this._entityUserViewJsonData.value[i].name, this._entityUserViewJsonData.value[i], this._entityUserViewJsonData.value[i].userqueryid);
                        if (this._viewId && this._viewId.toLowerCase() == this._entityUserViewJsonData.value[i].userqueryid) {
                            this._currentEntityViewSelected = option;
                            this._notifyOutputChanged();
                        }
                        entityUserViewOptions = entityUserViewOptions.concat(option);
                    }
                    entityUserViewOptions.sort();
                    return defaultSystemViewValue.concat(entityUserViewOptions);
                };
                /**
                 * This function will return an "Output Bag" to the Crm Infrastructure
                 * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
                 * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
                 * {
                 *		value: myvalue
                 * };
                 * @returns The "Output Bag" containing values to pass to the infrastructure
                 */
                DocTemplateDownloadControl.prototype.getOutputs = function () {
                    var output = {};
                    if (this._dialogType === "EXCEL") {
                        output['fileType'] = 1;
                        output['entityDisplayname'] = this._currentEntitySelected.Label;
                        output['fetchXML'] = (this._currentEntityViewSelected.text) ? this._currentEntityViewSelected.text.fetchxml : null;
                        output['layoutXML'] = (this._currentEntityViewSelected.text) ? this._currentEntityViewSelected.text.layoutxml : null;
                    }
                    else {
                        output['fileType'] = 0;
                        output['entityTypeCode'] = this._currentEntitySelected.text.ObjectTypeCode;
                        output['entityDisplayname'] = this._currentEntitySelected.Label;
                        output['selectedEntities'] = {};
                        output['selectedEntities']['oneToMany'] = this.oneToManyData;
                        output['selectedEntities']['manyToOne'] = this.manyToOneData;
                        output['selectedEntities']['manyToMany'] = this.manyToManyData;
                    }
                    var data = JSON.stringify(output);
                    this._context.parameters.file_data.raw = data;
                    console.log(this._context.parameters.file_data);
                    var result = {
                        "file_data": data
                    };
                    return result;
                };
                /**
                 * This function will be called when the control is destroyed
                 * It should be used for cleanup and releasing any memory the control is using
                 */
                DocTemplateDownloadControl.prototype.destroy = function () {
                };
                return DocTemplateDownloadControl;
            }());
            DocTemplateDownload.DocTemplateDownloadControl = DocTemplateDownloadControl;
            function compare(a, b) {
                var labelA = a.Label.toUpperCase();
                var labelB = b.Label.toUpperCase();
                var comparison = 0;
                if (labelA > labelB) {
                    comparison = 1;
                }
                else if (labelA < labelB) {
                    comparison = -1;
                }
                return comparison;
            }
            DocTemplateDownload.compare = compare;
        })(DocTemplateDownload = AppCommon.DocTemplateDownload || (AppCommon.DocTemplateDownload = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="inputsoutputs.g.ts" />
/// <reference path="DocTemplateDownloadControl.ts" /> 
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DocTemplateDownload;
        (function (DocTemplateDownload) {
            'use strict';
            var Sytle = (function () {
                function Sytle() {
                    this.main_container = {
                        "font-family": "'Segoe UI Regular', 'SegoeUI', 'Segoe UI'",
                        "display": "flex",
                        "flexDirection": "column"
                    };
                    this.entity_label = {};
                    this.entity_combo = {};
                }
                return Sytle;
            }());
            DocTemplateDownload.Sytle = Sytle;
        })(DocTemplateDownload = AppCommon.DocTemplateDownload || (AppCommon.DocTemplateDownload = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
/// <reference path="../../../../../TypeDefinitions/mscrm.d.ts" />
var MscrmControls;
(function (MscrmControls) {
    var AppCommon;
    (function (AppCommon) {
        var DocTemplateDownload;
        (function (DocTemplateDownload) {
            'use strict';
            /**
            * The name of this event which will be reported to Telemetry pipeline
            */
            var DocTemplateDownloadControlInit = "DocTemplateDownloadControlInit";
            var DocTemplateDownloadControlInitEvent = (function () {
                function DocTemplateDownloadControlInitEvent(entityName, fileType) {
                    this.eventName = DocTemplateDownloadControlInit;
                    this.eventParameters = [
                        { name: "entityName", value: entityName },
                        { name: "fileType", value: fileType },
                    ];
                }
                return DocTemplateDownloadControlInitEvent;
            }());
            DocTemplateDownload.DocTemplateDownloadControlInitEvent = DocTemplateDownloadControlInitEvent;
        })(DocTemplateDownload = AppCommon.DocTemplateDownload || (AppCommon.DocTemplateDownload = {}));
    })(AppCommon = MscrmControls.AppCommon || (MscrmControls.AppCommon = {}));
})(MscrmControls || (MscrmControls = {}));
//# sourceMappingURL=DocTemplateDownloadControl.js.map