/**
* @license Copyright (c) Microsoft Corporation.  All rights reserved.
*/
///// <reference path="privatereferences.ts"/>
var MscrmControls;
(function (MscrmControls) {
    var RadioOption;
    (function (RadioOption) {
        var RadioOptionControl = (function () {
            /**
             * Empty constructor.
             */
            function RadioOptionControl() {
            }
            /**
             * This function should be used for any initial setup necessary for your control.
             * @params context The "Input Bag" containing the parameters and other control metadata.
             * @params notifyOutputchanged The method for this control to notify the framework that it has new outputs
             * @params state The user state for this control set from setState in the last session
             * @params container The container for the element
             */
            RadioOptionControl.prototype.init = function (context, notifyOutputChanged, state, container) {
                this.inputData = this.getInputData(context);
                if (!(this.inputData && this.inputData.controlOptionValue && this.inputData.controlOptionLabel && this.inputData.controlOptionGroup)) {
                    throw "Invalid input parameters";
                }
                this.applyContainerStyling(container);
                var radioButton = this.createRadioButton(this.inputData, this.onOptionClicked.bind(this));
                var radioButtonLabel = this.createRadioButtonLabel(this.inputData);
                container.appendChild(radioButton);
                container.appendChild(radioButtonLabel);
                this.container = container;
                this.context = context;
                this.notifyOutputChanged = notifyOutputChanged;
            };
            RadioOptionControl.prototype.getInputData = function (context) {
                var inputData = {};
                if (context) {
                    var dynamicParameter = context.parameters;
                    if (dynamicParameter) {
                        var outputParameterValue = dynamicParameter.outputParameter;
                        if (outputParameterValue) {
                            var attributes = outputParameterValue.attributes;
                            if (attributes) {
                                inputData.controlOptionGroup = attributes.LogicalName;
                            }
                        }
                        var parameterValue = dynamicParameter.value;
                        if (parameterValue) {
                            var controlAttributes = parameterValue.attributes;
                            if (controlAttributes) {
                                var options = controlAttributes.Options;
                                var optionValue = controlAttributes.DefaultValue;
                                if (options && optionValue) {
                                    var matchingOptions = options.filter(function (option) { return option.Value === optionValue; });
                                    if (matchingOptions.length > 0) {
                                        inputData.controlOptionLabel = matchingOptions[0].Label;
                                        inputData.controlOptionValue = optionValue;
                                    }
                                }
                            }
                        }
                    }
                }
                return inputData;
            };
            RadioOptionControl.prototype.createRadioButton = function (inputData, onClick) {
                var radioButton = document.createElement("input");
                radioButton.id = this.getRadioButtonId(inputData.controlOptionGroup, inputData.controlOptionValue);
                radioButton.name = inputData.controlOptionGroup;
                radioButton.type = "radio";
                radioButton.style.margin = "0";
                radioButton.style.flexShrink = "0";
                radioButton.style.flexGrow = "0";
                radioButton.onclick = onClick;
                radioButton.setAttribute("class", "radio");
                return radioButton;
            };
            RadioOptionControl.prototype.createRadioButtonLabel = function (inputData) {
                var radioButtonLabel = document.createElement("label");
                radioButtonLabel.setAttribute("for", this.getRadioButtonId(inputData.controlOptionGroup, inputData.controlOptionValue));
                radioButtonLabel.style.color = RadioOptionControl.RadioLabelColor;
                radioButtonLabel.style.fontWeight = "bold";
                radioButtonLabel.style.paddingLeft = "5px";
                radioButtonLabel.style.whiteSpace = "normal";
                radioButtonLabel.innerHTML = inputData.controlOptionLabel;
                return radioButtonLabel;
            };
            RadioOptionControl.prototype.applyContainerStyling = function (customControl) {
                if (customControl) {
                    customControl.style.visibility = "visible";
                    customControl.style.display = "flex";
                    customControl.style.alignItems = "center";
                    var rootElement = this.getParentElement(customControl, RadioOptionControl.RootElementNodeDistance);
                    var inlineValueElement = this.getChildElement(rootElement, RadioOptionControl.InlineValueClass);
                    if (inlineValueElement) {
                        inlineValueElement.style.width = "100%";
                        inlineValueElement.style.visibility = "hidden";
                        var inlineValueParent = inlineValueElement.parentElement;
                        if (inlineValueParent) {
                            inlineValueParent.style.marginLeft = "-30px";
                            inlineValueParent.style.marginTop = "0px";
                            inlineValueParent.style.marginBottom = "0px";
                        }
                    }
                }
            };
            RadioOptionControl.prototype.applyInteractionStyling = function (context, customControl) {
                var rootElement = this.getParentElement(customControl, RadioOptionControl.RootElementNodeDistance);
                if (rootElement) {
                    var isDisabled = context.mode.isControlDisabled;
                    if (isDisabled) {
                        var lockIcon = this.getChildElement(rootElement, RadioOptionControl.InlineLockIconClass);
                        if (lockIcon) {
                            lockIcon.style.visibility = "hidden";
                        }
                    }
                    var input = customControl.getElementsByTagName("input");
                    if (input && input.length > 0) {
                        input[0].disabled = isDisabled;
                    }
                }
            };
            RadioOptionControl.prototype.clickRadioButtonIfDefaultOption = function (context, customControl) {
                if (context && customControl) {
                    var dynamicParameter = context.parameters;
                    if (dynamicParameter) {
                        var parameterValue = dynamicParameter.outputParameter;
                        if (parameterValue && !parameterValue.raw) {
                            var outputParameterValue = this.getBoundParameterValue(this.inputData.controlOptionGroup);
                            if (outputParameterValue && outputParameterValue === this.inputData.controlOptionValue) {
                                var rootElement = this.getParentElement(customControl, RadioOptionControl.RootElementNodeDistance);
                                if (rootElement) {
                                    var input = customControl.getElementsByTagName("input");
                                    if (input && input.length > 0) {
                                        input[0].click();
                                    }
                                }
                            }
                        }
                    }
                }
            };
            /**
             * This function will recieve an "Input Bag" containing the values currently assigned to the parameters in your manifest
             * It will send down the latest values (static or dynamic) that are assigned as defined by the manifest & customization experience
             * as well as resource, client, and theming info (see mscrm.d.ts)
             * @params context The "Input Bag" as described above
             */
            RadioOptionControl.prototype.updateView = function (context) {
                this.applyInteractionStyling(this.context, this.container);
                this.clickRadioButtonIfDefaultOption(this.context, this.container);
            };
            /**
             * This function will return an "Output Bag" to the Crm Infrastructure
             * The ouputs will contain a value for each property marked as "input-output"/"bound" in your manifest
             * i.e. if your manifest has a property "value" that is an "input-output", and you want to set that to the local variable "myvalue" you should return:
             * {
             *		value: myvalue
             * };
             * @returns The "Output Bag" containing values to pass to the infrastructure
             */
            RadioOptionControl.prototype.getOutputs = function () {
                return {
                    value: this.inputData.controlOptionValue,
                    outputParameter: this.inputData.controlOptionValue
                };
            };
            /**
             * This function will be called when the control is destroyed
             * It should be used for cleanup and releasing any memory the control is using
             */
            RadioOptionControl.prototype.destroy = function () {
                this.container.remove();
                this.container = null;
                this.inputData = null;
            };
            RadioOptionControl.prototype.onOptionClicked = function (e) {
                this.notifyOutputChanged.apply(this);
            };
            RadioOptionControl.prototype.getRadioButtonId = function (buttonGroupName, buttonValue) {
                return buttonGroupName + "_" + buttonValue;
            };
            RadioOptionControl.prototype.getChildElement = function (element, childClassName) {
                if (element) {
                    var childElementList = element.getElementsByClassName(childClassName);
                    if (childElementList && childElementList.length > 0) {
                        return childElementList[0];
                    }
                }
                return null;
            };
            RadioOptionControl.prototype.getParentElement = function (element, nodeDistance) {
                var currentDepth = 0;
                var currentElement = element;
                while (currentDepth < nodeDistance) {
                    if (!currentElement) {
                        return null;
                    }
                    currentElement = currentElement.parentElement;
                    currentDepth = currentDepth + 1;
                }
                return currentElement;
            };
            /**
            * We need this function as a workaround since we are not currently able to access the output parameter value from the custom control context.
            * The Custom Control Framework sets the output parameter raw value as an empty string rather than using the actual value.
            * TODO: Remove this logic when there is a better way to retrieve the current value of a bound parameter before it is updated.
            * @params parameterName The bound parameter name.
            */
            RadioOptionControl.prototype.getBoundParameterValue = function (parameterName) {
                var Xrm = window.Xrm;
                if (Xrm && Xrm.Page) {
                    var attribute = Xrm.Page.getAttribute(parameterName);
                    if (attribute) {
                        return attribute.getValue();
                    }
                }
                return null;
            };
            return RadioOptionControl;
        }());
        RadioOptionControl.RootElementNodeDistance = 5;
        RadioOptionControl.InlineLockedClass = "ms-crm-Inline-Locked";
        RadioOptionControl.InlineLockIconClass = "ms-crm-Inline-LockIcon";
        RadioOptionControl.InlineValueClass = "ms-crm-Inline-Value";
        RadioOptionControl.RadioLabelColor = "#000000 !important";
        RadioOption.RadioOptionControl = RadioOptionControl;
    })(RadioOption = MscrmControls.RadioOption || (MscrmControls.RadioOption = {}));
})(MscrmControls || (MscrmControls = {}));
/**
* @license Copyright (c) Microsoft Corporation. All rights reserved.
*/
/// <reference path="RadioOption.ts" />
//# sourceMappingURL=RadioOption.js.map